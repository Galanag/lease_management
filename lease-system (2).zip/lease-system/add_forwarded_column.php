<?php
// add_forwarded_column.php
require_once 'config.php';

$db = getDb();

// Check if column already exists
$cols = $db->query("PRAGMA table_info(applications)");
$has = false;
while ($c = $cols->fetchArray(SQLITE3_ASSOC)) {
    if ($c['name'] == 'forwarded_to_head_office') {
        $has = true;
        break;
    }
}

if (!$has) {
    $db->exec("ALTER TABLE applications ADD COLUMN forwarded_to_head_office INTEGER DEFAULT 0");
    echo "✅ Added column 'forwarded_to_head_office' to applications table.<br>";
} else {
    echo "ℹ️ Column already exists.<br>";
}