<?php
// add_missing_application_columns.php
require_once 'config.php';

$db = getDb();

// List of columns that should exist in applications table
$requiredColumns = [
    'lease_id' => 'TEXT',
    'user_id' => 'INTEGER',
    'branch_id' => 'INTEGER',
    'sector' => 'TEXT',
    'status' => 'TEXT DEFAULT \'pending\'',
    'current_stage' => 'INTEGER DEFAULT 1',
    'total_amount' => 'REAL',
    'down_payment' => 'REAL',
    'financed_amount' => 'REAL',
    'service_charge' => 'REAL',
    'total_repayment' => 'REAL',
    'term_months' => 'INTEGER',
    'frequency' => 'TEXT',
    'applicant_full_name' => 'TEXT',
    'applicant_gender' => 'TEXT',
    'applicant_dob' => 'DATE',
    'nationality' => 'TEXT',
    'applicant_national_id' => 'TEXT',
    'tin' => 'TEXT',
    'phone' => 'TEXT',
    'alternative_phone' => 'TEXT',
    'email' => 'TEXT',
    'region' => 'TEXT',
    'zone' => 'TEXT',
    'woreda' => 'TEXT',
    'house_number' => 'TEXT',
    'city' => 'TEXT',
    'address' => 'TEXT',
    'applicant_birth_place' => 'TEXT',
    'marriage_status' => 'TEXT',
    'total_members_male' => 'INTEGER',
    'total_members_female' => 'INTEGER',
    'business_name' => 'TEXT',
    'business_form' => 'TEXT',
    'enterprise_stage' => 'TEXT',
    'business_status' => 'TEXT',
    'business_reg_number' => 'TEXT',
    'business_license_number' => 'TEXT',
    'year_established' => 'INTEGER',
    'business_activity' => 'TEXT',
    'main_products' => 'TEXT',
    'num_employees' => 'INTEGER',
    'annual_revenue' => 'REAL',
    'business_location' => 'TEXT',
    'business_year_registered' => 'INTEGER',
    'business_type_engaged' => 'TEXT',
    'electric_power_applicant_kw' => 'TEXT',
    'electric_power_required_kw' => 'TEXT',
    'working_place_status' => 'TEXT',
    'equipment_name' => 'TEXT',
    'other_product_name' => 'TEXT',
    'other_product_price' => 'REAL'
];

// Get existing columns
$existing = [];
$cols = $db->query("PRAGMA table_info(applications)");
while ($col = $cols->fetchArray(SQLITE3_ASSOC)) {
    $existing[] = $col['name'];
}

$added = 0;
foreach ($requiredColumns as $col => $type) {
    if (!in_array($col, $existing)) {
        $db->exec("ALTER TABLE applications ADD COLUMN $col $type");
        echo "✅ Added column: $col<br>";
        $added++;
    }
}

if ($added == 0) {
    echo "All columns already exist.";
} else {
    echo "<br>Total columns added: $added";
}