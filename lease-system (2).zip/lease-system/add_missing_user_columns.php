<?php
// add_missing_user_columns.php
require_once 'config.php';

$db = getDb();

// Get existing columns
$columns = $db->query("PRAGMA table_info(users)");
$existing = [];
while ($col = $columns->fetchArray(SQLITE3_ASSOC)) {
    $existing[] = $col['name'];
}

// List of columns that should exist (from registration form)
$requiredColumns = [
    'username', 'email', 'password', 'role', 'approved',
    'full_name', 'gender', 'birth_date', 'nationality', 'national_id', 'tin',
    'phone', 'alternative_phone',
    'business_name', 'business_form', 'business_reg_number', 'business_license_number',
    'year_established', 'sector',
    'region', 'zone', 'woreda', 'house_number', 'city', 'address',
    'created_at'
];

$added = false;
foreach ($requiredColumns as $col) {
    if (!in_array($col, $existing)) {
        // Determine data type (most are TEXT)
        $type = 'TEXT';
        if ($col == 'year_established') $type = 'INTEGER';
        if ($col == 'approved') $type = 'INTEGER DEFAULT 0';
        if ($col == 'created_at') $type = 'DATETIME DEFAULT CURRENT_TIMESTAMP';
        $db->exec("ALTER TABLE users ADD COLUMN $col $type");
        echo "✅ Added column: $col<br>";
        $added = true;
    } else {
        echo "ℹ️ Column $col already exists.<br>";
    }
}

if (!$added) {
    echo "All columns already present.";
}