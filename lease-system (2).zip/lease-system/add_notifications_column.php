<?php
// add_notifications_column.php
require_once 'config.php';

$db = getDb();

// Check if column already exists
$columns = $db->query("PRAGMA table_info(notifications)");
$hasAppId = false;
while ($col = $columns->fetchArray(SQLITE3_ASSOC)) {
    if ($col['name'] === 'application_id') {
        $hasAppId = true;
        break;
    }
}

if (!$hasAppId) {
    $db->exec("ALTER TABLE notifications ADD COLUMN application_id INTEGER");
    echo "✅ Added column 'application_id' to notifications table.<br>";
} else {
    echo "ℹ️ Column 'application_id' already exists.<br>";
}

// Also ensure other columns exist (optional)
$required = ['user_id', 'message', 'link', 'created_at', 'read_at'];
$cols = $db->query("PRAGMA table_info(notifications)");
$existing = [];
while ($c = $cols->fetchArray(SQLITE3_ASSOC)) $existing[] = $c['name'];
foreach ($required as $col) {
    if (!in_array($col, $existing)) {
        $db->exec("ALTER TABLE notifications ADD COLUMN $col TEXT");
        echo "✅ Added column '$col'.<br>";
    }
}