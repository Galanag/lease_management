<?php
require_once 'config.php';
$db = getDb();
$db->exec("ALTER TABLE applications ADD COLUMN other_product_name TEXT");
$db->exec("ALTER TABLE applications ADD COLUMN other_product_price REAL");
echo "Columns added.";