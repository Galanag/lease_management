<?php
require_once 'config.php';
$db = getDb();

// Check if column exists
$result = $db->query("PRAGMA table_info(users)");
$hasUsername = false;
while ($col = $result->fetchArray(SQLITE3_ASSOC)) {
    if ($col['name'] == 'username') {
        $hasUsername = true;
        break;
    }
}
if (!$hasUsername) {
    $db->exec("ALTER TABLE users ADD COLUMN username TEXT");
    echo "✅ Added 'username' column to users table.<br>";
} else {
    echo "ℹ️ 'username' column already exists.<br>";
}