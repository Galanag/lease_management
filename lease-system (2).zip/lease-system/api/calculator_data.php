<?php
// api/calculator_data.php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

$db = getDb();

// Fetch products
$products = [];
$res = $db->query("SELECT id, name, price, sector FROM products WHERE available = 1 AND status = 'approved' ORDER BY name");
while ($p = $res->fetchArray(SQLITE3_ASSOC)) {
    $products[] = $p;
}

// Define sector constants (from tariff)
$sectorConstants = [
    'IMX' => ['appFee' => 500, 'downRate' => 10],
    'Agriculture' => ['appFee' => 1500, 'downRate' => 20],
    'Manufacturing' => ['appFee' => 1500, 'downRate' => 15],
    'Services' => ['appFee' => 1500, 'downRate' => 20],
    'Construction' => ['appFee' => 2000, 'downRate' => 25]
];

// Service charge rates
$serviceRates = [
    'IMX' => [1=>20,2=>20,3=>20.5,4=>20.5,5=>21.5,6=>22,7=>22],
    'Agriculture' => [1=>20,2=>20,3=>21.5,4=>21.5,5=>22,6=>null,7=>null],
    'Manufacturing' => [1=>20,2=>20,3=>21.5,4=>21.5,5=>22,6=>22.5,7=>22.5],
    'Services' => [1=>20,2=>20,3=>21.5,4=>21.5,5=>22,6=>22.5,7=>22.5],
    'Construction' => [1=>21,2=>21,3=>21.5,4=>21.5,5=>22.5,6=>23,7=>23]
];

// Allowed frequencies
$allowedFrequencies = [
    'IMX' => ['Monthly', 'Quarterly'],
    'Agriculture' => ['Monthly', 'Quarterly', 'Semi-Annual'],
    'Manufacturing' => ['Monthly', 'Quarterly'],
    'Services' => ['Monthly'],
    'Construction' => ['Monthly', 'Quarterly']
];

echo json_encode([
    'products' => $products,
    'sectorConstants' => $sectorConstants,
    'serviceRates' => $serviceRates,
    'allowedFrequencies' => $allowedFrequencies
]);