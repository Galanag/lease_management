<?php
// api/chapa_webhook.php
// Handles Chapa payment callback
require_once __DIR__ . '/../config.php';

// Log the incoming data for debugging (optional)
$input = file_get_contents('php://input');
$event = json_decode($input, true);

// In a real Chapa webhook, you would verify the signature using your secret key
// For simulation, we'll assume the event is valid

if ($event && isset($event['event']) && $event['event'] === 'charge.success') {
    $tx_ref = $event['data']['tx_ref'] ?? '';
    $transaction_id = $event['data']['id'] ?? '';

    $db = getDb();

    // Find the payment record with this transaction reference
    $payment = $db->querySingle("SELECT * FROM payments WHERE transaction_id = ?", $tx_ref);
    if (!$payment) {
        http_response_code(404);
        exit;
    }

    // Update payment status
    $db->exec("UPDATE payments SET status = 'completed', paid_at = datetime('now') WHERE id = {$payment['id']}");

    // Extract installment ID from notes (if stored as "Installment X")
    $notes = $payment['notes'];
    if (preg_match('/Installment (\d+)/', $notes, $matches)) {
        $installment_id = intval($matches[1]);
        $db->exec("UPDATE payment_installments SET status = 'paid', payment_id = {$payment['id']} WHERE id = $installment_id");

        // Notify the user
        $app_id = $payment['application_id'];
        $app = $db->querySingle("SELECT user_id FROM applications WHERE id = $app_id", true);
        if ($app) {
            addNotification($app['user_id'], $app_id, 'Payment received successfully.', "?page=view_application&id=$app_id");
        }
    }
}

http_response_code(200); // Acknowledge receipt