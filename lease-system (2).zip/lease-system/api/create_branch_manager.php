<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json');

if (!isAdmin()) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$name = trim($input['name'] ?? '');
$email = trim($input['email'] ?? '');
$phone = trim($input['phone'] ?? '');
$password = $input['password'] ?? '';

if (empty($name) || empty($email) || empty($password)) {
    echo json_encode(['error' => 'Name, email, and password are required.']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['error' => 'Invalid email.']);
    exit;
}

$db = getDb();

// Check if email already exists
$existing = $db->querySingle("SELECT id FROM users WHERE email = '$email'");
if ($existing) {
    echo json_encode(['error' => 'Email already exists.']);
    exit;
}

$hashed = password_hash($password, PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO users (username, email, password, full_name, phone, role, approved) VALUES (?, ?, ?, ?, ?, 'branch', 1)");
$stmt->bindValue(1, $email, SQLITE3_TEXT);
$stmt->bindValue(2, $email, SQLITE3_TEXT);
$stmt->bindValue(3, $hashed, SQLITE3_TEXT);
$stmt->bindValue(4, $name, SQLITE3_TEXT);
$stmt->bindValue(5, $phone, SQLITE3_TEXT);
$stmt->execute();
$user_id = $db->lastInsertRowID();

echo json_encode(['success' => true, 'user_id' => $user_id]);