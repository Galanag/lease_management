<?php
// api/get_service_rate.php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

$sector = $_GET['sector'] ?? '';
$term = intval($_GET['term'] ?? 0);

if (!$sector || !$term) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing sector or term']);
    exit;
}

$db = getDb();

// Get service charge rate
$years = ceil($term / 12);
$stmt = $db->prepare("SELECT rate FROM service_charge_rates WHERE sector = :sector AND term_min <= :years AND term_max >= :years");
$stmt->bindValue(':sector', $sector, SQLITE3_TEXT);
$stmt->bindValue(':years', $years, SQLITE3_INTEGER);
$res = $stmt->execute();
$row = $res->fetchArray(SQLITE3_ASSOC);
$rate = $row ? $row['rate'] : null;

// Get down payment rate
$stmt2 = $db->prepare("SELECT rate FROM down_payment_rates WHERE sector = ?");
$stmt2->bindValue(1, $sector, SQLITE3_TEXT);
$res2 = $stmt2->execute();
$row2 = $res2->fetchArray(SQLITE3_ASSOC);
$downRate = $row2 ? $row2['rate'] : null;

// Get application fee
$stmt3 = $db->prepare("SELECT fee_amount FROM application_fees WHERE sector = ?");
$stmt3->bindValue(1, $sector, SQLITE3_TEXT);
$res3 = $stmt3->execute();
$row3 = $res3->fetchArray(SQLITE3_ASSOC);
$appFee = $row3 ? $row3['fee_amount'] : null;

if ($rate === null || $downRate === null || $appFee === null) {
    http_response_code(404);
    echo json_encode(['error' => 'Sector data not found']);
    exit;
}

echo json_encode([
    'rate' => $rate,
    'down_payment_rate' => $downRate,
    'application_fee' => $appFee,
    'sector' => $sector
]);

function getServiceChargeRate($sector, $termMonths) {
    $years = $termMonths / 12;
    $db = getDb();
    $stmt = $db->prepare("SELECT rate FROM service_charge_rates 
                          WHERE sector = ? AND term_min < ? AND term_max >= ?");
    $stmt->bindValue(1, $sector, SQLITE3_TEXT);
    $stmt->bindValue(2, $years, SQLITE3_FLOAT);
    $stmt->bindValue(3, $years, SQLITE3_FLOAT);
    $res = $stmt->execute();
    if ($row = $res->fetchArray(SQLITE3_ASSOC)) {
        return $row['rate'];
    }
    return 0; // fallback
}