<?php
// api/initiate_payment.php
// Initiates a Chapa payment for a given application and installment
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

// Ensure user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'Not authenticated']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$app_id = intval($input['app_id'] ?? 0);
$installment_id = intval($input['installment_id'] ?? 0);
$amount = floatval($input['amount'] ?? 0);

if (!$app_id || !$installment_id || $amount <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing or invalid parameters']);
    exit;
}

$user_id = $_SESSION['user_id'];
$db = getDb();

// Verify that the application belongs to the user
$app = $db->querySingle("SELECT a.*, u.email, u.business_name FROM applications a JOIN users u ON a.user_id = u.id WHERE a.id = $app_id AND a.user_id = $user_id", true);
if (!$app) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Verify the installment exists and is pending
$installment = $db->querySingle("SELECT * FROM payment_installments WHERE id = $installment_id AND application_id = $app_id AND status = 'pending'", true);
if (!$installment) {
    http_response_code(400);
    echo json_encode(['error' => 'Installment not found or already paid']);
    exit;
}

// --- Simulate Chapa payment initiation ---
// In production, you would:
// 1. Get Chapa secret key from config (define CHAPA_SECRET_KEY in config.php)
// 2. Prepare payload:
//    $payload = [
//        'amount' => $amount,
//        'currency' => 'ETB',
//        'email' => $app['email'],
//        'first_name' => $app['business_name'] ?: 'Customer',
//        'tx_ref' => 'LEASE-' . $app_id . '-' . time(),
//        'callback_url' => BASE_URL . 'api/chapa_webhook.php',
//        'return_url' => BASE_URL . '?page=payment_success',
//        'customization' => ['title' => 'Lease Payment', 'description' => 'Payment for lease #' . $app['lease_id']]
//    ];
// 3. Send POST to 'https://api.chapa.co/v1/transaction/initialize' with headers
// 4. Return the checkout_url from Chapa

// For simulation, we'll generate a fake checkout URL and store a pending payment record
$tx_ref = 'LEASE-' . $app_id . '-' . time();

// Insert a pending payment record
$stmt = $db->prepare("INSERT INTO payments (application_id, amount, method, transaction_id, status, notes) VALUES (?, ?, 'chapa', ?, 'pending', ?)");
$stmt->bindValue(1, $app_id, SQLITE3_INTEGER);
$stmt->bindValue(2, $amount, SQLITE3_FLOAT);
$stmt->bindValue(3, $tx_ref, SQLITE3_TEXT);
$stmt->bindValue(4, 'Installment ' . $installment_id, SQLITE3_TEXT);
$stmt->execute();

// Simulate a checkout URL (in production, this comes from Chapa)
$checkout_url = 'https://checkout.chapa.co/checkout/' . $tx_ref; // fake

echo json_encode(['checkout_url' => $checkout_url, 'tx_ref' => $tx_ref]);