<?php
require_once __DIR__ . '/../config.php';
if (!isLoggedIn()) {
    http_response_code(401);
    exit;
}
$db = getDb();
$db->exec("UPDATE notifications SET read_at = datetime('now') WHERE user_id = {$_SESSION['user_id']} AND read_at IS NULL");
echo 'OK';