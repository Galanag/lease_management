<?php
// api/nearest-branch.php
// Returns the nearest branch based on latitude and longitude (Haversine formula)
// require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

if (!isset($_GET['lat']) || !isset($_GET['lon'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing latitude or longitude']);
    exit;
}

$lat = floatval($_GET['lat']);
$lon = floatval($_GET['lon']);

$db = getDb();

// Fetch all branches with coordinates
$branches = $db->query("SELECT id, name, city, address, phone, manager, latitude, longitude FROM branches WHERE latitude IS NOT NULL AND longitude IS NOT NULL");

$nearest = null;
$minDistance = PHP_INT_MAX;

while ($branch = $branches->fetchArray(SQLITE3_ASSOC)) {
    // Haversine formula
    $earthRadius = 6371; // km
    $dLat = deg2rad($branch['latitude'] - $lat);
    $dLon = deg2rad($branch['longitude'] - $lon);
    $a = sin($dLat / 2) * sin($dLat / 2) +
         cos(deg2rad($lat)) * cos(deg2rad($branch['latitude'])) *
         sin($dLon / 2) * sin($dLon / 2);
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    $distance = $earthRadius * $c;

    if ($distance < $minDistance) {
        $minDistance = $distance;
        $nearest = $branch;
        $nearest['distance'] = round($distance, 2);
    }
}

if ($nearest) {
    echo json_encode(['branch' => $nearest]);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'No branches found']);
}