<?php
// api/product_details.php
require_once __DIR__ . '/../config.php';

$id = $_GET['id'] ?? 0;
if (!$id) {
    die(json_encode(['error' => 'No product ID provided.']));
}

$db = getDb();
$product = $db->querySingle("SELECT * FROM products WHERE id = $id AND available = 1 AND approved = 1", true);
if (!$product) {
    die(json_encode(['error' => 'Product not found.']));
}

// Fetch images
$images = [];
$imgRes = $db->query("SELECT image_path FROM product_images WHERE product_id = $id ORDER BY sort_order");
while ($img = $imgRes->fetchArray(SQLITE3_ASSOC)) {
    $images[] = $img['image_path'];
}

$product['images'] = $images;
header('Content-Type: application/json');
echo json_encode($product);