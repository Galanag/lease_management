<?php
require_once 'config.php';

$db = getDb();

echo "<h1>Products Table Check</h1>";

// Count products
$count = $db->querySingle("SELECT COUNT(*) FROM products");
echo "<p>Total products: $count</p>";

if ($count == 0) {
    echo "<p style='color:red'>No products found. Please insert sample products.</p>";
} else {
    // Fetch all products
    $products = $db->query("SELECT id, name, price, sector, available, status FROM products ORDER BY sector, name");
    echo "<table border='1' cellpadding='5' cellspacing='0'>";
    echo "<tr><th>ID</th><th>Name</th><th>Price</th><th>Sector</th><th>Available</th><th>Status</th></tr>";
    while ($p = $products->fetchArray(SQLITE3_ASSOC)) {
        echo "<tr>";
        echo "<td>{$p['id']}</td>";
        echo "<td>" . htmlspecialchars($p['name']) . "</td>";
        echo "<td>" . number_format($p['price'], 2) . "</td>";
        echo "<td>{$p['sector']}</td>";
        echo "<td>" . ($p['available'] ? 'Yes' : 'No') . "</td>";
        echo "<td>{$p['status']}</td>";
        echo "</tr>";
    }
    echo "</table>";
}

echo "<h2>Test getDownPaymentRate function</h2>";
$sectors = ['IMX', 'Agriculture', 'Manufacturing', 'Services', 'Construction'];
foreach ($sectors as $s) {
    $rate = getDownPaymentRate($s);
    echo "$s -> " . ($rate !== null ? $rate . '%' : 'Not defined') . "<br>";
}

echo "<h2>Test getApplicationFee function</h2>";
foreach ($sectors as $s) {
    $fee = getApplicationFee($s);
    echo "$s -> " . ($fee !== null ? 'ETB ' . number_format($fee, 2) : 'Not defined') . "<br>";
}

echo "<h2>Test getServiceChargeRate for Agriculture (24 months)</h2>";
$rate = getServiceChargeRate('Agriculture', 24);
echo "Rate: " . ($rate !== null ? $rate . '%' : 'Not defined') . "<br>";

echo "<h2>Test getAllowedFrequencies for Agriculture</h2>";
$freq = getAllowedFrequencies('Agriculture');
echo "Allowed: " . implode(', ', $freq) . "<br>";