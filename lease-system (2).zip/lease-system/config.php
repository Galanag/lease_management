<?php
// config.php - place in project root

// Prevent multiple inclusions
if (!defined('BASE_URL')) {
    define('BASE_URL', 'https://siinqeelease.ijadevelopers.com/lease-system/');
}
if (!defined('DB_PATH')) {
    define('DB_PATH', '/home/ijadeveloperscom/siinqeelease.ijadevelopers.com/lease-system/database/lease.db');
}
if (!defined('SITE_NAME')) {
    define('SITE_NAME', 'SiinQee Lease');
}

// Start session first – before any output
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection function
if (!function_exists('getDb')) {
    function getDb() {
        $dbPath = DB_PATH;
        $dbDir = dirname($dbPath);
        
        if (!is_dir($dbDir)) {
            if (!mkdir($dbDir, 0755, true)) {
                die("Failed to create database directory: $dbDir");
            }
        }
        
        if (!is_writable($dbDir)) {
            die("Database directory is not writable: $dbDir");
        }
        
        $db = new SQLite3($dbPath);
        $db->exec('PRAGMA foreign_keys = ON;');
        return $db;
    }
}
if (!function_exists('requireApproved')) {
    function requireApproved() {
        if (!isLoggedIn()) return false;
        $db = getDb();
        $user = $db->querySingle("SELECT approved FROM users WHERE id = {$_SESSION['user_id']}", true);
        if (!$user || $user['approved'] != 1) {
            $_SESSION['error'] = 'Your account is not yet approved.';
            redirect(BASE_URL . '?page=dashboard');
        }
    }
}

if (!function_exists('getBranchByCity')) {
    function getBranchByCity($city) {
        $db = getDb();
        // Try to match zone name
        $stmt = $db->prepare("SELECT b.id FROM zones z JOIN branches b ON z.branch_id = b.id WHERE LOWER(z.name) = LOWER(:city)");
        $stmt->bindValue(':city', $city, SQLITE3_TEXT);
        $res = $stmt->execute();
        $branch = $res->fetchArray(SQLITE3_ASSOC);
        if ($branch) return $branch['id'];
        // Fallback: match city in branches table
        $stmt = $db->prepare("SELECT id FROM branches WHERE LOWER(city) = LOWER(:city)");
        $stmt->bindValue(':city', $city, SQLITE3_TEXT);
        $res = $stmt->execute();
        $branch = $res->fetchArray(SQLITE3_ASSOC);
        if ($branch) return $branch['id'];
        // Finally, return CRMD (head office)
        $crmd = $db->querySingle("SELECT id FROM branches WHERE name = 'CRMD'");
        if ($crmd) return $crmd;
        // Fallback to first branch
        return $db->querySingle("SELECT id FROM branches LIMIT 1");
    }
}

// Session and auth helpers
if (!function_exists('isLoggedIn')) {
    function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }
}
if (!function_exists('requireLogin')) {
    function requireLogin() {
        if (!isLoggedIn()) {
            $_SESSION['redirect_after_login'] = $_GET['page'] ?? 'dashboard';
            redirect(BASE_URL . '?page=login');
        }
    }
}
if (!function_exists('redirect')) {
    function redirect($url) {
        header("Location: $url");
        exit;
    }
}
if (!function_exists('isAdmin')) {
    function isAdmin() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
    }
}
if (!function_exists('requireAdmin')) {
    function requireAdmin() {
        if (!isAdmin()) {
            redirect(BASE_URL . '?page=login');
        }
    }
}
if (!function_exists('isBranchStaff')) {
    function isBranchStaff() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'branch';
    }
}
if (!function_exists('requireBranchStaff')) {
    function requireBranchStaff() {
        if (!isBranchStaff()) {
            redirect(BASE_URL . '?page=login');
        }
    }
}
if (!function_exists('isVendor')) {
    function isVendor() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'vendor';
    }
}
if (!function_exists('requireVendor')) {
    function requireVendor() {
        if (!isVendor()) {
            redirect(BASE_URL . '?page=login');
        }
    }
}
if (!function_exists('isClient')) {
    function isClient() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'client';
    }
}
if (!function_exists('requireClient')) {
    function requireClient() {
        if (!isClient()) {
            redirect(BASE_URL . '?page=login');
        }
    }
}

// Additional helper functions for dashboard
if (!function_exists('formatMoney')) {
    function formatMoney($amount) {
        return 'ETB ' . number_format($amount, 2);
    }
}
if (!function_exists('calculateLatePenalty')) {
    function calculateLatePenalty($amount, $due_date) {
        $days_overdue = max(0, (time() - strtotime($due_date)) / 86400);
        $penalty = $amount * 0.000667 * $days_overdue;
        return $penalty;
    }
}
if (!function_exists('markNotificationsRead')) {
    function markNotificationsRead($user_id) {
        $db = getDb();
        $db->exec("UPDATE notifications SET read_at = datetime('now') WHERE user_id = $user_id AND read_at IS NULL");
    }
}
if (!function_exists('getUnreadNotificationCount')) {
    function getUnreadNotificationCount($user_id) {
        $db = getDb();
        return $db->querySingle("SELECT COUNT(*) FROM notifications WHERE user_id = $user_id AND read_at IS NULL");
    }
}

// Notification helper
if (!function_exists('addNotification')) {
    function addNotification($user_id, $application_id, $message, $link = '') {
        $db = getDb();
        $stmt = $db->prepare("INSERT INTO notifications (user_id, application_id, message, link, created_at) VALUES (?, ?, ?, ?, datetime('now'))");
        $stmt->bindValue(1, $user_id, SQLITE3_INTEGER);
        $stmt->bindValue(2, $application_id, SQLITE3_INTEGER);
        $stmt->bindValue(3, $message, SQLITE3_TEXT);
        $stmt->bindValue(4, $link, SQLITE3_TEXT);
        $stmt->execute();
    }
}

if (!function_exists('getCurrentBranchId')) {
    function getCurrentBranchId() {
        if (!isLoggedIn()) return null;
        $db = getDb();
        $user_id = $_SESSION['user_id'];
        $branch = $db->querySingle("SELECT id FROM branches WHERE manager_id = $user_id LIMIT 1", true);
        return $branch ? $branch['id'] : null;
    }
}

// ========== Sector and Rate Helpers ==========
if (!function_exists('getDownPaymentRate')) {
    function getDownPaymentRate($sector) {
        $rates = [
            'IMX' => 10,
            'Agriculture' => 20,
            'Manufacturing' => 15,
            'Services' => 20,
            'Construction' => 25
        ];
        return $rates[$sector] ?? null;
    }
}

if (!function_exists('getApplicationFee')) {
    function getApplicationFee($sector) {
        $fees = [
            'IMX' => 500,
            'Agriculture' => 1500,
            'Manufacturing' => 1500,
            'Services' => 1500,
            'Construction' => 2000
        ];
        return $fees[$sector] ?? null;
    }
}

if (!function_exists('getServiceChargeRate')) {
    function getServiceChargeRate($sector, $termMonths) {
        $years = ceil($termMonths / 12);
        $rates = [
            'IMX' => [1=>20, 2=>20, 3=>20.5, 4=>20.5, 5=>21.5, 6=>22, 7=>22],
            'Agriculture' => [1=>20, 2=>20, 3=>21.5, 4=>21.5, 5=>22, 6=>null, 7=>null],
            'Manufacturing' => [1=>20, 2=>20, 3=>21.5, 4=>21.5, 5=>22, 6=>22.5, 7=>22.5],
            'Services' => [1=>20, 2=>20, 3=>21.5, 4=>21.5, 5=>22, 6=>22.5, 7=>22.5],
            'Construction' => [1=>21, 2=>21, 3=>21.5, 4=>21.5, 5=>22.5, 6=>23, 7=>23]
        ];
        if (!isset($rates[$sector])) return null;
        return $rates[$sector][$years] ?? null;
    }
}

if (!function_exists('getAllowedFrequencies')) {
    function getAllowedFrequencies($sector) {
        $freq = [
            'IMX' => ['Monthly', 'Quarterly'],
            'Agriculture' => ['Monthly', 'Quarterly', 'Semi-Annual'],
            'Manufacturing' => ['Monthly', 'Quarterly'],
            'Services' => ['Monthly'],
            'Construction' => ['Monthly', 'Quarterly']
        ];
        return $freq[$sector] ?? ['Monthly'];
    }
}