<?php
// create_missing_tables.php
require_once 'config.php';

$db = getDb();

// ------------------------------------------------------------
// 1. Create transfer_requests table if not exists
// ------------------------------------------------------------
$result = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='transfer_requests'");
if (!$result->fetchArray()) {
    $db->exec("CREATE TABLE transfer_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        application_id INTEGER NOT NULL,
        from_branch_id INTEGER NOT NULL,
        to_branch_id INTEGER NOT NULL,
        status TEXT DEFAULT 'pending',
        reason TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE
    )");
    echo "✅ Created table: transfer_requests<br>";
} else {
    echo "ℹ️ Table transfer_requests already exists.<br>";
}

// ------------------------------------------------------------
// 2. Create payments table if not exists
// ------------------------------------------------------------
$result = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='payments'");
if (!$result->fetchArray()) {
    $db->exec("CREATE TABLE payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        application_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        payment_date DATETIME,
        method TEXT,
        reference TEXT,
        status TEXT DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE
    )");
    echo "✅ Created table: payments<br>";
} else {
    echo "ℹ️ Table payments already exists.<br>";
}

// ------------------------------------------------------------
// 3. Add parent_id column to branches if missing
// ------------------------------------------------------------
$columns = $db->query("PRAGMA table_info(branches)");
$hasParent = false;
while ($col = $columns->fetchArray(SQLITE3_ASSOC)) {
    if ($col['name'] === 'parent_id') {
        $hasParent = true;
        break;
    }
}
if (!$hasParent) {
    $db->exec("ALTER TABLE branches ADD COLUMN parent_id INTEGER DEFAULT NULL");
    echo "✅ Added column parent_id to branches table.<br>";
} else {
    echo "ℹ️ Column parent_id already exists in branches table.<br>";
}

echo "<br>All missing database objects created successfully.";