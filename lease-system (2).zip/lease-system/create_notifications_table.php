<?php
// create_notifications_table.php
require_once 'config.php';

$db = getDb();

// Check if table already exists
$result = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='notifications'");
if ($result->fetchArray()) {
    echo "Table 'notifications' already exists. No action taken.";
} else {
    // Create the table
    $db->exec("CREATE TABLE notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        application_id INTEGER,
        message TEXT NOT NULL,
        link TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        read_at DATETIME
    )");
    echo "✅ Table 'notifications' created successfully.";
}