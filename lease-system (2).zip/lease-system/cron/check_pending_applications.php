<?php
require_once __DIR__ . '/../config.php';

$db = getDb();
$crmd = $db->querySingle("SELECT id FROM branches WHERE name = 'CRMD'");
if (!$crmd) {
    echo "CRMD branch not found.\n";
    exit;
}

$apps = $db->query("SELECT id, lease_id, user_id FROM applications WHERE status = 'pending' AND reminder_sent = 0 AND branch_id != $crmd AND created_at <= date('now', '-3 days')");

while ($app = $apps->fetchArray(SQLITE3_ASSOC)) {
    // Notify all admin and CRMD users
    $users = $db->query("SELECT id FROM users WHERE role IN ('admin', 'crmd')");
    while ($u = $users->fetchArray(SQLITE3_ASSOC)) {
        addNotification($u['id'], $app['id'], "Application #{$app['lease_id']} has been pending for more than 3 days.", "?page=admin_application&id={$app['id']}");
    }
    $db->exec("UPDATE applications SET reminder_sent = 1 WHERE id = {$app['id']}");
}

echo "Reminders processed.\n";