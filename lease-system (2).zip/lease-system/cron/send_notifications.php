<?php
// cron/send_notifications.php
require_once __DIR__ . '/../config.php';

$db = getDb();
$pending = $db->query("SELECT * FROM notifications WHERE status = 'pending' ORDER BY created_at ASC LIMIT 10");

while ($notif = $pending->fetchArray(SQLITE3_ASSOC)) {
    // For email
    if ($notif['type'] == 'email') {
        $to = $db->querySingle("SELECT email FROM users WHERE id = {$notif['user_id']}");
        $subject = $notif['subject'];
        $message = $notif['message'];
        $headers = "From: no-reply@siinqee.com\r\n";
        if (mail($to, $subject, $message, $headers)) {
            $db->exec("UPDATE notifications SET status = 'sent', sent_at = datetime('now') WHERE id = {$notif['id']}");
        } else {
            $db->exec("UPDATE notifications SET status = 'failed' WHERE id = {$notif['id']}");
        }
    }
    // For SMS (using a gateway like Chapa) – placeholder
    // ...
}