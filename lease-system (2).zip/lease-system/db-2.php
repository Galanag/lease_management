<?php
require_once 'config.php';
$db = getDb();
$db->exec("UPDATE products SET approved = 1");
echo "All existing products marked as approved.";
?>