<?php
// add_equipment_name_column.php
require_once 'config.php';

$db = getDb();

// Check if column already exists
$cols = $db->query("PRAGMA table_info(applications)");
$columnExists = false;
while ($col = $cols->fetchArray(SQLITE3_ASSOC)) {
    if ($col['name'] === 'equipment_name') {
        $columnExists = true;
        break;
    }
}

if (!$columnExists) {
    $db->exec("ALTER TABLE applications ADD COLUMN equipment_name TEXT");
    echo "✅ Column 'equipment_name' added to applications table.<br>";
} else {
    echo "ℹ️ Column 'equipment_name' already exists.<br>";
}

echo "<a href='index.php'>Return to site</a>";