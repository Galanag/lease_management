<?php
// final_database_setup.php
require_once 'config.php';

$db = getDb();

// 1. Add missing columns to users (if any)
$cols = $db->query("PRAGMA table_info(users)");
$existing = [];
while ($c = $cols->fetchArray(SQLITE3_ASSOC)) $existing[] = $c['name'];
if (!in_array('approved', $existing)) $db->exec("ALTER TABLE users ADD COLUMN approved INTEGER DEFAULT 0");
if (!in_array('business_name', $existing)) $db->exec("ALTER TABLE users ADD COLUMN business_name TEXT");
if (!in_array('created_at', $existing)) $db->exec("ALTER TABLE users ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP");

// 2. Add parent_id to branches
$cols = $db->query("PRAGMA table_info(branches)");
$existing = [];
while ($c = $cols->fetchArray(SQLITE3_ASSOC)) $existing[] = $c['name'];
if (!in_array('parent_id', $existing)) $db->exec("ALTER TABLE branches ADD COLUMN parent_id INTEGER DEFAULT NULL");

// 3. Create transfer_requests table
$db->exec("CREATE TABLE IF NOT EXISTS transfer_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    from_branch_id INTEGER NOT NULL,
    to_branch_id INTEGER NOT NULL,
    status TEXT DEFAULT 'pending',
    reason TEXT,
    requested_by_user INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    responded_at DATETIME,
    FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE
)");

// 4. Create payments table
$db->exec("CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    payment_date DATETIME,
    method TEXT,
    reference TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE
)");

// 5. Create notifications table
$db->exec("CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    application_id INTEGER,
    message TEXT NOT NULL,
    link TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
)");

echo "All tables and columns are now ready.";