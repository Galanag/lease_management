<?php
// final_database_setup.php
require_once 'config.php';
$db = getDb();

$db->exec("CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    application_id INTEGER,
    message TEXT NOT NULL,
    link TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME
)");

$db->exec("CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    payment_date DATETIME,
    method TEXT,
    reference TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// Also ensure transfer_requests and other tables exist (your earlier setup may have them)
$db->exec("CREATE TABLE IF NOT EXISTS transfer_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    from_branch_id INTEGER NOT NULL,
    to_branch_id INTEGER NOT NULL,
    status TEXT DEFAULT 'pending',
    reason TEXT,
    requested_by_user INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    responded_at DATETIME
)");

// Add parent_id to branches if missing
$cols = $db->query("PRAGMA table_info(branches)");
$hasParent = false;
while ($c = $cols->fetchArray(SQLITE3_ASSOC)) if ($c['name'] == 'parent_id') $hasParent = true;
if (!$hasParent) $db->exec("ALTER TABLE branches ADD COLUMN parent_id INTEGER DEFAULT NULL");

echo "All tables are ready.";