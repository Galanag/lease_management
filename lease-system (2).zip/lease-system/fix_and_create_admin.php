<?php
// fix_and_create_admin.php
require_once 'config.php';

$db = getDb();

// ========== 1. Add missing columns to users table ==========
echo "Checking users table...<br>";

// Get existing columns
$columns = $db->query("PRAGMA table_info(users)");
$existing = [];
while ($col = $columns->fetchArray(SQLITE3_ASSOC)) {
    $existing[] = $col['name'];
}

// Add username column if missing
if (!in_array('username', $existing)) {
    $db->exec("ALTER TABLE users ADD COLUMN username TEXT");
    echo "✅ Added 'username' column.<br>";
} else {
    echo "ℹ️ 'username' column already exists.<br>";
}

// Add approved column if missing
if (!in_array('approved', $existing)) {
    $db->exec("ALTER TABLE users ADD COLUMN approved INTEGER DEFAULT 0");
    echo "✅ Added 'approved' column.<br>";
} else {
    echo "ℹ️ 'approved' column already exists.<br>";
}

// Add business_name column if missing (for client dashboard)
if (!in_array('business_name', $existing)) {
    $db->exec("ALTER TABLE users ADD COLUMN business_name TEXT");
    echo "✅ Added 'business_name' column.<br>";
} else {
    echo "ℹ️ 'business_name' column already exists.<br>";
}

// ========== 2. Create admin user ==========
$admin_email = 'admin@siinqee.com';
$admin_username = 'admin';
$admin_password = 'admin123'; // Change if desired
$admin_fullname = 'System Administrator';
$admin_role = 'admin';

// Hash password
$hashed = password_hash($admin_password, PASSWORD_DEFAULT);

// Check if admin already exists
$exists = $db->querySingle("SELECT id FROM users WHERE email = '$admin_email' OR username = '$admin_username'");
if ($exists) {
    echo "Admin user already exists. Skipping creation.<br>";
    echo "You can log in with email: $admin_email or username: $admin_username, password: $admin_password<br>";
} else {
    $stmt = $db->prepare("INSERT INTO users (username, email, password, full_name, role, approved) VALUES (?, ?, ?, ?, ?, 1)");
    $stmt->bindValue(1, $admin_username, SQLITE3_TEXT);
    $stmt->bindValue(2, $admin_email, SQLITE3_TEXT);
    $stmt->bindValue(3, $hashed, SQLITE3_TEXT);
    $stmt->bindValue(4, $admin_fullname, SQLITE3_TEXT);
    $stmt->bindValue(5, $admin_role, SQLITE3_TEXT);
    $stmt->execute();
    echo "✅ Admin user created successfully!<br>";
    echo "Email: $admin_email<br>";
    echo "Username: $admin_username<br>";
    echo "Password: $admin_password<br>";
}

echo "<br>You can now <a href='" . BASE_URL . "?page=login'>log in</a>.";
?>