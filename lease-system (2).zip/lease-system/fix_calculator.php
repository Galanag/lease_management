<?php
// fix_calculator.php – Run once, then delete
require_once __DIR__ . '/config.php';

$db = getDb();

// Check if down_payment_rates table has 'sector' column
$columns = $db->query("PRAGMA table_info(down_payment_rates)");
$hasSector = false;
while ($col = $columns->fetchArray(SQLITE3_ASSOC)) {
    if ($col['name'] === 'sector') $hasSector = true;
}

if (!$hasSector) {
    // If table exists but no sector column, drop and recreate (simplest)
    $db->exec("DROP TABLE IF EXISTS down_payment_rates");
    $db->exec("CREATE TABLE down_payment_rates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sector TEXT,
        rate DECIMAL(5,2),
        description TEXT
    )");
    $db->exec("INSERT INTO down_payment_rates (sector, rate) VALUES
        ('IMX', 10), ('Manufacturing', 15), ('Agriculture', 20),
        ('Services', 20), ('Construction', 25), ('Employees', 5)");
    echo "Recreated down_payment_rates table with sector column.<br>";
} else {
    echo "Table already has sector column.";
}

// Also check service_charge_rates table (used by get_service_rate.php)
$columns2 = $db->query("PRAGMA table_info(service_charge_rates)");
$hasSector2 = false;
while ($col = $columns2->fetchArray(SQLITE3_ASSOC)) {
    if ($col['name'] === 'sector') $hasSector2 = true;
}
if (!$hasSector2) {
    $db->exec("DROP TABLE IF EXISTS service_charge_rates");
    $db->exec("CREATE TABLE service_charge_rates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sector TEXT,
        term_min INTEGER,
        term_max INTEGER,
        rate DECIMAL(5,2)
    )");
    // Insert sample data (you can expand)
    $db->exec("INSERT INTO service_charge_rates (sector, term_min, term_max, rate) VALUES
        ('Agriculture', 1, 2, 20.0), ('Agriculture', 3, 4, 21.5), ('Agriculture', 5, 5, 22.0),
        ('Manufacturing', 1, 2, 20.0), ('Manufacturing', 3, 4, 21.5), ('Manufacturing', 5, 5, 22.0), ('Manufacturing', 6, 7, 22.5),
        ('Construction', 1, 2, 21.0), ('Construction', 3, 4, 21.5), ('Construction', 5, 5, 22.5), ('Construction', 6, 7, 23.0)");
    echo "Recreated service_charge_rates table with sector column.<br>";
}

echo "Done. Delete this file.";