<?php
// fix_transfer_requests.php
require_once 'config.php';

$db = getDb();
$db->exec("ALTER TABLE transfer_requests ADD COLUMN requested_by_user INTEGER");
$db->exec("ALTER TABLE transfer_requests RENAME COLUMN requested_at TO created_at");

// Get existing columns
$cols = $db->query("PRAGMA table_info(transfer_requests)");
$existing = [];
while ($c = $cols->fetchArray(SQLITE3_ASSOC)) {
    $existing[] = $c['name'];
}

// Add requested_by_user if missing
if (!in_array('requested_by_user', $existing)) {
    $db->exec("ALTER TABLE transfer_requests ADD COLUMN requested_by_user INTEGER");
    echo "✅ Added column 'requested_by_user'.<br>";
}

// Add created_at if missing (rename if needed)
if (!in_array('created_at', $existing)) {
    // If 'requested_at' exists, rename it to created_at
    if (in_array('requested_at', $existing)) {
        $db->exec("ALTER TABLE transfer_requests RENAME COLUMN requested_at TO created_at");
        echo "✅ Renamed 'requested_at' to 'created_at'.<br>";
    } else {
        $db->exec("ALTER TABLE transfer_requests ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP");
        echo "✅ Added column 'created_at'.<br>";
    }
} else {
    echo "ℹ️ Column 'created_at' already exists.<br>";
}

echo "Done. You can now <a href='index.php'>go back</a>.";
