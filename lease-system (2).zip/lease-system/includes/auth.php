<?php
// includes/auth.php
require_once __DIR__ . '/../config.php';

function login($username, $password) {
    $db = getDb();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->bindValue(1, $username, SQLITE3_TEXT);
    $stmt->bindValue(2, $username, SQLITE3_TEXT);
    $result = $stmt->execute();
    $user = $result->fetchArray(SQLITE3_ASSOC);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['branch_id'] = $user['branch_id'];
        $_SESSION['business_name'] = $user['business_name'];
        return true;
    }
    return false;
}

// Client registration (simplified – in real file you'd have all fields)
function registerClient($data) {
    $db = getDb();
    $password = password_hash($data['password'], PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO users (username, email, password, role, approved, full_name, gender, birth_date, nationality, national_id, tin, phone, alternative_phone, business_name, business_form, business_reg_number, business_license_number, year_established, sector, region, zone, woreda, house_number, city, address) VALUES (?, ?, ?, 'client', 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    // bind all – omitted for brevity
    return $stmt->execute();
}

function registerVendor($data) {
    // similar with many fields
}

// Role check functions
function isLoggedIn() { return isset($_SESSION['user_id']); }
function getUserRole() { return $_SESSION['role'] ?? 'guest'; }
function isAdmin() { return getUserRole() === 'admin'; }
function isBranchStaff() { return getUserRole() === 'branch_staff'; }
function isClient() { return getUserRole() === 'client'; }
function isVendor() { return getUserRole() === 'vendor'; }
function getCurrentBranchId() { return $_SESSION['branch_id'] ?? null; }