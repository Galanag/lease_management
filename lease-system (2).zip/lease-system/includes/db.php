<?php
// includes/db.php
function getDb() {
    static $db = null;
    if ($db === null) {
        $db = new SQLite3(DB_PATH);
        $db->exec('PRAGMA foreign_keys = ON;');
    }
    return $db;
}