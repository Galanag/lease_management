<?php
// includes/config.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('BASE_URL', 'https://siinqeelease.ijadevelopers.com/lease-system/');
define('DB_PATH', __DIR__ . '/../database.sqlite');
define('SITE_NAME', 'SiinQee Lease');

// Include core files
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/role_check.php';