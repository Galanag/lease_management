<?php
// includes/footer.php
?>
    </main>
    <footer class="bg-white border-t mt-8 py-6">
        <div class="container mx-auto px-4 text-center text-gray-600">
            &copy; <?= date('Y') ?> <?= SITE_NAME ?>. All rights reserved.
        </div>
    </footer>
</body>
</html>