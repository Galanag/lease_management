<?php
// includes/functions.php
require_once __DIR__ . '/db.php';

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

function generateLeaseId() {
    return 'LS-' . date('Y') . '-' . str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
}

function getStageName($stage) {
    $stages = [
        1 => 'Inquiry Received',
        2 => 'Application Submitted',
        3 => 'Credit Assessment',
        4 => 'Approval & Conditions',
        5 => 'Contract Signing',
        6 => 'Asset Procurement',
        7 => 'Disbursement',
        8 => 'Active Lease'
    ];
    return $stages[$stage] ?? 'Unknown';
}

function formatMoney($amount) {
    return 'ETB ' . number_format($amount, 2);
}

// ---------- TARIFF HELPERS ----------
function getDownPaymentRate($sector) {
    $db = getDb();
    $stmt = $db->prepare("SELECT rate FROM down_payment_rates WHERE sector = ?");
    $stmt->bindValue(1, $sector, SQLITE3_TEXT);
    $res = $stmt->execute();
    $row = $res->fetchArray(SQLITE3_ASSOC);
    return $row ? $row['rate'] : 20;
}

function getApplicationFee($sector) {
    $db = getDb();
    $stmt = $db->prepare("SELECT fee_amount FROM application_fees WHERE sector = ?");
    $stmt->bindValue(1, $sector, SQLITE3_TEXT);
    $res = $stmt->execute();
    $row = $res->fetchArray(SQLITE3_ASSOC);
    return $row ? $row['fee_amount'] : 0;
}

function getServiceChargeRate($sector, $term_months) {
    $years = ceil($term_months / 12);
    $db = getDb();
    $stmt = $db->prepare("SELECT rate FROM service_charge_rates WHERE sector = :sector AND term_min <= :years AND term_max >= :years");
    $stmt->bindValue(':sector', $sector, SQLITE3_TEXT);
    $stmt->bindValue(':years', $years, SQLITE3_INTEGER);
    $res = $stmt->execute();
    $row = $res->fetchArray(SQLITE3_ASSOC);
    return $row ? $row['rate'] : 20;
}

function getRepaymentFrequency($sector, $equipment_type = null) {
    $db = getDb();
    if ($equipment_type) {
        $stmt = $db->prepare("SELECT frequency FROM repayment_frequencies WHERE sector = ? AND equipment_type = ?");
        $stmt->bindValue(2, $equipment_type, SQLITE3_TEXT);
    } else {
        $stmt = $db->prepare("SELECT frequency FROM repayment_frequencies WHERE sector = ? AND equipment_type IS NULL");
    }
    $stmt->bindValue(1, $sector, SQLITE3_TEXT);
    $res = $stmt->execute();
    $row = $res->fetchArray(SQLITE3_ASSOC);
    return $row ? explode(',', $row['frequency']) : ['monthly'];
}

function generateLeaseInstallments($app_id, $sector, $total_amount, $term_months, $service_rate, $repayment_method = null, $equipment_type = null) {
    if ($term_months <= 0 || $total_amount <= 0) {
        error_log("generateLeaseInstallments: Invalid term or total amount for app $app_id");
        return;
    }
    $db = getDb();
    if ($repayment_method) {
        switch (strtolower($repayment_method)) {
            case 'monthly': $num = $term_months; break;
            case 'quarterly': $num = ceil($term_months / 3); break;
            case 'semi-annual': $num = ceil($term_months / 6); break;
            case 'annual': $num = ceil($term_months / 12); break;
            default: $num = $term_months;
        }
    } else {
        $freqs = getRepaymentFrequency($sector, $equipment_type);
        $freq = $freqs[0];
        switch ($freq) {
            case 'monthly': $num = $term_months; break;
            case 'quarterly': $num = ceil($term_months / 3); break;
            case 'semi-annual': $num = ceil($term_months / 6); break;
            default: $num = $term_months;
        }
    }
    $installment_amount = $total_amount / $num;
    $start_date = date('Y-m-d');
    for ($i = 1; $i <= $num; $i++) {
        $due = date('Y-m-d', strtotime("+$i months", strtotime($start_date)));
        $stmt = $db->prepare("INSERT INTO payment_installments (application_id, due_date, amount) VALUES (?, ?, ?)");
        $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);
        $stmt->bindValue(2, $due, SQLITE3_TEXT);
        $stmt->bindValue(3, $installment_amount, SQLITE3_FLOAT);
        $stmt->execute();
    }
}

function calculateLatePenalty($amount, $due_date, $as_of_date = null) {
    if (!$as_of_date) $as_of_date = date('Y-m-d');
    $due = strtotime($due_date);
    $now = strtotime($as_of_date);
    if ($now <= $due) return 0;
    $days = floor(($now - $due) / (60*60*24));
    $months = ceil($days / 30);
    return $amount * 0.02 * $months;
}

// ---------- NOTIFICATION HELPERS ----------
function addNotification($user_id, $application_id, $message, $link = '') {
    $db = getDb();
    $stmt = $db->prepare("INSERT INTO notifications (user_id, application_id, message, link) VALUES (?, ?, ?, ?)");
    $stmt->bindValue(1, $user_id, SQLITE3_INTEGER);
    $stmt->bindValue(2, $application_id, SQLITE3_INTEGER);
    $stmt->bindValue(3, $message, SQLITE3_TEXT);
    $stmt->bindValue(4, $link, SQLITE3_TEXT);
    return $stmt->execute();
}

function getUnreadNotificationCount($user_id) {
    $db = getDb();
    return $db->querySingle("SELECT COUNT(*) FROM notifications WHERE user_id = $user_id AND is_read = 0");
}

function markNotificationsRead($user_id) {
    $db = getDb();
    $db->exec("UPDATE notifications SET is_read = 1 WHERE user_id = $user_id");
}

// ---------- COMMENT HELPERS ----------
function addComment($application_id, $user_id, $comment, $is_admin = 0) {
    $db = getDb();
    $stmt = $db->prepare("INSERT INTO comments (application_id, user_id, comment, is_admin) VALUES (?, ?, ?, ?)");
    $stmt->bindValue(1, $application_id, SQLITE3_INTEGER);
    $stmt->bindValue(2, $user_id, SQLITE3_INTEGER);
    $stmt->bindValue(3, $comment, SQLITE3_TEXT);
    $stmt->bindValue(4, $is_admin, SQLITE3_INTEGER);
    $stmt->execute();
    $comment_id = $db->lastInsertRowID();
    $app = $db->querySingle("SELECT user_id FROM applications WHERE id = $application_id", true);
    if ($app) {
        if ($is_admin) {
            addNotification($app['user_id'], $application_id, "New comment on your application.", "?page=view_application&id=$application_id");
        } else {
            addNotification(1, $application_id, "New comment from client.", "?page=admin&view=$application_id");
        }
    }
    return $comment_id;
}

function getComments($application_id) {
    $db = getDb();
    return $db->query("SELECT c.*, u.username FROM comments c JOIN users u ON c.user_id = u.id WHERE c.application_id = $application_id ORDER BY c.created_at ASC");
}

// ---------- DOCUMENT HELPERS ----------
function uploadDocument($application_id, $user_id, $file, $stage_number = null, $description = '') {
    $target_dir = __DIR__ . '/../uploads/';
    if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '.' . $extension;
    $target_file = $target_dir . $filename;
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        $db = getDb();
        $stmt = $db->prepare("INSERT INTO documents (application_id, user_id, file_name, file_path, stage_number, description) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bindValue(1, $application_id, SQLITE3_INTEGER);
        $stmt->bindValue(2, $user_id, SQLITE3_INTEGER);
        $stmt->bindValue(3, $file['name'], SQLITE3_TEXT);
        $stmt->bindValue(4, $filename, SQLITE3_TEXT);
        $stmt->bindValue(5, $stage_number, SQLITE3_INTEGER);
        $stmt->bindValue(6, $description, SQLITE3_TEXT);
        $stmt->execute();
        return true;
    }
    return false;
}

function getDocuments($application_id) {
    $db = getDb();
    return $db->query("SELECT * FROM documents WHERE application_id = $application_id ORDER BY uploaded_at DESC");
}

// ---------- TIN VERIFICATION (Mock) ----------
function verifyTIN($tin) {
    if (preg_match('/^\d{10}$/', $tin)) {
        return ['valid' => true, 'message' => 'TIN verified.'];
    } else {
        return ['valid' => false, 'message' => 'Invalid TIN format. Must be 10 digits.'];
    }
}