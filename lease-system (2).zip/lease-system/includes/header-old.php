<!--<?php-->
// includes/header.php
<!--if (!defined('BASE_URL')) {-->
<!--    require_once __DIR__ . '/../config.php';-->
<!--}-->
<!--?>-->
<!--<!DOCTYPE html>-->
<!--<html lang="en">-->
<!--<head>-->
<!--    <meta charset="UTF-8">-->
<!--    <meta name="viewport" content="width=device-width, initial-scale=1.0">-->
<!--    <title><?= SITE_NAME ?></title>-->
<!--    <script src="https://cdn.tailwindcss.com"></script>-->
<!--    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">-->
<!--</head>-->
<!--<body class="bg-gray-100">-->
<!--    <header class="bg-white shadow">-->
<!--        <nav class="container mx-auto px-4 py-4 flex flex-wrap justify-between items-center">-->
<!--            <a href="<?= BASE_URL ?>" class="text-xl font-bold text-green-700">SiinQee Lease</a>-->
<!--            <div class="space-x-4">-->
<!--                <a href="<?= BASE_URL ?>" class="text-gray-700 hover:text-green-700">Home</a>-->
<!--                <a href="<?= BASE_URL ?>?page=calculator" class="text-gray-700 hover:text-green-700">Calculator</a>-->
<!--                <a href="<?= BASE_URL ?>?page=market" class="text-gray-700 hover:text-green-700">Market</a>-->
<!--                <a href="<?= BASE_URL ?>?page=track" class="text-gray-700 hover:text-green-700">Track Lease</a>-->
<!--                <a href="<?= BASE_URL ?>?page=about" class="text-gray-700 hover:text-green-700">About</a>-->
<!--                <a href="<?= BASE_URL ?>?page=contact" class="text-gray-700 hover:text-green-700">Contact</a>-->
<!--                <?php if (isset($_SESSION['user_id'])): ?>-->
<!--                    <a href="<?= BASE_URL ?>?page=dashboard" class="text-gray-700 hover:text-green-700">Dashboard</a>-->
<!--                    <a href="<?= BASE_URL ?>?page=logout" class="text-gray-700 hover:text-green-700">Logout</a>-->
<!--                <?php else: ?>-->
<!--                    <a href="<?= BASE_URL ?>?page=login" class="text-gray-700 hover:text-green-700">Login</a>-->
<!--                    <a href="<?= BASE_URL ?>?page=register_client" class="text-gray-700 hover:text-green-700">Client</a>-->
<!--                    <a href="<?= BASE_URL ?>?page=register_vendor" class="text-gray-700 hover:text-green-700">Vendor</a>-->
<!--                <?php endif; ?>-->
<!--            </div>-->
<!--        </nav>-->
<!--    </header>-->
<!--    <main class="container mx-auto px-4 py-8">-->