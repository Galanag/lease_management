<?php
// includes/role_check.php
require_once __DIR__ . '/auth.php';

function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['redirect_after_login'] = $_GET['page'] ?? 'home';
        redirect(BASE_URL . '?page=login');
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) redirect(BASE_URL . '?page=home');
}

function requireBranchStaff() {
    requireLogin();
    if (!isBranchStaff() && !isAdmin()) redirect(BASE_URL . '?page=home');
}