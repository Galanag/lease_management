<?php
// index.php
require_once __DIR__ . '/config.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Define allowed pages (added new admin pages)
$allowed = [
    'home', 'calculator', 'market', 'track', 'about', 'how-it-works', 'contact',
    'login', 'register_client', 'register_vendor', 'logout',
    'profile', 'apply', 'dashboard',
    'vendor_products', 'vendor_product_form', 'vendor_applications',
    'admin_users', 'admin_branches', 'admin_products', 'admin_reports', 'admin_transfer_requests',
    'branch_transfer_accept', 'vendor_view_application', 'admin_view_application', 'admin_user_docs',
    // NEW ADMIN PAGES
    'admin_dashboard', 'admin_application', 'admin_verify_document', 'admin_edit_schedule', 'accept_conditions', 'admin_edit_user', 'admin_applications', 'upload_document', 'admin_edit_product', 'admin_add_application', 'request_transfer', 'export_schedule_pdf'
];

$page = $_GET['page'] ?? 'home';
if (!in_array($page, $allowed)) $page = 'home';

// Handle logout
if ($page === 'logout') {
    session_destroy();
    redirect(BASE_URL . '?page=home');
}

// include 'pages/partials/header.php';

switch ($page) {
    // Public pages
    case 'home': include 'pages/home.php'; break;
    case 'calculator': include 'pages/calculator.php'; break;
    case 'market': include 'pages/market.php'; break;
    case 'track': include 'pages/track.php'; break;
    case 'about': include 'pages/about.php'; break;
    case 'how-it-works': include 'pages/how-it-works.php'; break;
    case 'contact': include 'pages/contact.php'; break;

    // Auth pages
    case 'login': include 'pages/auth/login.php'; break;
    case 'register_client': include 'pages/auth/register_client.php'; break;
    case 'register_vendor': include 'pages/auth/register_vendor.php'; break;

    // Protected pages (require login)
    case 'profile': requireLogin(); include 'pages/profile.php'; break;
    case 'apply': requireLogin(); include 'pages/apply.php'; break;
    
    case 'accept_conditions': requireLogin(); include 'pages/accept_conditions.php'; break;

    // Role‑based dashboard
    case 'dashboard':
        requireLogin();
        if (isAdmin()) {
            // Redirect admin to dedicated admin dashboard? Or show a simple admin view?
            // For now, include a generic admin dashboard (you can create pages/dashboard/admin.php)
            include 'pages/dashboard/admin.php';
        } elseif (isBranchStaff()) {
            include 'pages/dashboard/branch.php';
        } elseif (isVendor()) {
            include 'pages/dashboard/vendor.php';
        } else {
            // Client dashboard (we'll move our new dashboard.php to pages/dashboard/client.php)
            include 'pages/dashboard/client.php';
        }
        break;
        case 'admin_edit_user': requireAdmin(); include 'pages/admin/edit_user.php'; break;
        
        case 'admin_add_application': requireAdmin(); include 'pages/admin/add_application.php'; break;
        
        case 'export_schedule_pdf': requireAdmin(); include 'pages/export_schedule_pdf.php'; break;

    // Vendor pages
    case 'vendor_products': requireLogin(); if (!isVendor()) redirect(BASE_URL.'?page=home'); include 'pages/vendor/products.php'; break;
    case 'vendor_product_form': requireLogin(); if (!isVendor()) redirect(BASE_URL.'?page=home'); include 'pages/vendor/product_form.php'; break;
    case 'vendor_applications': requireLogin(); if (!isVendor()) redirect(BASE_URL.'?page=home'); include 'pages/vendor/applications.php'; break;
    case 'vendor_view_application': requireLogin(); if (!isVendor()) redirect(BASE_URL.'?page=home'); include 'pages/vendor/view_application.php'; break;
    case 'vendor_delete_image': requireVendor(); include 'pages/vendor/delete_image.php'; break;

    // Admin pages (require admin role)
    case 'admin_users': requireAdmin(); include 'pages/admin/users.php'; break;
    case 'admin_branches': requireAdmin(); include 'pages/admin/branches.php'; break;
    case 'admin_products': requireAdmin(); include 'pages/admin/products.php'; break;
    case 'admin_reports': requireAdmin(); include 'pages/admin/reports.php'; break;
    case 'admin_transfer_requests': requireAdmin(); include 'pages/admin/transfer_requests.php'; break;
    case 'admin_view_application': requireAdmin(); include 'pages/admin/view_application.php'; break;
    case 'admin_user_docs': requireAdmin(); include 'pages/admin/user_docs.php'; break;
    case 'admin_applications': requireAdmin(); include 'pages/admin/applications.php'; break;
    case 'upload_document': requireLogin(); include 'pages/upload_document.php'; break;
    
    case 'admin_edit_product': requireAdmin(); include 'pages/admin/edit_product.php'; break;

    // NEW ADMIN PAGES
    case 'admin_dashboard': requireAdmin(); include 'pages/admin/dashboard.php'; break;
    case 'admin_application': requireAdmin(); include 'pages/admin/application.php'; break;
    case 'admin_verify_document': requireAdmin(); include 'pages/admin/verify_document.php'; break;
    case 'admin_edit_schedule': requireAdmin(); include 'pages/admin/edit_schedule.php'; break;

    // Branch staff pages
    case 'branch_transfer_accept': requireBranchStaff(); include 'pages/branch/transfer_accept.php'; break;
    
    case 'request_transfer': requireLogin(); include 'pages/request_transfer.php'; break;

    default: include 'pages/home.php';
}

// include 'pages/partials/footer.php';
?>