<?php
// insert_sample_products.php
require_once 'config.php';

$db = getDb();

// Check if products already exist
$count = $db->querySingle("SELECT COUNT(*) FROM products");
if ($count > 0) {
    echo "Products already exist ($count found). No new products inserted.";
    exit;
}

// Sample product data
$products = [
    ['Tractor', 500000, 'Agriculture', 1, 'approved'],
    ['Excavator', 1200000, 'Construction', 1, 'approved'],
    ['Harvester', 800000, 'Agriculture', 1, 'approved'],
    ['Loader', 600000, 'Construction', 1, 'approved'],
    ['CNC Machine', 1500000, 'Manufacturing', 1, 'approved'],
    ['Generator', 300000, 'Services', 1, 'approved']
];

$stmt = $db->prepare("INSERT INTO products (name, price, sector, available, status) VALUES (?, ?, ?, ?, ?)");
foreach ($products as $p) {
    $stmt->bindValue(1, $p[0], SQLITE3_TEXT);
    $stmt->bindValue(2, $p[1], SQLITE3_FLOAT);
    $stmt->bindValue(3, $p[2], SQLITE3_TEXT);
    $stmt->bindValue(4, $p[3], SQLITE3_INTEGER);
    $stmt->bindValue(5, $p[4], SQLITE3_TEXT);
    $stmt->execute();
}

echo "✅ " . count($products) . " sample products inserted successfully.";