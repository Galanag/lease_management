<?php
// install.php – Run once to set up the database, then DELETE this file.
$db = new SQLite3(__DIR__ . '/database.sqlite');
$db->exec('PRAGMA foreign_keys = ON;');

// ---------- USERS ----------
$db->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'client',
    approved INTEGER DEFAULT 0,
    full_name TEXT,
    gender TEXT,
    birth_date TEXT,
    nationality TEXT,
    national_id TEXT,
    tin TEXT,
    phone TEXT,
    alternative_phone TEXT,
    business_name TEXT,
    business_form TEXT,
    business_reg_number TEXT,
    business_license_number TEXT,
    year_established INTEGER,
    sector TEXT,
    region TEXT,
    zone TEXT,
    woreda TEXT,
    house_number TEXT,
    city TEXT,
    address TEXT,
    trade_name TEXT,
    business_type TEXT,
    country_registration TEXT,
    vat_number TEXT,
    contact_person TEXT,
    position TEXT,
    office_phone TEXT,
    equipment_types TEXT,
    brand_represented TEXT,
    equipment_origin TEXT,
    avg_supply_capacity TEXT,
    installation_service INTEGER DEFAULT 0,
    after_sales_maintenance INTEGER DEFAULT 0,
    spare_parts_supply INTEGER DEFAULT 0,
    operator_training INTEGER DEFAULT 0,
    warranty_provision INTEGER DEFAULT 0,
    warranty_period TEXT,
    bank_name TEXT,
    bank_account_name TEXT,
    bank_account_number TEXT,
    bank_branch TEXT,
    years_supplying INTEGER,
    major_clients TEXT,
    branch_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

// ---------- BRANCHES ----------
$db->exec("CREATE TABLE IF NOT EXISTS branches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    city TEXT,
    address TEXT,
    phone TEXT,
    manager TEXT,
    latitude REAL,
    longitude REAL,
    parent_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(parent_id) REFERENCES branches(id)
)");

// ---------- PRODUCTS ----------
$db->exec("CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    category TEXT,
    description TEXT,
    price DECIMAL(15,2),
    image_url TEXT,
    vendor_id INTEGER,
    status TEXT DEFAULT 'pending',
    available INTEGER DEFAULT 0,
    market_analysis INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(vendor_id) REFERENCES users(id)
)");

// ---------- APPLICATIONS ----------
$db->exec("CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lease_id TEXT UNIQUE,
    user_id INTEGER,
    branch_id INTEGER,
    product_id INTEGER,
    applicant_full_name TEXT,
    applicant_gender TEXT,
    applicant_dob TEXT,
    nationality TEXT,
    applicant_national_id TEXT,
    business_name TEXT,
    business_form TEXT,
    business_reg_number TEXT,
    business_license_number TEXT,
    year_established INTEGER,
    sector TEXT,
    target_status TEXT,
    former_client TEXT,
    preferred_date TEXT,
    comment TEXT,
    equity_amount DECIMAL(15,2),
    total_amount DECIMAL(15,2),
    lease_term INTEGER,
    interest_rate DECIMAL(5,2),
    phone TEXT,
    alternative_phone TEXT,
    email TEXT,
    region TEXT,
    zone TEXT,
    woreda TEXT,
    house_number TEXT,
    tin TEXT,
    business_activity TEXT,
    main_products TEXT,
    num_employees INTEGER,
    annual_revenue DECIMAL(15,2),
    business_location TEXT,
    equipment_supplier TEXT,
    equipment_origin TEXT,
    equipment_quantity INTEGER,
    equipment_installation_location TEXT,
    requested_financing_amount DECIMAL(15,2),
    financing_tenure TEXT,
    proposed_repayment_method TEXT,
    equipment_purpose TEXT,
    expected_production_increase TEXT,
    estimated_annual_income_after DECIMAL(15,2),
    lease_type TEXT,
    applicant_birth_place TEXT,
    marriage_status TEXT,
    total_members_male INTEGER,
    total_members_female INTEGER,
    enterprise_stage TEXT,
    business_status TEXT,
    business_year_registered INTEGER,
    business_type_engaged TEXT,
    machine_name_other TEXT,
    machine_availability TEXT,
    purpose_cg TEXT,
    electric_power_applicant_kw TEXT,
    electric_power_required_kw TEXT,
    working_place_status TEXT,
    raw_materials_availability TEXT,
    key_competitors TEXT,
    area_market_condition TEXT,
    current_asset_cash DECIMAL(15,2),
    fixed_asset_types TEXT,
    fixed_asset_evidences TEXT,
    total_fixed_asset DECIMAL(15,2),
    loan_amount DECIMAL(15,2),
    outstanding_loan DECIMAL(15,2),
    loan_evidences TEXT,
    status TEXT DEFAULT 'Submitted',
    current_stage INTEGER DEFAULT 1,
    admin_comment TEXT,
    confirmed INTEGER DEFAULT 0,
    confirmed_at DATETIME,
    forwarded_to_head_office INTEGER DEFAULT 0,
    forwarded_at DATETIME,
    head_office_notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(branch_id) REFERENCES branches(id),
    FOREIGN KEY(product_id) REFERENCES products(id)
)");

// ---------- STAGES ----------
$db->exec("CREATE TABLE IF NOT EXISTS stages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER,
    stage_number INTEGER,
    stage_name TEXT,
    completed_at DATETIME,
    notes TEXT,
    FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE
)");

// ---------- PAYMENTS ----------
$db->exec("CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER,
    amount DECIMAL(15,2),
    method TEXT,
    transaction_id TEXT,
    status TEXT DEFAULT 'Pending',
    receipt_path TEXT,
    paid_at DATETIME,
    due_date DATE,
    notes TEXT,
    FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE
)");

// ---------- PAYMENT INSTALLMENTS ----------
$db->exec("CREATE TABLE IF NOT EXISTS payment_installments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER,
    due_date DATE,
    amount DECIMAL(15,2),
    status TEXT DEFAULT 'pending',
    payment_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE
)");
$db->exec("CREATE INDEX IF NOT EXISTS idx_installments_due ON payment_installments(due_date)");

// ---------- DOCUMENTS ----------
$db->exec("CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER,
    user_id INTEGER,
    file_name TEXT,
    file_path TEXT,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    stage_number INTEGER,
    description TEXT,
    FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
)");

// ---------- VENDOR DOCUMENTS ----------
$db->exec("CREATE TABLE IF NOT EXISTS vendor_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    file_name TEXT,
    file_path TEXT,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    document_type TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
)");

// ---------- COMMENTS ----------
$db->exec("CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER,
    user_id INTEGER,
    comment TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_admin INTEGER DEFAULT 0,
    FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
)");

// ---------- NOTIFICATIONS ----------
$db->exec("CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    application_id INTEGER,
    message TEXT,
    link TEXT,
    is_read INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE
)");
$db->exec("CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, is_read)");

// ---------- BRANCH TRANSFER REQUESTS ----------
$db->exec("CREATE TABLE IF NOT EXISTS transfer_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER,
    requested_by_user INTEGER,
    from_branch_id INTEGER,
    to_branch_id INTEGER,
    reason TEXT,
    status TEXT DEFAULT 'pending',
    requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    responded_at DATETIME,
    response_notes TEXT,
    FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE,
    FOREIGN KEY(from_branch_id) REFERENCES branches(id),
    FOREIGN KEY(to_branch_id) REFERENCES branches(id)
)");

// ---------- TARIFF TABLES ----------
$db->exec("CREATE TABLE IF NOT EXISTS down_payment_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT,
    rate DECIMAL(5,2),
    description TEXT
)");
$db->exec("CREATE TABLE IF NOT EXISTS application_fees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT,
    fee_amount DECIMAL(15,2)
)");
$db->exec("CREATE TABLE IF NOT EXISTS service_charge_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT,
    term_min INTEGER,
    term_max INTEGER,
    rate DECIMAL(5,2)
)");
$db->exec("CREATE TABLE IF NOT EXISTS repayment_frequencies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT,
    equipment_type TEXT,
    frequency TEXT
)");
$db->exec("CREATE TABLE IF NOT EXISTS cancellation_penalties (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stage TEXT,
    rate DECIMAL(5,2)
)");
$db->exec("CREATE TABLE IF NOT EXISTS rescheduling_fees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_number INTEGER,
    fee_amount DECIMAL(15,2)
)");

// ---------- INSERT DEFAULT DATA ----------
// Branches
$db->exec("INSERT OR IGNORE INTO branches (name, city, address, phone, manager, latitude, longitude) VALUES
    ('Head Office', 'Addis Ababa', 'Bole Sub-city', '+251-11-1234567', 'Alemitu Bekele', 9.0222, 38.7468),
    ('Adama Branch', 'Adama', 'Around Stadium', '+251-22-1234567', 'Merga Yami', 8.5400, 39.2700),
    ('Hawassa Branch', 'Hawassa', 'Piazza', '+251-46-1234567', 'Gemechu Tula', 7.0500, 38.4800)");

// Down payment rates
$db->exec("INSERT OR IGNORE INTO down_payment_rates (sector, rate) VALUES
    ('IMX', 10), ('Manufacturing', 15), ('Agriculture', 20),
    ('Services', 20), ('Construction', 25), ('Employees', 5)");

// Application fees
$db->exec("INSERT OR IGNORE INTO application_fees (sector, fee_amount) VALUES
    ('Agriculture', 1500), ('Manufacturing', 1500), ('Construction', 2000),
    ('Services', 1500), ('IMX', 500)");

// Service charge rates
$db->exec("INSERT OR IGNORE INTO service_charge_rates (sector, term_min, term_max, rate) VALUES
    ('IMX', 1, 2, 20.0), ('IMX', 3, 4, 20.5), ('IMX', 5, 5, 21.5), ('IMX', 6, 7, 22.0),
    ('Agriculture', 1, 2, 20.0), ('Agriculture', 3, 4, 21.5), ('Agriculture', 5, 5, 22.0),
    ('Manufacturing', 1, 2, 20.0), ('Manufacturing', 3, 4, 21.5), ('Manufacturing', 5, 5, 22.0), ('Manufacturing', 6, 7, 22.5),
    ('Services', 1, 2, 20.0), ('Services', 3, 4, 21.5), ('Services', 5, 5, 22.0), ('Services', 6, 7, 22.5),
    ('Construction', 1, 2, 21.0), ('Construction', 3, 4, 21.5), ('Construction', 5, 5, 22.5), ('Construction', 6, 7, 23.0),
    ('Employees', 1, 2, 12.0), ('Employees', 3, 4, 12.5), ('Employees', 5, 5, 13.0), ('Employees', 6, 7, 14.0)");

// Admin user
$admin_pass = password_hash('admin123', PASSWORD_DEFAULT);
$db->exec("INSERT OR IGNORE INTO users (username, email, password, role, approved) VALUES ('admin', 'admin@siinqeelease.com', '$admin_pass', 'admin', 1)");

echo "Database installed successfully. Delete this file now.";