<?php
// create_notifications_table.php
require_once 'config.php';
$db = getDb();
$db->exec("CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    application_id INTEGER,
    message TEXT NOT NULL,
    link TEXT,
    created_at DATETIME,
    read_at DATETIME,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
)");
echo "Notifications table created.";
?>