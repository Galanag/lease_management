<?php
// pages/about.php
$pageTitle = 'About Us';
require_once __DIR__ . '/../config.php';

$db = getDb();

// Fetch branches with their zones (grouped)
$branches = $db->query("
    SELECT b.id, b.name, b.city, 
           GROUP_CONCAT(z.name, ', ') as zones
    FROM branches b
    LEFT JOIN zones z ON b.id = z.branch_id
    GROUP BY b.id
    ORDER BY b.name
");

// Fetch headquarters contact info
$contact = $db->querySingle("SELECT * FROM contact_info WHERE id = 1", true);
if (!$contact) {
    $contact = ['address' => 'Addis Ababa, Ethiopia', 'phone' => '+251 911 234 567', 'manager' => 'John Doe'];
}

// Include header (now using partials)
include __DIR__ . '/../partials/header.php';
?>

<div class="max-w-7xl mx-auto">
    <h1 class="text-3xl font-bold mb-6">About SiinQee Lease</h1>

    <section class="mb-12">
        <h2 class="text-2xl font-semibold mb-4">Our History</h2>
        <p class="mb-4">Oromia Capital Goods Finance Business Share Company was established to address one of the major barriers faced by businesses—limited access to finance due to collateral requirements. The company was founded to provide practical leasing solutions that enable micro, small, and medium enterprises (MSMEs) to acquire essential machinery, vehicles, and other capital goods needed to grow and compete.</p>
        <p class="mb-4">The company began its journey with a paid-up capital of Birr 200 million, established by seven town administrations and one individual shareholder. Over the years, increasing demand for asset-based financing and strong stakeholder commitment have driven steady institutional growth, raising the company’s paid-up capital to Birr 725 million today.</p>
        <p class="mb-4">To strengthen its market presence and build a clear identity in the leasing industry, the company introduced its new market brand, Siinqee Lease Finance. This rebranding reflects the company’s commitment to becoming a trusted leasing partner that supports business expansion through accessible and innovative financing solutions.</p>
        <p class="mb-4">The brand’s logo draws inspiration from the Oromo Headrest, symbolizing stability and support. Its upward-pointing arrow shapes represent growth, progress, and the journey of businesses toward success, while the upper bar reflects the stability and achievement reached through reliable financial partnership.</p>
        <p>Today, Siinqee Lease Finance continues to empower businesses by expanding access to capital goods financing, helping enterprises grow, create jobs, and contribute to sustainable economic development.</p>
    </section>

    <section class="mb-12">
        <h2 class="text-2xl font-semibold mb-4">Our Headquarters</h2>
        <div class="bg-white p-6 rounded shadow">
            <p><strong>Address:</strong> <?= htmlspecialchars($contact['address']) ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($contact['phone']) ?></p>
            <p><strong>Manager:</strong> <?= htmlspecialchars($contact['manager']) ?></p>
        </div>
    </section>

    <section>
        <h2 class="text-2xl font-semibold mb-4">Our Branches</h2>
        <p class="mb-6">We have branches across Ethiopia to serve you better. When you apply, we automatically assign your nearest branch based on your city. You may also request a specific branch – your request will be reviewed by head office.</p>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php while ($branch = $branches->fetchArray(SQLITE3_ASSOC)): ?>
                <div class="bg-white p-5 rounded shadow card-hover">
                    <h3 class="text-xl font-bold text-green-700 mb-2"><?= htmlspecialchars($branch['name']) ?></h3>
                    <?php if ($branch['city']): ?>
                        <p class="text-gray-600 mb-2"><i class="fas fa-map-marker-alt mr-1"></i> <?= htmlspecialchars($branch['city']) ?></p>
                    <?php endif; ?>
                    <?php if (!empty($branch['zones'])): ?>
                        <div class="mt-2">
                            <p class="text-sm font-medium text-gray-700">Service Areas:</p>
                            <ul class="text-sm text-gray-600 list-disc list-inside">
                                <?php
                                $zones = explode(',', $branch['zones']);
                                foreach ($zones as $zone):
                                    $zone = trim($zone);
                                    if ($zone):
                                ?>
                                    <li><?= htmlspecialchars($zone) ?></li>
                                <?php endif; endforeach; ?>
                            </ul>
                        </div>
                    <?php else: ?>
                        <p class="text-sm text-gray-500 mt-2">No specific zones listed.</p>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>
    </section>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>