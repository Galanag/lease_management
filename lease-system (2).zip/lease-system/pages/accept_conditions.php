<?php
// pages/accept_conditions.php
require_once __DIR__ . '/../config.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $app_id = $_POST['application_id'] ?? 0;
    $db = getDb();
    $app = $db->querySingle("SELECT * FROM applications WHERE id = $app_id AND user_id = {$_SESSION['user_id']}", true);
    if ($app && $app['status'] === 'conditional_approved') {
        $db->exec("UPDATE applications SET status = 'approved' WHERE id = $app_id");
        // Notify admins
        $admins = $db->query("SELECT id FROM users WHERE role = 'admin'");
        while ($admin = $admins->fetchArray(SQLITE3_ASSOC)) {
            $db->exec("INSERT INTO notifications (user_id, type, subject, message) VALUES ({$admin['id']}, 'email', 'Conditions Accepted', 'Client accepted conditions for application #$app_id')");
        }
        $_SESSION['success'] = "Conditions accepted. Your application is now fully approved.";
    }
}
redirect(BASE_URL . '?page=dashboard');