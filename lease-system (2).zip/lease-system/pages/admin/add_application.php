<?php
// pages/admin/add_application.php
$pageTitle = 'Add Application';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();

// Fetch all approved clients for dropdown
$clients = $db->query("SELECT id, username, full_name, business_name, email, phone, city, address, tin FROM users WHERE role = 'client' AND approved = 1 ORDER BY full_name");

// Fetch sectors (excluding Employees)
$sectors = $db->query("SELECT sector FROM down_payment_rates WHERE sector != 'Employees' ORDER BY sector");

// Fetch all products (for equipment dropdown)
$allProducts = [];
$productsRes = $db->query("SELECT id, name, price, sector FROM products WHERE available = 1 ORDER BY name");
while ($p = $productsRes->fetchArray(SQLITE3_ASSOC)) {
    $allProducts[] = $p;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_application'])) {
    $errors = [];

    // Get selected client (required)
    $client_id = intval($_POST['client_id'] ?? 0);
    if ($client_id <= 0) {
        $errors[] = 'Please select a client.';
    } else {
        $client = $db->querySingle("SELECT * FROM users WHERE id = $client_id", true);
        if (!$client) $errors[] = 'Client not found.';
    }

    // Personal info (all optional)
    $full_name = trim($_POST['full_name'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $birth_date = $_POST['birth_date'] ?? '';
    $nationality = $_POST['nationality'] ?? '';
    $national_id = trim($_POST['national_id'] ?? '');
    $tin = trim($_POST['tin'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $alternative_phone = trim($_POST['alternative_phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $region = trim($_POST['region'] ?? '');
    $zone = trim($_POST['zone'] ?? '');
    $woreda = trim($_POST['woreda'] ?? '');
    $house_number = trim($_POST['house_number'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $birth_place = trim($_POST['birth_place'] ?? '');
    $marriage_status = $_POST['marriage_status'] ?? '';
    $total_members_male = intval($_POST['total_members_male'] ?? 0);
    $total_members_female = intval($_POST['total_members_female'] ?? 0);

    // Business info (all optional)
    $business_name = trim($_POST['business_name'] ?? '');
    $business_form = $_POST['business_form'] ?? '';
    $enterprise_stage = $_POST['enterprise_stage'] ?? '';
    $business_status = $_POST['business_status'] ?? '';
    $business_reg_number = trim($_POST['business_reg_number'] ?? '');
    $business_license_number = trim($_POST['business_license_number'] ?? '');
    $year_established = $_POST['year_established'] ? intval($_POST['year_established']) : null;
    $business_activity = trim($_POST['business_activity'] ?? '');
    $main_products = trim($_POST['main_products'] ?? '');
    $num_employees = intval($_POST['num_employees'] ?? 0);
    $annual_revenue = floatval($_POST['annual_revenue'] ?? 0);
    $business_location = trim($_POST['business_location'] ?? '');
    $year_registered = $_POST['year_registered'] ? intval($_POST['year_registered']) : null;
    $business_type_engaged = trim($_POST['business_type_engaged'] ?? '');

    // Equipment & financing fields
    $requested_amount = floatval($_POST['requested_amount'] ?? 0);
    $equity_amount = floatval($_POST['equity_amount'] ?? 0);
    $lease_term = intval($_POST['lease_term'] ?? 0);
    $frequency = $_POST['frequency'] ?? 'Monthly';
    $electric_power_applicant = trim($_POST['electric_power_applicant'] ?? '');
    $electric_power_required = trim($_POST['electric_power_required'] ?? '');
    $working_place_status = $_POST['working_place_status'] ?? '';

    // Equipment product handling (optional)
    $product_id = null;
    $other_product_name = null;
    $other_product_price = null;
    $equipment_name = '';

    if (isset($_POST['use_manual']) && $_POST['use_manual'] == '1') {
        $other_product_name = trim($_POST['manual_product_name'] ?? '');
        $other_product_price = floatval($_POST['manual_product_price'] ?? 0);
        $equipment_name = $other_product_name;
        // Only validate if manual fields are provided
        if (!empty($other_product_name) && $other_product_price <= 0) {
            $errors[] = 'Manual product price must be greater than 0.';
        }
    } else {
        $product_id = intval($_POST['product_id'] ?? 0);
        if ($product_id > 0) {
            $product = $db->querySingle("SELECT name, price FROM products WHERE id = $product_id", true);
            if ($product) {
                $equipment_name = $product['name'];
                if ($requested_amount == 0) {
                    $requested_amount = $product['price'];
                }
            }
        }
    }

    // Sector (optional)
    $sector = $_POST['equipment_sector'] ?? '';

    // Determine branch based on selected zone (if any)
    $branch_id = null;
    if (!empty($zone)) {
        $stmt = $db->prepare("SELECT branch_id FROM zones WHERE name = :zone");
        $stmt->bindValue(':zone', $zone, SQLITE3_TEXT);
        $res = $stmt->execute();
        $row = $res->fetchArray(SQLITE3_ASSOC);
        if ($row) {
            $branch_id = $row['branch_id'];
        }
    }
    if (!$branch_id) {
        $crmd = $db->querySingle("SELECT id FROM branches WHERE name = 'CRMD'");
        $branch_id = $crmd ?: $db->querySingle("SELECT id FROM branches LIMIT 1");
    }

    // Only validate financials if sector and amount are provided
    if (!empty($sector) && $requested_amount > 0) {
        $down_rate = getDownPaymentRate($sector);
        $service_rate = getServiceChargeRate($sector, $lease_term);
        if ($down_rate === null || $service_rate === null) {
            $errors[] = 'Unable to determine rates for the selected sector.';
        } else {
            if ($equity_amount < $requested_amount * ($down_rate / 100)) {
                $errors[] = "Down payment must be at least " . formatMoney($requested_amount * $down_rate / 100) . " for the $sector sector.";
            }
        }
        if ($lease_term < 12 || $lease_term > 84) $errors[] = 'Lease term must be between 12 and 84 months.';
        if ($sector == 'Agriculture' && $lease_term > 60) $errors[] = 'Agriculture sector lease term cannot exceed 60 months.';
        $allowedFrequencies = getAllowedFrequencies($sector);
        if (!in_array($frequency, $allowedFrequencies)) {
            $errors[] = "Repayment frequency $frequency is not allowed for the $sector sector.";
        }
    }

    if (empty($errors)) {
        $financed = $requested_amount - $equity_amount;
        $service_charge = $financed * ($service_rate / 100) * ($lease_term / 12);
        $total_repayment = $financed + $service_charge;
        $installment = $total_repayment / ($frequency == 'Monthly' ? $lease_term : ($frequency == 'Quarterly' ? ceil($lease_term / 3) : ceil($lease_term / 6)));

        // Generate lease ID
        $lease_id = 'L-' . date('Ymd') . '-' . rand(1000, 9999);

        $stmt = $db->prepare("INSERT INTO applications (
            lease_id, user_id, branch_id, sector, status, current_stage,
            total_amount, down_payment, financed_amount, service_charge, total_repayment, term_months, frequency,
            applicant_full_name, applicant_gender, applicant_dob, nationality, applicant_national_id, tin,
            phone, alternative_phone, email,
            region, zone, woreda, house_number, city, address,
            applicant_birth_place, marriage_status, total_members_male, total_members_female,
            business_name, business_form, enterprise_stage, business_status,
            business_reg_number, business_license_number, year_established,
            business_activity, main_products, num_employees, annual_revenue, business_location,
            business_year_registered, business_type_engaged,
            electric_power_applicant_kw, electric_power_required_kw, working_place_status,
            equipment_name, other_product_name, other_product_price
        ) VALUES (
            :lease_id, :user_id, :branch_id, :sector, 'pending', 1,
            :total_amount, :down_payment, :financed_amount, :service_charge, :total_repayment, :term_months, :frequency,
            :full_name, :gender, :birth_date, :nationality, :national_id, :tin,
            :phone, :alternative_phone, :email,
            :region, :zone, :woreda, :house_number, :city, :address,
            :birth_place, :marriage_status, :total_members_male, :total_members_female,
            :business_name, :business_form, :enterprise_stage, :business_status,
            :business_reg_number, :business_license_number, :year_established,
            :business_activity, :main_products, :num_employees, :annual_revenue, :business_location,
            :year_registered, :business_type_engaged,
            :electric_power_applicant, :electric_power_required, :working_place_status,
            :equipment_name, :other_product_name, :other_product_price
        )");

        $stmt->bindValue(':lease_id', $lease_id, SQLITE3_TEXT);
        $stmt->bindValue(':user_id', $client_id, SQLITE3_INTEGER);
        $stmt->bindValue(':branch_id', $branch_id, SQLITE3_INTEGER);
        $stmt->bindValue(':sector', $sector, SQLITE3_TEXT);
        $stmt->bindValue(':total_amount', $requested_amount, SQLITE3_FLOAT);
        $stmt->bindValue(':down_payment', $equity_amount, SQLITE3_FLOAT);
        $stmt->bindValue(':financed_amount', $financed, SQLITE3_FLOAT);
        $stmt->bindValue(':service_charge', $service_charge, SQLITE3_FLOAT);
        $stmt->bindValue(':total_repayment', $total_repayment, SQLITE3_FLOAT);
        $stmt->bindValue(':term_months', $lease_term, SQLITE3_INTEGER);
        $stmt->bindValue(':frequency', $frequency, SQLITE3_TEXT);
        $stmt->bindValue(':full_name', $full_name, SQLITE3_TEXT);
        $stmt->bindValue(':gender', $gender, SQLITE3_TEXT);
        $stmt->bindValue(':birth_date', $birth_date, SQLITE3_TEXT);
        $stmt->bindValue(':nationality', $nationality, SQLITE3_TEXT);
        $stmt->bindValue(':national_id', $national_id, SQLITE3_TEXT);
        $stmt->bindValue(':tin', $tin, SQLITE3_TEXT);
        $stmt->bindValue(':phone', $phone, SQLITE3_TEXT);
        $stmt->bindValue(':alternative_phone', $alternative_phone, SQLITE3_TEXT);
        $stmt->bindValue(':email', $email, SQLITE3_TEXT);
        $stmt->bindValue(':region', $region, SQLITE3_TEXT);
        $stmt->bindValue(':zone', $zone, SQLITE3_TEXT);
        $stmt->bindValue(':woreda', $woreda, SQLITE3_TEXT);
        $stmt->bindValue(':house_number', $house_number, SQLITE3_TEXT);
        $stmt->bindValue(':city', $city, SQLITE3_TEXT);
        $stmt->bindValue(':address', $address, SQLITE3_TEXT);
        $stmt->bindValue(':birth_place', $birth_place, SQLITE3_TEXT);
        $stmt->bindValue(':marriage_status', $marriage_status, SQLITE3_TEXT);
        $stmt->bindValue(':total_members_male', $total_members_male, SQLITE3_INTEGER);
        $stmt->bindValue(':total_members_female', $total_members_female, SQLITE3_INTEGER);
        $stmt->bindValue(':business_name', $business_name, SQLITE3_TEXT);
        $stmt->bindValue(':business_form', $business_form, SQLITE3_TEXT);
        $stmt->bindValue(':enterprise_stage', $enterprise_stage, SQLITE3_TEXT);
        $stmt->bindValue(':business_status', $business_status, SQLITE3_TEXT);
        $stmt->bindValue(':business_reg_number', $business_reg_number, SQLITE3_TEXT);
        $stmt->bindValue(':business_license_number', $business_license_number, SQLITE3_TEXT);
        $stmt->bindValue(':year_established', $year_established, SQLITE3_INTEGER);
        $stmt->bindValue(':business_activity', $business_activity, SQLITE3_TEXT);
        $stmt->bindValue(':main_products', $main_products, SQLITE3_TEXT);
        $stmt->bindValue(':num_employees', $num_employees, SQLITE3_INTEGER);
        $stmt->bindValue(':annual_revenue', $annual_revenue, SQLITE3_FLOAT);
        $stmt->bindValue(':business_location', $business_location, SQLITE3_TEXT);
        $stmt->bindValue(':year_registered', $year_registered, SQLITE3_INTEGER);
        $stmt->bindValue(':business_type_engaged', $business_type_engaged, SQLITE3_TEXT);
        $stmt->bindValue(':electric_power_applicant', $electric_power_applicant, SQLITE3_TEXT);
        $stmt->bindValue(':electric_power_required', $electric_power_required, SQLITE3_TEXT);
        $stmt->bindValue(':working_place_status', $working_place_status, SQLITE3_TEXT);
        $stmt->bindValue(':equipment_name', $equipment_name, SQLITE3_TEXT);
        $stmt->bindValue(':other_product_name', $other_product_name, SQLITE3_TEXT);
        $stmt->bindValue(':other_product_price', $other_product_price, SQLITE3_FLOAT);
        $stmt->execute();

        $app_id = $db->lastInsertRowID();

        // Insert initial stage
        $db->exec("INSERT INTO application_stages (application_id, stage_number, stage_name, completed_at) VALUES ($app_id, 1, 'Inquiry Received', datetime('now'))");

        // Notify client
        addNotification($client_id, $app_id, "An application has been created for you. Please check your dashboard.", "?page=view_application&id=$app_id");

        // Notify branch managers and CRMD
        $branchManagers = $db->query("SELECT id FROM users WHERE role = 'branch' AND branch_id = $branch_id");
        while ($bm = $branchManagers->fetchArray(SQLITE3_ASSOC)) {
            addNotification($bm['id'], $app_id, "New application #$lease_id assigned to your branch.", "?page=admin_application&id=$app_id");
        }
        $crmdUsers = $db->query("SELECT id FROM users WHERE role IN ('admin', 'crmd')");
        while ($crmd = $crmdUsers->fetchArray(SQLITE3_ASSOC)) {
            addNotification($crmd['id'], $app_id, "New application #$lease_id added by admin.", "?page=admin_application&id=$app_id");
        }

        $_SESSION['message'] = 'Application added successfully.';
        redirect(BASE_URL . '?page=admin_applications');
    }
}

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8 max-w-4xl">
    <h1 class="text-3xl font-bold mb-6">Add Application (Admin)</h1>
    <p class="text-gray-600 mb-6">Fill in the details below to create a new lease application on behalf of a client. Only the client selection is required; all other fields are optional.</p>

    <?php if (!empty($errors)): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
            <?php foreach ($errors as $err): ?>
                <p><?= htmlspecialchars($err) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" class="bg-white p-6 rounded shadow">
        <!-- Client Selection -->
        <h2 class="text-2xl font-semibold mb-4">Select Client</h2>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Client *</label>
            <select name="client_id" id="client_id" class="w-full border border-gray-300 rounded p-2" required>
                <option value="">-- Select Client --</option>
                <?php while ($c = $clients->fetchArray(SQLITE3_ASSOC)): ?>
                    <option value="<?= $c['id'] ?>" data-fullname="<?= htmlspecialchars($c['full_name'] ?? '') ?>" data-phone="<?= htmlspecialchars($c['phone'] ?? '') ?>" data-email="<?= htmlspecialchars($c['email'] ?? '') ?>" data-city="<?= htmlspecialchars($c['city'] ?? '') ?>" data-address="<?= htmlspecialchars($c['address'] ?? '') ?>" data-tin="<?= htmlspecialchars($c['tin'] ?? '') ?>">
                        <?= htmlspecialchars($c['full_name'] ?? $c['username']) ?> (<?= $c['email'] ?>)
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- Section 1: Personal Information (all fields optional) -->
        <h2 class="text-2xl font-semibold mt-6 mb-4">1. Personal Information</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Full Name</label>
                <input type="text" name="full_name" id="full_name" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Gender</label>
                <select name="gender" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Date of Birth</label>
                <input type="date" name="birth_date" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Nationality</label>
                <input type="text" name="nationality" value="Ethiopian" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">National ID / Passport</label>
                <input type="text" name="national_id" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">TIN Number</label>
                <input type="text" name="tin" id="tin" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Phone</label>
                <input type="text" name="phone" id="phone" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Alternative Phone</label>
                <input type="text" name="alternative_phone" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Email</label>
                <input type="email" name="email" id="email" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Region</label>
                <input type="text" name="region" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Zone / Town</label>
                <select name="zone" id="zone" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select zone/town</option>
                    <?php
                    $zones = $db->query("SELECT DISTINCT name FROM zones ORDER BY name");
                    while ($z = $zones->fetchArray(SQLITE3_ASSOC)):
                    ?>
                        <option value="<?= htmlspecialchars($z['name']) ?>"><?= htmlspecialchars($z['name']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Woreda</label>
                <input type="text" name="woreda" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">House Number</label>
                <input type="text" name="house_number" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">City</label>
                <input type="text" name="city" id="city" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium mb-1">Address</label>
                <textarea name="address" id="address" rows="3" class="w-full border border-gray-300 rounded p-2"></textarea>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div>
                <label class="block text-sm font-medium mb-1">Birth Place</label>
                <input type="text" name="birth_place" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Marriage Status</label>
                <select name="marriage_status" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="Married">Married</option>
                    <option value="Single">Single</option>
                    <option value="Divorced">Divorced</option>
                    <option value="Widowed">Widowed</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Total Members (Male)</label>
                <input type="number" name="total_members_male" min="0" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Total Members (Female)</label>
                <input type="number" name="total_members_female" min="0" class="w-full border border-gray-300 rounded p-2">
            </div>
        </div>

        <!-- Section 2: Business Information (all optional) -->
        <h2 class="text-2xl font-semibold mt-6 mb-4">2. Business Information</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Business / Company Name</label>
                <input type="text" name="business_name" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Business Form</label>
                <select name="business_form" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="IMX">Grouped by Gov’t (IMX)</option>
                    <option value="PLC">PLC</option>
                    <option value="Partnership">Partnership</option>
                    <option value="Sole Proprietorship">Sole Proprietorship</option>
                    <option value="Share Company">Share Company</option>
                    <option value="Cooperative">Cooperative Union</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Enterprise Stage</label>
                <select name="enterprise_stage" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="Start up">Start up</option>
                    <option value="Micro">Micro</option>
                    <option value="Small">Small</option>
                    <option value="Medium">Medium</option>
                    <option value="Large">Large</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Business Status</label>
                <select name="business_status" id="business_status" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="Existing">Existing / In Business</option>
                    <option value="New">New (not yet in business)</option>
                </select>
            </div>
            <div id="existing_business_fields" style="display:none;" class="grid grid-cols-2 gap-4 md:col-span-2">
                <div>
                    <label class="block text-sm font-medium mb-1">Year Registered</label>
                    <input type="number" name="year_registered" min="1900" max="<?= date('Y') ?>" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Type of Business Engaged In</label>
                    <input type="text" name="business_type_engaged" class="w-full border border-gray-300 rounded p-2">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Business Registration Number</label>
                <input type="text" name="business_reg_number" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Business License Number</label>
                <input type="text" name="business_license_number" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Year of Establishment</label>
                <input type="number" name="year_established" min="1900" max="<?= date('Y') ?>" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Type of Business Activity</label>
                <input type="text" name="business_activity" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Main Products / Services</label>
                <input type="text" name="main_products" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Number of Employees</label>
                <input type="number" name="num_employees" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Annual Revenue (Last Year) ETB</label>
                <input type="number" name="annual_revenue" step="0.01" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium mb-1">Business Location</label>
                <input type="text" name="business_location" class="w-full border border-gray-300 rounded p-2">
            </div>
        </div>

        <!-- Section 3: Equipment Requested Info (embedded, all optional) -->
        <h2 class="text-2xl font-semibold mt-6 mb-4">3. Equipment Requested Info</h2>

        <!-- Sector constants info box -->
        <div id="sector-info-box" class="bg-blue-50 p-4 rounded mb-4 hidden">
            <h3 class="font-semibold text-blue-800">Sector Information</h3>
            <div class="grid grid-cols-3 gap-4 mt-2 text-sm">
                <div><strong>Application Fee:</strong> <span id="display-app-fee">-</span></div>
                <div><strong>Minimum Down Payment:</strong> <span id="display-down-payment">-</span>%</div>
                <div><strong>Service Charge Range:</strong> <span id="display-service-charge">-</span></div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Sector</label>
                <select name="equipment_sector" id="equipment_sector" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select sector</option>
                    <?php while ($s = $sectors->fetchArray(SQLITE3_ASSOC)): ?>
                        <option value="<?= $s['sector'] ?>"><?= $s['sector'] ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div id="equipment-field">
                <label class="block text-sm font-medium mb-1">Equipment / Product</label>
                <div id="product-dropdown-container" style="display: block;">
                    <select name="product_id" id="product_select" class="w-full border border-gray-300 rounded p-2">
                        <option value="">Select a product</option>
                        <!-- Options will be filled by JS -->
                    </select>
                </div>
                <div id="manual-product-container" style="display: none;">
                    <input type="text" name="manual_product_name" id="manual_product_name" class="w-full border border-gray-300 rounded p-2" placeholder="Enter product name">
                    <input type="number" name="manual_product_price" id="manual_product_price" step="0.01" class="w-full border border-gray-300 rounded p-2 mt-2" placeholder="Price (ETB)">
                </div>
                <button type="button" id="toggle_manual_btn" class="text-sm text-blue-600 mt-1">Or enter manually</button>
                <p id="equipment-note" class="text-xs text-gray-500 mt-1"></p>
                <input type="hidden" name="use_manual" id="use_manual" value="0">
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div>
                <label class="block text-sm font-medium mb-1">Requested Financing Amount (ETB)</label>
                <input type="number" name="requested_amount" id="price" step="0.01" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Down Payment (Equity) (ETB)</label>
                <input type="number" name="equity_amount" id="down" step="0.01" class="w-full border border-gray-300 rounded p-2">
                <p class="text-xs text-gray-500 mt-1">Minimum: <span id="min_down_display">0</span>% of total</p>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Lease Term (months)</label>
                <select name="lease_term" id="term" class="w-full border border-gray-300 rounded p-2">
                    <?php for ($t=12; $t<=84; $t+=12): ?>
                        <option value="<?= $t ?>"><?= $t/12 ?> year<?= $t>12?'s':'' ?> (<?= $t ?> months)</option>
                    <?php endfor; ?>
                </select>
                <p id="term_note" class="text-xs text-gray-500"></p>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Repayment Frequency</label>
                <select name="frequency" id="freq" class="w-full border border-gray-300 rounded p-2">
                    <option value="Monthly">Monthly</option>
                    <option value="Quarterly">Quarterly</option>
                    <option value="Semi-Annual">Semi-Annual</option>
                </select>
                <p id="freq_note" class="text-xs text-gray-500"></p>
            </div>
        </div>

        <!-- Payment Preview -->
        <div id="payment-preview" class="bg-gray-50 p-4 rounded mt-4" style="display:none;">
            <h3 class="text-lg font-semibold">Estimated Payment</h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2">
                <div><span class="text-sm text-gray-600">Financed Amount:</span><br><span id="preview-financed" class="font-semibold">ETB 0.00</span></div>
                <div><span class="text-sm text-gray-600">Service Fee:</span><br><span id="preview-service-fee" class="font-semibold">ETB 0.00</span></div>
                <div><span class="text-sm text-gray-600">Total Payment:</span><br><span id="preview-total" class="font-semibold">ETB 0.00</span></div>
                <div><span class="text-sm text-gray-600">Installment:</span><br><span id="preview-installment" class="font-semibold">ETB 0.00</span></div>
            </div>
        </div>

        <!-- Additional fields -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div>
                <label class="block text-sm font-medium mb-1">Electric Power Availability (Applicant) (KW/KV)</label>
                <input type="text" name="electric_power_applicant" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Electric Power Required (Machine) (KW/KV)</label>
                <input type="text" name="electric_power_required" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Working Place Status</label>
                <select name="working_place_status" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="Own">Own</option>
                    <option value="Rental">Rental</option>
                    <option value="Investment">Investment</option>
                    <option value="Gov't cluster">Gov’t cluster</option>
                    <option value="Other">Other</option>
                </select>
            </div>
        </div>

        <div class="mt-6">
            <button type="submit" name="add_application" class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg text-lg transition w-full md:w-auto">Add Application</button>
        </div>
    </form>
</div>

<script>
// Client auto‑fill (unchanged)
const clientSelect = document.getElementById('client_id');
if (clientSelect) {
    clientSelect.addEventListener('change', function() {
        const selected = this.options[this.selectedIndex];
        if (this.value) {
            document.getElementById('full_name').value = selected.dataset.fullname || '';
            document.getElementById('phone').value = selected.dataset.phone || '';
            document.getElementById('email').value = selected.dataset.email || '';
            document.getElementById('city').value = selected.dataset.city || '';
            document.getElementById('address').value = selected.dataset.address || '';
            document.getElementById('tin').value = selected.dataset.tin || '';
        } else {
            document.getElementById('full_name').value = '';
            document.getElementById('phone').value = '';
            document.getElementById('email').value = '';
            document.getElementById('city').value = '';
            document.getElementById('address').value = '';
            document.getElementById('tin').value = '';
        }
    });
}

// Business status toggle (unchanged)
document.getElementById('business_status')?.addEventListener('change', function() {
    document.getElementById('existing_business_fields').style.display = this.value === 'Existing' ? 'block' : 'none';
});

// (All the JavaScript for sector constants, service rates, product dropdown, calculations remains the same as before)
// ... (copy the existing JavaScript block from your current file here, it's unchanged)
</script>

<?php include __DIR__ . '/../../partials/footer.php'; ?>