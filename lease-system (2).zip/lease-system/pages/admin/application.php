<?php
// pages/admin/application.php
$pageTitle = 'Application Details';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();
$app_id = $_GET['id'] ?? 0;
$app = $db->querySingle("SELECT a.*, u.full_name, u.email FROM applications a JOIN users u ON a.user_id = u.id WHERE a.id = $app_id", true);
if (!$app) {
    die("Application not found.");
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update application status (including conditional approval)
    if (isset($_POST['update_status'])) {
        $new_status = $_POST['status'];
        $conditions = $_POST['conditions'] ?? '';
        $db->exec("UPDATE applications SET status = '$new_status', conditions = " . ($conditions ? "'$conditions'" : "NULL") . ", updated_at = datetime('now') WHERE id = $app_id");
        if ($new_status === 'conditional_approved') {
            $user_id = $app['user_id'];
            $message = "Your application has been conditionally approved. Please review the conditions on your dashboard.";
            $db->exec("INSERT INTO notifications (user_id, type, subject, message) VALUES ($user_id, 'email', 'Application Update', '$message')");
        }
        $_SESSION['success'] = "Status updated.";
        header("Location: ?page=admin_application&id=$app_id");
        exit;
    }

    // Change branch
    if (isset($_POST['action']) && $_POST['action'] === 'change_branch') {
        $new_branch = intval($_POST['new_branch_id']);
        $db->exec("UPDATE applications SET branch_id = $new_branch WHERE id = $app_id");
        $_SESSION['success'] = "Branch updated.";
        header("Location: ?page=admin_application&id=$app_id");
        exit;
    }

    // Update stage
    if (isset($_POST['update_stage'])) {
        $new_stage = (int)$_POST['current_stage'];
        $db->exec("UPDATE applications SET current_stage = $new_stage, updated_at = datetime('now') WHERE id = $app_id");
        $db->exec("UPDATE application_stages SET status = 'completed', completed_at = datetime('now') WHERE application_id = $app_id AND stage_number = $new_stage");
        $user_id = $app['user_id'];
        $message = "Your application has moved to stage $new_stage.";
        $db->exec("INSERT INTO notifications (user_id, type, subject, message) VALUES ($user_id, 'email', 'Application Update', '$message')");
        $_SESSION['success'] = "Stage updated.";
        header("Location: ?page=admin_application&id=$app_id");
        exit;
    }

    // Schedule site visit
    if (isset($_POST['action']) && $_POST['action'] === 'schedule_visit') {
        $scheduled_date = $_POST['scheduled_date'];
        $staff_id = $_POST['staff_id'] ?: null;
        $notes = $_POST['notes'];
        $db->exec("INSERT INTO site_visits (application_id, scheduled_date, staff_id, notes, status) 
                   VALUES ($app_id, '$scheduled_date', " . ($staff_id ?: 'NULL') . ", '$notes', 'scheduled')");
        $user_id = $app['user_id'];
        $message = "A site visit has been scheduled for your application on $scheduled_date.";
        $db->exec("INSERT INTO notifications (user_id, type, subject, message) VALUES ($user_id, 'email', 'Site Visit Scheduled', '$message')");
        $_SESSION['success'] = "Visit scheduled.";
        header("Location: ?page=admin_application&id=$app_id");
        exit;
    }

    // Update asset procurement
    if (isset($_POST['update_asset'])) {
        $supplier = $_POST['supplier'] ? "'{$_POST['supplier']}'" : "NULL";
        $order_date = $_POST['order_date'] ? "'{$_POST['order_date']}'" : "NULL";
        $expected_delivery = $_POST['expected_delivery'] ? "'{$_POST['expected_delivery']}'" : "NULL";
        $actual_delivery = $_POST['actual_delivery'] ? "'{$_POST['actual_delivery']}'" : "NULL";
        $installation_date = $_POST['installation_date'] ? "'{$_POST['installation_date']}'" : "NULL";
        $status = $_POST['status'] ? "'{$_POST['status']}'" : "'ordered'";
        $notes = $_POST['notes'] ? "'{$_POST['notes']}'" : "NULL";

        $asset = $db->querySingle("SELECT id FROM asset_tracking WHERE application_id = $app_id", true);
        if ($asset) {
            $db->exec("UPDATE asset_tracking SET supplier=$supplier, order_date=$order_date, expected_delivery=$expected_delivery, actual_delivery=$actual_delivery, installation_date=$installation_date, status=$status, notes=$notes WHERE application_id=$app_id");
        } else {
            $db->exec("INSERT INTO asset_tracking (application_id, supplier, order_date, expected_delivery, actual_delivery, installation_date, status, notes) VALUES ($app_id, $supplier, $order_date, $expected_delivery, $actual_delivery, $installation_date, $status, $notes)");
        }
        $_SESSION['success'] = "Asset tracking updated.";
        header("Location: ?page=admin_application&id=$app_id");
        exit;
    }

    // Generate payment schedule
    if (isset($_POST['generate_schedule'])) {
        $financed = $app['financed_amount'];
        $service_rate = 20; // from service_charge_rates
        $term_years = $app['term_months'] / 12;
        $service_charge = $financed * ($service_rate / 100) * $term_years;
        $total_repayment = $financed + $service_charge;
        $installment_count = $app['term_months'];
        $installment_amount = $total_repayment / $installment_count;

        $db->exec("INSERT INTO payment_schedules (application_id, total_financed, total_service_charge, total_repayment, installment_count, frequency)
            VALUES ($app_id, $financed, $service_charge, $total_repayment, $installment_count, '{$app['frequency']}')");
        $schedule_id = $db->lastInsertRowID();

        $due_date = date('Y-m-d', strtotime('+1 month'));
        for ($i = 1; $i <= $installment_count; $i++) {
            $db->exec("INSERT INTO installments (schedule_id, due_date, amount) VALUES ($schedule_id, '$due_date', $installment_amount)");
            $due_date = date('Y-m-d', strtotime($due_date . ' +1 month'));
        }
        $_SESSION['success'] = "Payment schedule generated.";
        header("Location: ?page=admin_application&id=$app_id");
        exit;
    }

    // Edit installments
    if (isset($_POST['edit_installments'])) {
        $inst_id = $_POST['installment_id'];
        $new_amount = $_POST['amount'];
        $db->exec("UPDATE installments SET amount = $new_amount WHERE id = $inst_id");
        $_SESSION['success'] = "Installment updated.";
        header("Location: ?page=admin_application&id=$app_id");
        exit;
    }
}

// Fetch related data
$stages = $db->query("SELECT * FROM application_stages WHERE application_id = $app_id ORDER BY stage_number");
$docs = $db->query("SELECT * FROM documents WHERE application_id = $app_id");
$schedule = $db->querySingle("SELECT * FROM payment_schedules WHERE application_id = $app_id", true);
if ($schedule) {
    $installments = $db->query("SELECT * FROM installments WHERE schedule_id = {$schedule['id']} ORDER BY due_date");
}
$requests = $db->query("SELECT * FROM service_requests WHERE application_id = $app_id ORDER BY created_at DESC");
$visit = $db->querySingle("SELECT * FROM site_visits WHERE application_id = $app_id ORDER BY scheduled_date DESC LIMIT 1", true);
$asset = $db->querySingle("SELECT * FROM asset_tracking WHERE application_id = $app_id", true);

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Application #<?= $app['id'] ?></h1>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Left Column -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Client Info -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Client Information</h2>
                <p><strong>Name:</strong> <?= htmlspecialchars($app['full_name'] ?? '') ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($app['email'] ?? '') ?></p>
                <p><strong>Sector:</strong> <?= htmlspecialchars($app['sector'] ?? '') ?></p>
                <p><strong>Total Amount:</strong> ETB <?= number_format($app['total_amount'] ?? 0, 2) ?></p>
                <p><strong>Down Payment:</strong> ETB <?= number_format($app['down_payment'] ?? 0, 2) ?></p>
            </div>

            <!-- Change Branch -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Change Branch</h2>
                <form method="post">
                    <input type="hidden" name="action" value="change_branch">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">New Branch</label>
                        <select name="new_branch_id" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                            <?php
                            $branches = $db->query("SELECT id, name FROM branches ORDER BY name");
                            while ($b = $branches->fetchArray(SQLITE3_ASSOC)) {
                                $selected = ($app['branch_id'] ?? '') == $b['id'] ? 'selected' : '';
                                echo '<option value="' . $b['id'] . '" ' . $selected . '>' . htmlspecialchars($b['name']) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit" class="mt-2 bg-blue-600 text-white px-4 py-2 rounded">Update Branch</button>
                </form>
            </div>

            <!-- Update Status -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Update Status</h2>
                <form method="post" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Status</label>
                        <select name="status" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                            <option value="inquiry" <?= $app['status']=='inquiry'?'selected':'' ?>>Inquiry</option>
                            <option value="pending" <?= $app['status']=='pending'?'selected':'' ?>>Pending</option>
                            <option value="conditional_approved" <?= $app['status']=='conditional_approved'?'selected':'' ?>>Conditional Approved</option>
                            <option value="approved" <?= $app['status']=='approved'?'selected':'' ?>>Approved</option>
                            <option value="rejected" <?= $app['status']=='rejected'?'selected':'' ?>>Rejected</option>
                        </select>
                    </div>
                    <div id="conditions-field" style="<?= $app['status']=='conditional_approved' ? '' : 'display:none;' ?>">
                        <label class="block text-sm font-medium text-gray-700">Conditions</label>
                        <textarea name="conditions" rows="4" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"><?= htmlspecialchars($app['conditions'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" name="update_status" class="bg-blue-600 text-white px-4 py-2 rounded">Update Status</button>
                </form>
            </div>

            <!-- Update Stage -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Update Stage</h2>
                <form method="post" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Current Stage</label>
                        <select name="current_stage" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                            <?php for ($i=1; $i<=8; $i++): ?>
                                <option value="<?= $i ?>" <?= $i == $app['current_stage'] ? 'selected' : '' ?>><?= $i ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <button type="submit" name="update_stage" class="bg-blue-600 text-white px-4 py-2 rounded">Update Stage</button>
                </form>
            </div>

            <!-- Site Visit -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Site Visit</h2>
                <?php if ($visit): ?>
                    <div class="mb-4">
                        <p><strong>Scheduled:</strong> <?= htmlspecialchars($visit['scheduled_date'] ?? '') ?></p>
                        <p><strong>Status:</strong> <?= ucfirst($visit['status'] ?? '') ?></p>
                        <?php if ($visit['visited_date']): ?>
                            <p><strong>Visited:</strong> <?= htmlspecialchars($visit['visited_date'] ?? '') ?></p>
                        <?php endif; ?>
                        <p><strong>Report:</strong> <?= nl2br(htmlspecialchars($visit['report'] ?? '')) ?></p>
                    </div>
                <?php endif; ?>
                <form method="post" class="space-y-4">
                    <input type="hidden" name="action" value="schedule_visit">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Scheduled Date</label>
                            <input type="date" name="scheduled_date" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Assign Staff</label>
                            <select name="staff_id" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                                <option value="">Select staff</option>
                                <?php
                                $staffs = $db->query("SELECT id, full_name FROM users WHERE role = 'staff'");
                                while ($staff = $staffs->fetchArray(SQLITE3_ASSOC)):
                                ?>
                                <option value="<?= $staff['id'] ?>"><?= htmlspecialchars($staff['full_name']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Notes</label>
                        <textarea name="notes" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"></textarea>
                    </div>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Schedule Visit</button>
                </form>
            </div>

            <!-- Documents -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Documents</h2>
                <table class="min-w-full divide-y">
                    <thead>
                          <tr><th>Type</th><th>File</th><th>Verified</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php while ($doc = $docs->fetchArray(SQLITE3_ASSOC)): ?>
                          <tr>
                             <td><?= htmlspecialchars($doc['document_type'] ?? '') ?></td>
                             <td><a href="<?= BASE_URL . ($doc['file_path'] ?? '') ?>" target="_blank">View</a></td>
                             <td><?= $doc['is_verified'] ? 'Yes' : 'No' ?></td>
                             <td>
                                <?php if (!$doc['is_verified']): ?>
                                    <a href="?page=admin_verify_document&id=<?= $doc['id'] ?>" class="text-green-600 underline">Verify</a>
                                <?php endif; ?>
                             </td>
                          </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <!-- Asset Procurement -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Asset Procurement</h2>
                <form method="post" class="space-y-4">
                    <input type="hidden" name="update_asset" value="1">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Supplier</label>
                            <input type="text" name="supplier" value="<?= htmlspecialchars($asset['supplier'] ?? '') ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Order Date</label>
                            <input type="date" name="order_date" value="<?= $asset['order_date'] ?? '' ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Expected Delivery</label>
                            <input type="date" name="expected_delivery" value="<?= $asset['expected_delivery'] ?? '' ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Actual Delivery</label>
                            <input type="date" name="actual_delivery" value="<?= $asset['actual_delivery'] ?? '' ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Installation Date</label>
                            <input type="date" name="installation_date" value="<?= $asset['installation_date'] ?? '' ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Status</label>
                            <select name="status" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                                <option value="ordered" <?= ($asset['status']??'')=='ordered'?'selected':'' ?>>Ordered</option>
                                <option value="shipped" <?= ($asset['status']??'')=='shipped'?'selected':'' ?>>Shipped</option>
                                <option value="delivered" <?= ($asset['status']??'')=='delivered'?'selected':'' ?>>Delivered</option>
                                <option value="installed" <?= ($asset['status']??'')=='installed'?'selected':'' ?>>Installed</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Notes</label>
                        <textarea name="notes" rows="3" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"><?= htmlspecialchars($asset['notes'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Update Asset Tracking</button>
                </form>
            </div>
        </div>
        
        <!-- Document Upload Section -->
        <div class="bg-white rounded-lg shadow-md p-6 mt-6">
            <h2 class="text-xl font-semibold mb-4">Upload Required Documents</h2>
            <p>Please upload the following documents for this application:</p>
            <ul class="list-disc list-inside mb-4 text-sm">
                <li>TIN Number certificate</li>
                <li>Registered business license (commercial registration)</li>
                <li>Renewed business trade license</li>
                <li>Working premise agreement/site evidence</li>
                <li>Memorandum of association (except sole)</li>
                <li>Marriage or non-marriage evidence (for sole lessee)</li>
                <li>Recent six months Bank Statements</li>
                <li>Residential ID card of members</li>
                <li>Professional license for medical equipment (if applicable)</li>
                <li>Professional license with level for contractors (if applicable)</li>
                <li>Support letter from concerned sector (if IMX)</li>
            </ul>
            <form method="post" enctype="multipart/form-data" action="<?= BASE_URL ?>?page=upload_document">
                <input type="hidden" name="application_id" value="<?= $app_id ?>">
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Document Type</label>
                    <select name="document_type" required class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        <option value="">Select type</option>
                        <option value="tin">TIN Number certificate</option>
                        <option value="business_license">Registered business license</option>
                        <option value="trade_license">Renewed business trade license</option>
                        <option value="premise_agreement">Working premise agreement</option>
                        <option value="memorandum">Memorandum of association</option>
                        <option value="marriage_evidence">Marriage/non-marriage evidence</option>
                        <option value="bank_statement">Bank Statements (6 months)</option>
                        <option value="id_card">Residential ID card of members</option>
                        <option value="professional_license_medical">Professional license (medical)</option>
                        <option value="professional_license_contractor">Professional license (contractor)</option>
                        <option value="support_letter">Support letter (IMX)</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">File</label>
                    <input type="file" name="document_file" required accept=".pdf,.jpg,.png,.jpeg" class="mt-1 block w-full">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Notes (optional)</label>
                    <textarea name="notes" rows="2" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"></textarea>
                </div>
                <button type="submit" name="upload_document" class="bg-blue-600 text-white px-4 py-2 rounded">Upload Document</button>
            </form>
        </div>

        <!-- List of already uploaded documents -->
        <?php
        $uploadedDocs = $db->query("SELECT * FROM application_documents WHERE application_id = $app_id ORDER BY uploaded_at DESC");
        if ($uploadedDocs->numColumns() > 0):
        ?>
        <div class="bg-white rounded-lg shadow-md p-6 mt-6">
            <h2 class="text-xl font-semibold mb-4">Uploaded Documents</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full text-sm">
                    <thead>
                         <tr><th>Type</th><th>File</th><th>Uploaded By</th><th>Date</th><th>Status</th><th>Notes</th></tr>
                    </thead>
                    <tbody>
                        <?php while ($d = $uploadedDocs->fetchArray(SQLITE3_ASSOC)): ?>
                        <tr class="border-t">
                            <td class="px-2 py-2"><?= $d['document_type'] ?></td>
                            <td class="px-2 py-2"><a href="<?= BASE_URL . $d['file_path'] ?>" target="_blank">View</a></td>
                            <td class="px-2 py-2"><?= $db->querySingle("SELECT username FROM users WHERE id = {$d['uploaded_by']}") ?></td>
                            <td class="px-2 py-2"><?= date('Y-m-d H:i', strtotime($d['uploaded_at'])) ?></td>
                            <td class="px-2 py-2"><?= ucfirst($d['status']) ?></td>
                            <td class="px-2 py-2"><?= htmlspecialchars($d['notes'] ?? '') ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- Right Column -->
        <div class="space-y-6">
            <!-- Payment Schedule -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Payment Schedule</h2>
                <?php if ($schedule): ?>
                    <p>Total repayment: ETB <?= number_format($schedule['total_repayment'], 2) ?></p>
                    <p>Installments: <?= $schedule['installment_count'] ?></p>
                    <table class="min-w-full mt-4 text-sm">
                        <thead>
                             <tr><th>Due</th><th>Amount</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                            <?php while ($inst = $installments->fetchArray(SQLITE3_ASSOC)): ?>
                              <tr>
                                 <td><?= $inst['due_date'] ?></td>
                                 <td><?= number_format($inst['amount'], 2) ?></td>
                                 <td><?= ucfirst($inst['status']) ?></td>
                              </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <div class="mt-4">
                        <a href="?page=admin_edit_schedule&id=<?= $schedule['id'] ?>" class="text-blue-600 underline">Edit Schedule</a>
                    </div>
                <?php else: ?>
                    <form method="post">
                        <button type="submit" name="generate_schedule" class="bg-green-600 text-white px-4 py-2 rounded">Generate Payment Schedule</button>
                    </form>
                <?php endif; ?>
            </div>

            <!-- Service Requests -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold mb-4">Service Requests</h2>
                <?php while ($req = $requests->fetchArray(SQLITE3_ASSOC)): ?>
                <div class="border-b py-2">
                    <p class="font-medium"><?= htmlspecialchars($req['subject'] ?? '') ?></p>
                    <p class="text-sm"><?= htmlspecialchars($req['description'] ?? '') ?></p>
                    <p class="text-xs">Status: <?= ucfirst($req['status'] ?? '') ?></p>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelector('select[name="status"]').addEventListener('change', function() {
    document.getElementById('conditions-field').style.display = this.value === 'conditional_approved' ? 'block' : 'none';
});
</script>

<?php include __DIR__ . '/../../partials/footer.php'; ?>