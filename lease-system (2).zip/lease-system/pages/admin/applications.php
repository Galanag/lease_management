<?php
// pages/admin/applications.php
$pageTitle = 'All Applications';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();

// Get filter from URL (status)
$status_filter = $_GET['status'] ?? '';
$where = '';
if ($status_filter && in_array($status_filter, ['pending','approved','rejected','inquiry','conditional_approved'])) {
    $where = "WHERE a.status = '$status_filter'";
}

// Query applications with user and product details
$applications = $db->query("
    SELECT a.*, 
           u.full_name as client_name, 
           u.username,
           p.name as product_name, 
           b.name as branch_name
    FROM applications a
    LEFT JOIN users u ON a.user_id = u.id
    LEFT JOIN products p ON a.product_id = p.id
    LEFT JOIN branches b ON a.branch_id = b.id
    $where
    ORDER BY a.created_at DESC
");

// If the query fails, show an error
if (!$applications) {
    die("Query failed: " . $db->lastErrorMsg());
}

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">All Applications</h1>
    
    <!-- Filter tabs -->
    <div class="flex space-x-2 mb-6">
        <a href="?page=admin_applications" class="px-4 py-2 rounded <?= !$status_filter ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">All</a>
        <a href="?page=admin_applications&status=pending" class="px-4 py-2 rounded <?= $status_filter == 'pending' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Pending</a>
        <a href="?page=admin_applications&status=approved" class="px-4 py-2 rounded <?= $status_filter == 'approved' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Approved</a>
        <a href="?page=admin_applications&status=rejected" class="px-4 py-2 rounded <?= $status_filter == 'rejected' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Rejected</a>
        <a href="?page=admin_applications&status=conditional_approved" class="px-4 py-2 rounded <?= $status_filter == 'conditional_approved' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Conditional</a>
    </div>

    <!-- Applications table -->
    <div class="overflow-x-auto bg-white rounded shadow">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lease ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Branch</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stage</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php if ($applications->numColumns() == 0): ?>
                    <tr>
                        <td colspan="9" class="px-6 py-4 text-center text-gray-500">No applications found.</td>
                    </tr>
                <?php else: ?>
                    <?php while ($app = $applications->fetchArray(SQLITE3_ASSOC)): ?>
                    <tr class="border-t">
                        <td class="px-6 py-4 whitespace-nowrap"><?= $app['id'] ?></td>
                        <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($app['lease_id'] ?? '—') ?></td>
                        <td class="px-6 py-4"><?= htmlspecialchars($app['client_name'] ?? $app['username'] ?? '—') ?></td>
                        <td class="px-6 py-4"><?= htmlspecialchars($app['product_name'] ?? '—') ?></td>
                        <td class="px-6 py-4"><?= htmlspecialchars($app['branch_name'] ?? '—') ?></td>
                        <td class="px-6 py-4">
                            <span class="inline-block px-2 py-1 text-xs rounded 
                                <?= $app['status'] == 'approved' ? 'bg-green-100 text-green-800' : 
                                   ($app['status'] == 'rejected' ? 'bg-red-100 text-red-800' : 
                                   ($app['status'] == 'conditional_approved' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800')) ?>">
                                <?= ucfirst($app['status']) ?>
                            </span>
                        </td>
                        <td class="px-6 py-4"><?= $app['current_stage'] ?>/8</td>
                        <td class="px-6 py-4"><?= date('Y-m-d', strtotime($app['created_at'])) ?></td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <a href="?page=admin_application&id=<?= $app['id'] ?>" class="text-blue-600 hover:underline">View</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>