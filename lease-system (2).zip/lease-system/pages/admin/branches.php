<?php
// pages/admin/branches.php
$pageTitle = 'Manage Branches';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();

// Handle add branch
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_branch'])) {
    $name = trim($_POST['name']);
    $city = trim($_POST['city']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $manager_id = $_POST['manager_id'] ? intval($_POST['manager_id']) : null;
    $latitude = $_POST['latitude'] ? floatval($_POST['latitude']) : null;
    $longitude = $_POST['longitude'] ? floatval($_POST['longitude']) : null;
    $parent_id = $_POST['parent_id'] ? intval($_POST['parent_id']) : null;

    $stmt = $db->prepare("INSERT INTO branches (name, city, address, phone, manager_id, latitude, longitude, parent_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bindValue(1, $name, SQLITE3_TEXT);
    $stmt->bindValue(2, $city, SQLITE3_TEXT);
    $stmt->bindValue(3, $address, SQLITE3_TEXT);
    $stmt->bindValue(4, $phone, SQLITE3_TEXT);
    $stmt->bindValue(5, $manager_id, SQLITE3_INTEGER);
    $stmt->bindValue(6, $latitude, SQLITE3_FLOAT);
    $stmt->bindValue(7, $longitude, SQLITE3_FLOAT);
    $stmt->bindValue(8, $parent_id, SQLITE3_INTEGER);
    $stmt->execute();
    $_SESSION['message'] = 'Branch added.';
    redirect(BASE_URL . '?page=admin_branches');
}

// Handle edit branch
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_branch'])) {
    $id = intval($_POST['id']);
    $name = trim($_POST['name']);
    $city = trim($_POST['city']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $manager_id = $_POST['manager_id'] ? intval($_POST['manager_id']) : null;
    $latitude = $_POST['latitude'] ? floatval($_POST['latitude']) : null;
    $longitude = $_POST['longitude'] ? floatval($_POST['longitude']) : null;
    $parent_id = $_POST['parent_id'] ? intval($_POST['parent_id']) : null;

    $stmt = $db->prepare("UPDATE branches SET name = ?, city = ?, address = ?, phone = ?, manager_id = ?, latitude = ?, longitude = ?, parent_id = ? WHERE id = ?");
    $stmt->bindValue(1, $name, SQLITE3_TEXT);
    $stmt->bindValue(2, $city, SQLITE3_TEXT);
    $stmt->bindValue(3, $address, SQLITE3_TEXT);
    $stmt->bindValue(4, $phone, SQLITE3_TEXT);
    $stmt->bindValue(5, $manager_id, SQLITE3_INTEGER);
    $stmt->bindValue(6, $latitude, SQLITE3_FLOAT);
    $stmt->bindValue(7, $longitude, SQLITE3_FLOAT);
    $stmt->bindValue(8, $parent_id, SQLITE3_INTEGER);
    $stmt->bindValue(9, $id, SQLITE3_INTEGER);
    $stmt->execute();
    $_SESSION['message'] = 'Branch updated.';
    redirect(BASE_URL . '?page=admin_branches');
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $sub = $db->querySingle("SELECT COUNT(*) FROM branches WHERE parent_id = $id");
    $apps = $db->querySingle("SELECT COUNT(*) FROM applications WHERE branch_id = $id");
    if ($sub == 0 && $apps == 0) {
        $db->exec("DELETE FROM branches WHERE id = $id");
        $_SESSION['message'] = 'Branch deleted.';
    } else {
        $_SESSION['error'] = 'Cannot delete branch with sub‑branches or applications.';
    }
    redirect(BASE_URL . '?page=admin_branches');
}

// Fetch branches with manager names
$branches = $db->query("SELECT b.*, p.name as parent_name, u.full_name as manager_name 
                        FROM branches b 
                        LEFT JOIN branches p ON b.parent_id = p.id 
                        LEFT JOIN users u ON b.manager_id = u.id 
                        ORDER BY b.name");

// Fetch all users with role = 'branch' for manager dropdown
$branchStaff = $db->query("SELECT id, full_name, email FROM users WHERE role = 'branch' ORDER BY full_name");

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6"><i class="fas fa-store-alt"></i> Manage Branches</h1>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Add Branch Form -->
        <div class="bg-white p-6 rounded shadow">
            <h2 class="text-xl font-semibold mb-4">Add New Branch</h2>
            <form method="post">
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Branch Name *</label>
                    <input type="text" name="name" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">City *</label>
                    <input type="text" name="city" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Address</label>
                    <input type="text" name="address" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Phone</label>
                    <input type="text" name="phone" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Manager</label>
                    <select name="manager_id" id="manager_id" class="w-full border border-gray-300 rounded p-2">
                        <option value="">— None —</option>
                        <?php while ($s = $branchStaff->fetchArray(SQLITE3_ASSOC)): ?>
                            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['full_name'] ?? $s['email']) ?></option>
                        <?php endwhile; ?>
                    </select>
                    <button type="button" id="addManagerBtn" class="mt-2 text-sm text-blue-600 hover:underline">+ Create New Manager</button>
                </div>
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium mb-1">Latitude</label>
                        <input type="text" name="latitude" class="w-full border border-gray-300 rounded p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium mb-1">Longitude</label>
                        <input type="text" name="longitude" class="w-full border border-gray-300 rounded p-2">
                    </div>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Parent Branch (if sub‑branch)</label>
                    <select name="parent_id" class="w-full border border-gray-300 rounded p-2">
                        <option value="">— None (Top‑level) —</option>
                        <?php
                        $parents = $db->query("SELECT id, name FROM branches ORDER BY name");
                        while ($p = $parents->fetchArray(SQLITE3_ASSOC)) {
                            echo '<option value="' . $p['id'] . '">' . htmlspecialchars($p['name'] ?? '') . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <button type="submit" name="add_branch" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">Add Branch</button>
            </form>
        </div>

        <!-- Branches List -->
        <div class="bg-white rounded shadow overflow-hidden">
            <h2 class="text-xl font-semibold p-4 border-b">Existing Branches</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                           <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">City</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Manager</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Parent</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                           </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php while($b = $branches->fetchArray(SQLITE3_ASSOC)): ?>
                           <tr>
                            <td class="px-6 py-4 whitespace-nowrap"><?= $b['id'] ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($b['name'] ?? '') ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($b['city'] ?? '') ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($b['manager_name'] ?? '—') ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($b['parent_name'] ?? '—') ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <button onclick="editBranch(<?= $b['id'] ?>, '<?= addslashes($b['name'] ?? '') ?>', '<?= addslashes($b['city'] ?? '') ?>', '<?= addslashes($b['address'] ?? '') ?>', '<?= addslashes($b['phone'] ?? '') ?>', '<?= $b['manager_id'] ?? '' ?>', '<?= $b['latitude'] ?? '' ?>', '<?= $b['longitude'] ?? '' ?>', '<?= $b['parent_id'] ?? '' ?>')" class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm mr-2">Edit</button>
                                <a href="?page=admin_branches&delete=<?= $b['id'] ?>" class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm" onclick="return confirm('Delete this branch?')">Delete</a>
                             </td>
                           </tr>
                        <?php endwhile; ?>
                    </tbody>
                 </table>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); background:white; padding:2rem; border-radius:0.5rem; box-shadow:0 10px 25px rgba(0,0,0,0.2); z-index:1000; width:90%; max-width:500px;">
        <h2 class="text-xl font-bold mb-4">Edit Branch</h2>
        <form method="post">
            <input type="hidden" name="id" id="edit_id">
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Branch Name *</label>
                <input type="text" name="name" id="edit_name" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">City *</label>
                <input type="text" name="city" id="edit_city" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Address</label>
                <input type="text" name="address" id="edit_address" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Phone</label>
                <input type="text" name="phone" id="edit_phone" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Manager</label>
                <select name="manager_id" id="edit_manager_id" class="w-full border border-gray-300 rounded p-2">
                    <option value="">— None —</option>
                    <?php
                    $staff = $db->query("SELECT id, full_name, email FROM users WHERE role = 'branch' ORDER BY full_name");
                    while ($s = $staff->fetchArray(SQLITE3_ASSOC)) {
                        echo '<option value="' . $s['id'] . '">' . htmlspecialchars($s['full_name'] ?? $s['email']) . '</option>';
                    }
                    ?>
                </select>
                <button type="button" id="addManagerBtnModal" class="mt-2 text-sm text-blue-600 hover:underline">+ Create New Manager</button>
            </div>
            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Latitude</label>
                    <input type="text" name="latitude" id="edit_latitude" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Longitude</label>
                    <input type="text" name="longitude" id="edit_longitude" class="w-full border border-gray-300 rounded p-2">
                </div>
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Parent Branch</label>
                <select name="parent_id" id="edit_parent_id" class="w-full border border-gray-300 rounded p-2">
                    <option value="">— None —</option>
                    <?php
                    $parents = $db->query("SELECT id, name FROM branches ORDER BY name");
                    while ($p = $parents->fetchArray(SQLITE3_ASSOC)) {
                        echo '<option value="' . $p['id'] . '">' . htmlspecialchars($p['name'] ?? '') . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="flex gap-2">
                <button type="submit" name="edit_branch" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">Update</button>
                <button type="button" onclick="document.getElementById('editModal').style.display='none'" class="bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded">Cancel</button>
            </div>
        </form>
    </div>

    <!-- Modal for Creating New Manager -->
    <div id="newManagerModal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); background:white; padding:2rem; border-radius:0.5rem; box-shadow:0 10px 25px rgba(0,0,0,0.2); z-index:1001; width:90%; max-width:400px;">
        <h2 class="text-xl font-bold mb-4">Create New Manager</h2>
        <form id="newManagerForm">
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Full Name *</label>
                <input type="text" id="new_manager_name" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Email *</label>
                <input type="email" id="new_manager_email" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Phone</label>
                <input type="text" id="new_manager_phone" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Password *</label>
                <input type="password" id="new_manager_password" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="flex gap-2">
                <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">Create</button>
                <button type="button" onclick="document.getElementById('newManagerModal').style.display='none'" class="bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function editBranch(id, name, city, address, phone, managerId, lat, lng, parent) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_city').value = city;
    document.getElementById('edit_address').value = address;
    document.getElementById('edit_phone').value = phone;
    document.getElementById('edit_manager_id').value = managerId;
    document.getElementById('edit_latitude').value = lat;
    document.getElementById('edit_longitude').value = lng;
    document.getElementById('edit_parent_id').value = parent;
    document.getElementById('editModal').style.display = 'block';
}

// Open new manager modal from main form
document.getElementById('addManagerBtn').addEventListener('click', function() {
    document.getElementById('newManagerModal').style.display = 'block';
});
// Open from edit modal
document.getElementById('addManagerBtnModal').addEventListener('click', function() {
    document.getElementById('newManagerModal').style.display = 'block';
});

// Handle new manager creation via AJAX
document.getElementById('newManagerForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const name = document.getElementById('new_manager_name').value;
    const email = document.getElementById('new_manager_email').value;
    const phone = document.getElementById('new_manager_phone').value;
    const password = document.getElementById('new_manager_password').value;

    const response = await fetch('<?= BASE_URL ?>api/create_branch_manager.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, phone, password })
    });
    const result = await response.json();
    if (result.success) {
        // Add new option to both dropdowns
        const newOption = document.createElement('option');
        newOption.value = result.user_id;
        newOption.text = name;
        document.getElementById('manager_id').appendChild(newOption);
        document.getElementById('edit_manager_id').appendChild(newOption.cloneNode(true));
        // Select the new manager
        document.getElementById('manager_id').value = result.user_id;
        document.getElementById('edit_manager_id').value = result.user_id;
        // Close modal
        document.getElementById('newManagerModal').style.display = 'none';
        alert('Manager created successfully.');
    } else {
        alert('Error: ' + result.error);
    }
});
</script>

<?php include __DIR__ . '/../../partials/footer.php'; ?>