<?php
// pages/admin/dashboard.php
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

if (!isLoggedIn() || $_SESSION['user_role'] !== 'admin') {
    redirect(BASE_URL . '?page=login');
}

$db = getDb();
$apps = $db->query("SELECT a.*, u.full_name, u.email FROM applications a JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC");

include __DIR__ . '/../../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Admin Dashboard</h1>

    <div class="bg-white rounded-lg shadow-md p-6">
        <h2 class="text-xl font-semibold mb-4">All Applications</h2>
        <table class="min-w-full divide-y divide-gray-200">
            <thead>
                <tr>
                    <th class="px-4 py-2 text-left">ID</th>
                    <th class="px-4 py-2 text-left">Client</th>
                    <th class="px-4 py-2 text-left">Sector</th>
                    <th class="px-4 py-2 text-left">Status</th>
                    <th class="px-4 py-2 text-left">Stage</th>
                    <th class="px-4 py-2 text-left">Created</th>
                    <th class="px-4 py-2 text-left">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php while ($app = $apps->fetchArray(SQLITE3_ASSOC)): ?>
                <tr>
                    <td class="px-4 py-2"><?= $app['id'] ?></td>
                    <td class="px-4 py-2"><?= htmlspecialchars($app['full_name']) ?></td>
                    <td class="px-4 py-2"><?= $app['sector'] ?></td>
                    <td class="px-4 py-2"><?= ucfirst($app['status']) ?></td>
                    <td class="px-4 py-2"><?= $app['current_stage'] ?>/8</td>
                    <td class="px-4 py-2"><?= date('Y-m-d', strtotime($app['created_at'])) ?></td>
                    <td class="px-4 py-2">
                        <a href="?page=admin_application&id=<?= $app['id'] ?>" class="text-blue-600 underline">View</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>