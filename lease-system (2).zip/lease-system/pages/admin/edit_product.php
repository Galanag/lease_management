<?php
// pages/admin/edit_product.php
$pageTitle = 'Edit Product';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();
$product_id = $_GET['id'] ?? 0;
$product = $db->querySingle("SELECT * FROM products WHERE id = $product_id", true);
if (!$product) {
    die("Product not found.");
}

$sectors = $db->query("SELECT DISTINCT sector FROM down_payment_rates ORDER BY sector");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product'])) {
    $name = trim($_POST['name']);
    $price = floatval($_POST['price']);
    $sector = $_POST['sector'];
    $description = trim($_POST['description']);
    $status = $_POST['status'];
    $available = isset($_POST['available']) ? 1 : 0;

    $stmt = $db->prepare("UPDATE products SET name = ?, price = ?, sector = ?, description = ?, status = ?, available = ? WHERE id = ?");
    $stmt->bindValue(1, $name, SQLITE3_TEXT);
    $stmt->bindValue(2, $price, SQLITE3_FLOAT);
    $stmt->bindValue(3, $sector, SQLITE3_TEXT);
    $stmt->bindValue(4, $description, SQLITE3_TEXT);
    $stmt->bindValue(5, $status, SQLITE3_TEXT);
    $stmt->bindValue(6, $available, SQLITE3_INTEGER);
    $stmt->bindValue(7, $product_id, SQLITE3_INTEGER);
    $stmt->execute();

    $_SESSION['message'] = 'Product updated.';
    redirect(BASE_URL . '?page=admin_products');
}

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8 max-w-2xl">
    <h1 class="text-3xl font-bold mb-6">Edit Product</h1>
    <form method="post" class="bg-white p-6 rounded shadow">
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Product Name *</label>
            <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" required class="w-full border border-gray-300 rounded p-2">
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Price (ETB) *</label>
            <input type="number" name="price" step="0.01" value="<?= $product['price'] ?>" required class="w-full border border-gray-300 rounded p-2">
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Sector *</label>
            <select name="sector" required class="w-full border border-gray-300 rounded p-2">
                <option value="">Select sector</option>
                <?php while ($s = $sectors->fetchArray(SQLITE3_ASSOC)): ?>
                    <option value="<?= $s['sector'] ?>" <?= $product['sector'] == $s['sector'] ? 'selected' : '' ?>><?= $s['sector'] ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Description</label>
            <textarea name="description" rows="4" class="w-full border border-gray-300 rounded p-2"><?= htmlspecialchars($product['description']) ?></textarea>
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Status</label>
            <select name="status" class="w-full border border-gray-300 rounded p-2">
                <option value="pending" <?= $product['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                <option value="approved" <?= $product['status'] == 'approved' ? 'selected' : '' ?>>Approved</option>
                <option value="rejected" <?= $product['status'] == 'rejected' ? 'selected' : '' ?>>Rejected</option>
            </select>
        </div>
        <div class="mb-4">
            <label class="flex items-center gap-2">
                <input type="checkbox" name="available" value="1" <?= $product['available'] ? 'checked' : '' ?>> Available for lease
            </label>
        </div>
        <div class="flex gap-2">
            <button type="submit" name="update_product" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">Update Product</button>
            <a href="?page=admin_products" class="bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded">Cancel</a>
        </div>
    </form>
</div>
<?php include __DIR__ . '/../../partials/footer.php'; ?>