<?php
// pages/admin/edit_schedule.php
require_once __DIR__ . '/../../config.php';

if (!isAdmin()) {
    redirect(BASE_URL . '?page=login');
}

$db = getDb();
$schedule_id = $_GET['id'] ?? 0;
$schedule = $db->querySingle("SELECT * FROM payment_schedules WHERE id = $schedule_id", true);
if (!$schedule) {
    die("Payment schedule not found.");
}
$app_id = $schedule['application_id'];

// Fetch installments
$installments = $db->query("SELECT * FROM installments WHERE schedule_id = $schedule_id ORDER BY due_date");

// Check if any paid installments
$has_paid = $db->querySingle("SELECT COUNT(*) FROM installments WHERE schedule_id = $schedule_id AND status = 'paid'") > 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_schedule'])) {
    if (!$has_paid) {
        // Full edit allowed – delete all and recreate
        $db->exec("DELETE FROM installments WHERE schedule_id = $schedule_id");
        $total_amount = $_POST['total_repayment'];
        $installment_count = $_POST['installment_count'];
        $frequency = $_POST['frequency'];
        $installment_amount = $total_amount / $installment_count;
        $due_date = date('Y-m-d', strtotime('+1 month'));
        for ($i = 1; $i <= $installment_count; $i++) {
            $db->exec("INSERT INTO installments (schedule_id, due_date, amount) VALUES ($schedule_id, '$due_date', $installment_amount)");
            $due_date = date('Y-m-d', strtotime($due_date . ' +1 month'));
        }
        // Update schedule totals
        $db->exec("UPDATE payment_schedules SET total_repayment = $total_amount, installment_count = $installment_count, frequency = '$frequency', modified_at = datetime('now') WHERE id = $schedule_id");
        $_SESSION['success'] = "Payment schedule fully updated.";
    } else {
        // Only future installments can be edited
        $inst_id = $_POST['installment_id'];
        $new_amount = $_POST['amount'];
        $inst = $db->querySingle("SELECT status FROM installments WHERE id = $inst_id", true);
        if ($inst && $inst['status'] != 'paid') {
            $db->exec("UPDATE installments SET amount = $new_amount WHERE id = $inst_id");
            // Recalculate total
            $total = $db->querySingle("SELECT SUM(amount) FROM installments WHERE schedule_id = $schedule_id");
            $db->exec("UPDATE payment_schedules SET total_repayment = $total, modified_at = datetime('now') WHERE id = $schedule_id");
            $_SESSION['success'] = "Installment updated.";
        } else {
            $_SESSION['error'] = "Cannot edit paid installment.";
        }
    }
    header("Location: ?page=admin_application&id=$app_id");
    exit;
}

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Edit Payment Schedule</h1>
    <div class="bg-white rounded-lg shadow-md p-6">
        <?php if ($has_paid): ?>
            <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-4">
                Some installments have been paid. You can only modify future installments.
            </div>
        <?php endif; ?>

        <form method="post">
            <?php if (!$has_paid): ?>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Total Repayment Amount</label>
                    <input type="number" step="0.01" name="total_repayment" value="<?= $schedule['total_repayment'] ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Number of Installments</label>
                    <input type="number" name="installment_count" value="<?= $schedule['installment_count'] ?>" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">Frequency</label>
                    <select name="frequency" class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                        <option value="monthly" <?= $schedule['frequency']=='monthly'?'selected':'' ?>>Monthly</option>
                        <option value="quarterly" <?= $schedule['frequency']=='quarterly'?'selected':'' ?>>Quarterly</option>
                        <option value="semi-annual" <?= $schedule['frequency']=='semi-annual'?'selected':'' ?>>Semi-Annual</option>
                    </select>
                </div>
            <?php endif; ?>

            <h2 class="text-lg font-semibold mt-6 mb-2">Installments</h2>
            <table class="min-w-full divide-y divide-gray-200">
                <thead>
                    <tr>
                        <th class="px-4 py-2 text-left">Due Date</th>
                        <th class="px-4 py-2 text-left">Amount</th>
                        <th class="px-4 py-2 text-left">Status</th>
                        <?php if ($has_paid): ?><th class="px-4 py-2 text-left">Action</th><?php endif; ?>
                     </thead>
                <tbody>
                    <?php while ($inst = $installments->fetchArray(SQLITE3_ASSOC)): ?>
                     <tr>
                        <td class="px-4 py-2"><?= $inst['due_date'] ?>\\
                        <td class="px-4 py-2">ETB <?= number_format($inst['amount'], 2) ?>\\
                        <td class="px-4 py-2"><?= ucfirst($inst['status']) ?>\\
                        <?php if ($has_paid && $inst['status'] != 'paid'): ?>
                        <td class="px-4 py-2">
                            <form method="post" class="inline">
                                <input type="hidden" name="installment_id" value="<?= $inst['id'] ?>">
                                <input type="number" name="amount" step="0.01" value="<?= $inst['amount'] ?>" class="w-24 border border-gray-300 rounded p-1 text-sm">
                                <button type="submit" name="update_schedule" class="text-blue-600 underline text-sm">Update</button>
                            </form>
                         \\
                        <?php elseif ($has_paid): ?>
                        <td class="px-4 py-2">—\\
                        <?php endif; ?>
                     </tr>
                    <?php endwhile; ?>
                </tbody>
             </table>

            <?php if (!$has_paid): ?>
                <div class="mt-6">
                    <button type="submit" name="update_schedule" class="bg-blue-600 text-white px-4 py-2 rounded">Save Full Schedule</button>
                </div>
            <?php endif; ?>
        </form>

        <!-- Export to PDF Button -->
        <div class="mt-6">
            <a href="?page=export_schedule_pdf&id=<?= $schedule_id ?>" target="_blank" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded">Export to PDF</a>
        </div>
        <div class="mt-4">
            <a href="?page=admin_application&id=<?= $app_id ?>" class="text-gray-600 underline">Back to Application</a>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>