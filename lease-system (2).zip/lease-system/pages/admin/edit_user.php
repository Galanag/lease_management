<?php
// pages/admin/edit_user.php
$pageTitle = 'Edit User';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();
$user_id = $_GET['id'] ?? 0;
$user = $db->querySingle("SELECT * FROM users WHERE id = $user_id", true);
if (!$user) {
    die("User not found.");
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $role = $_POST['role'] ?? 'client';
    $approved = isset($_POST['approved']) ? 1 : 0;
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    // Check if username or email has changed
    $usernameChanged = ($username !== $user['username']);
    $emailChanged = ($email !== $user['email']);

    // Basic validation
    if (empty($username)) $error = 'Username is required.';
    elseif (empty($email)) $error = 'Email is required.';
    elseif (empty($full_name)) $error = 'Full name is required.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $error = 'Invalid email format.';
    else {
        // Check uniqueness only if changed
        if ($usernameChanged || $emailChanged) {
            $stmt = $db->prepare("SELECT id FROM users WHERE (username = ? OR email = ?) AND id != ?");
            $stmt->bindValue(1, $username, SQLITE3_TEXT);
            $stmt->bindValue(2, $email, SQLITE3_TEXT);
            $stmt->bindValue(3, $user_id, SQLITE3_INTEGER);
            $res = $stmt->execute();
            if ($res->fetchArray()) {
                $error = 'Username or email already exists.';
            }
        }
    }

    if (empty($error)) {
        // Update user
        if (!empty($password)) {
            if ($password !== $password_confirm) {
                $error = 'Passwords do not match.';
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $db->prepare("UPDATE users SET username = ?, email = ?, full_name = ?, phone = ?, role = ?, approved = ?, password = ? WHERE id = ?");
                $stmt->bindValue(1, $username, SQLITE3_TEXT);
                $stmt->bindValue(2, $email, SQLITE3_TEXT);
                $stmt->bindValue(3, $full_name, SQLITE3_TEXT);
                $stmt->bindValue(4, $phone, SQLITE3_TEXT);
                $stmt->bindValue(5, $role, SQLITE3_TEXT);
                $stmt->bindValue(6, $approved, SQLITE3_INTEGER);
                $stmt->bindValue(7, $hashed, SQLITE3_TEXT);
                $stmt->bindValue(8, $user_id, SQLITE3_INTEGER);
                $stmt->execute();
            }
        } else {
            $stmt = $db->prepare("UPDATE users SET username = ?, email = ?, full_name = ?, phone = ?, role = ?, approved = ? WHERE id = ?");
            $stmt->bindValue(1, $username, SQLITE3_TEXT);
            $stmt->bindValue(2, $email, SQLITE3_TEXT);
            $stmt->bindValue(3, $full_name, SQLITE3_TEXT);
            $stmt->bindValue(4, $phone, SQLITE3_TEXT);
            $stmt->bindValue(5, $role, SQLITE3_TEXT);
            $stmt->bindValue(6, $approved, SQLITE3_INTEGER);
            $stmt->bindValue(7, $user_id, SQLITE3_INTEGER);
            $stmt->execute();
        }

        if (empty($error)) {
            $_SESSION['message'] = 'User updated successfully.';
            redirect(BASE_URL . '?page=admin_users');
        }
    }
}

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8 max-w-2xl">
    <h1 class="text-3xl font-bold mb-6">Edit User</h1>

    <?php if ($error): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" class="bg-white p-6 rounded shadow">
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Username *</label>
            <input type="text" name="username" value="<?= htmlspecialchars($user['username'] ?? '') ?>" required class="w-full border border-gray-300 rounded p-2">
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Email *</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required class="w-full border border-gray-300 rounded p-2">
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Full Name *</label>
            <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name'] ?? '') ?>" required class="w-full border border-gray-300 rounded p-2">
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Phone</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" class="w-full border border-gray-300 rounded p-2">
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Role</label>
            <select name="role" class="w-full border border-gray-300 rounded p-2">
                <option value="client" <?= ($user['role'] ?? '') == 'client' ? 'selected' : '' ?>>Client</option>
                <option value="vendor" <?= ($user['role'] ?? '') == 'vendor' ? 'selected' : '' ?>>Vendor</option>
                <option value="admin" <?= ($user['role'] ?? '') == 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="branch" <?= ($user['role'] ?? '') == 'branch' ? 'selected' : '' ?>>Branch Staff</option>
                <option value="crmd" <?= ($user['role'] ?? '') == 'crmd' ? 'selected' : '' ?>>CRMD</option>
            </select>
        </div>
        <div class="mb-4">
            <label class="flex items-center gap-2">
                <input type="checkbox" name="approved" value="1" <?= ($user['approved'] ?? 0) ? 'checked' : '' ?>> Approved
            </label>
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">New Password (leave blank to keep unchanged)</label>
            <input type="password" name="password" class="w-full border border-gray-300 rounded p-2">
        </div>
        <div class="mb-4">
            <label class="block text-sm font-medium mb-1">Confirm New Password</label>
            <input type="password" name="password_confirm" class="w-full border border-gray-300 rounded p-2">
        </div>
        <div class="flex gap-2">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">Update User</button>
            <a href="?page=admin_users" class="bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded">Cancel</a>
        </div>
    </form>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>