<?php
// pages/admin/products.php
$pageTitle = 'Manage Products';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();

// Handle approval/rejection
if (isset($_GET['approve'])) {
    $id = intval($_GET['approve']);
    $db->exec("UPDATE products SET status = 'approved' WHERE id = $id");
    // Notify vendor
    $product = $db->querySingle("SELECT vendor_id, name FROM products WHERE id = $id", true);
    if ($product) {
        addNotification($product['vendor_id'], 0, "Your product '{$product['name']}' has been approved.", "?page=vendor_products");
    }
    $_SESSION['message'] = 'Product approved.';
    redirect(BASE_URL . '?page=admin_products');
}
if (isset($_GET['reject'])) {
    $id = intval($_GET['reject']);
    $db->exec("UPDATE products SET status = 'rejected' WHERE id = $id");
    $product = $db->querySingle("SELECT vendor_id, name FROM products WHERE id = $id", true);
    if ($product) {
        addNotification($product['vendor_id'], 0, "Your product '{$product['name']}' has been rejected.", "");
    }
    $_SESSION['message'] = 'Product rejected.';
    redirect(BASE_URL . '?page=admin_products');
}
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    // Check if product is used in any applications
    $apps = $db->querySingle("SELECT COUNT(*) FROM applications WHERE product_id = $id");
    if ($apps == 0) {
        // Delete associated images (files and records)
        $images = $db->query("SELECT image_path FROM product_images WHERE product_id = $id");
        while ($img = $images->fetchArray(SQLITE3_ASSOC)) {
            $filepath = __DIR__ . '/../../' . $img['image_path'];
            if (file_exists($filepath)) unlink($filepath);
        }
        $db->exec("DELETE FROM product_images WHERE product_id = $id");
        $db->exec("DELETE FROM products WHERE id = $id");
        $_SESSION['message'] = 'Product deleted.';
    } else {
        $_SESSION['error'] = 'Cannot delete product with linked applications.';
    }
    redirect(BASE_URL . '?page=admin_products');
}

// Filter by status
$status_filter = $_GET['status'] ?? '';
$where = '';
if ($status_filter && in_array($status_filter, ['pending','approved','rejected'])) {
    $where = "WHERE p.status = '$status_filter'";
}

// Fetch products with their first image
$products = $db->query("
    SELECT p.*, u.username as vendor_name,
           (SELECT image_path FROM product_images WHERE product_id = p.id ORDER BY sort_order LIMIT 1) as first_image
    FROM products p 
    LEFT JOIN users u ON p.vendor_id = u.id 
    $where 
    ORDER BY p.created_at DESC
");

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Manage Products</h1>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <!-- Filter tabs -->
    <div class="flex space-x-2 mb-6">
        <a href="?page=admin_products" class="px-4 py-2 rounded <?= !$status_filter ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">All</a>
        <a href="?page=admin_products&status=pending" class="px-4 py-2 rounded <?= $status_filter == 'pending' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Pending</a>
        <a href="?page=admin_products&status=approved" class="px-4 py-2 rounded <?= $status_filter == 'approved' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Approved</a>
        <a href="?page=admin_products&status=rejected" class="px-4 py-2 rounded <?= $status_filter == 'rejected' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Rejected</a>
    </div>

    <div class="overflow-x-auto bg-white rounded shadow">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Vendor</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php while($p = $products->fetchArray(SQLITE3_ASSOC)): ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap"><?= $p['id'] ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <?php if (!empty($p['first_image'])): ?>
                            <img src="<?= BASE_URL . $p['first_image'] ?>" class="w-12 h-12 object-cover rounded">
                        <?php else: ?>
                            <span class="text-gray-400">No image</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4"><?= htmlspecialchars($p['name'] ?? '') ?></td>
                    <td class="px-6 py-4"><?= htmlspecialchars($p['vendor_name'] ?? 'Unknown') ?></td>
                    <td class="px-6 py-4">ETB <?= number_format($p['price'], 2) ?></td>
                    <td class="px-6 py-4">
                        <span class="inline-block px-2 py-1 text-xs rounded 
                            <?= $p['status'] == 'approved' ? 'bg-green-100 text-green-800' : 
                               ($p['status'] == 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800') ?>">
                            <?= ucfirst($p['status']) ?>
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
    <a href="?page=admin_edit_product&id=<?= $p['id'] ?>" class="text-blue-600 hover:underline mr-2">Edit</a>
    <?php if ($p['status'] == 'pending'): ?>
        <a href="?page=admin_products&approve=<?= $p['id'] ?>" class="text-green-600 hover:underline mr-2" onclick="return confirm('Approve this product?')">Approve</a>
        <a href="?page=admin_products&reject=<?= $p['id'] ?>" class="text-red-600 hover:underline mr-2" onclick="return confirm('Reject this product?')">Reject</a>
    <?php endif; ?>
    <a href="?page=admin_products&delete=<?= $p['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Delete this product?')">Delete</a>
</td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>