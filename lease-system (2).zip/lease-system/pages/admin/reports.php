<?php
// pages/admin/reports.php
$pageTitle = 'Reports';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();

// Handle export
if (isset($_GET['export'])) {
    $type = $_GET['export']; // applications, payments, users, vendors
    $format = $_GET['format'] ?? 'csv'; // only csv for now

    if ($type == 'applications') {
        $filename = 'applications_' . date('Ymd') . '.csv';
        $data = $db->query("SELECT a.*, u.username as client_name, p.name as product_name, b.name as branch_name 
                            FROM applications a 
                            JOIN users u ON a.user_id = u.id 
                            JOIN products p ON a.product_id = p.id 
                            JOIN branches b ON a.branch_id = b.id 
                            ORDER BY a.created_at DESC");
        $headers = ['ID','Lease ID','Client','Product','Branch','Status','Stage','Total Amount','Created'];
        $rows = [];
        while ($row = $data->fetchArray(SQLITE3_ASSOC)) {
            $rows[] = [
                $row['id'],
                $row['lease_id'],
                $row['client_name'],
                $row['product_name'],
                $row['branch_name'],
                $row['status'],
                $row['current_stage'],
                $row['total_amount'],
                $row['created_at']
            ];
        }
    } elseif ($type == 'payments') {
        $filename = 'payments_' . date('Ymd') . '.csv';
        $data = $db->query("SELECT p.*, a.lease_id, u.username as client 
                            FROM payments p 
                            JOIN applications a ON p.application_id = a.id 
                            JOIN users u ON a.user_id = u.id 
                            ORDER BY p.paid_at DESC");
        $headers = ['ID','Lease ID','Client','Amount','Method','Status','Date','Notes'];
        $rows = [];
        while ($row = $data->fetchArray(SQLITE3_ASSOC)) {
            $rows[] = [
                $row['id'],
                $row['lease_id'],
                $row['client'],
                $row['amount'],
                $row['method'],
                $row['status'],
                $row['paid_at'],
                $row['notes']
            ];
        }
    } elseif ($type == 'users') {
        $filename = 'users_' . date('Ymd') . '.csv';
        $data = $db->query("SELECT id, username, email, role, approved, created_at FROM users ORDER BY created_at DESC");
        $headers = ['ID','Username','Email','Role','Approved','Created'];
        $rows = [];
        while ($row = $data->fetchArray(SQLITE3_ASSOC)) {
            $rows[] = [
                $row['id'],
                $row['username'] ?? '',
                $row['email'] ?? '',
                $row['role'] ?? '',
                $row['approved'] ? 'Yes' : 'No',
                $row['created_at'] ?? ''
            ];
        }
    } elseif ($type == 'vendors') {
        $filename = 'vendors_' . date('Ymd') . '.csv';
        $data = $db->query("SELECT id, username, email, business_name, approved, created_at FROM users WHERE role='vendor' ORDER BY created_at DESC");
        $headers = ['ID','Username','Email','Business Name','Approved','Created'];
        $rows = [];
        while ($row = $data->fetchArray(SQLITE3_ASSOC)) {
            $rows[] = [
                $row['id'],
                $row['username'] ?? '',
                $row['email'] ?? '',
                $row['business_name'] ?? '',
                $row['approved'] ? 'Yes' : 'No',
                $row['created_at'] ?? ''
            ];
        }
    } else {
        die('Invalid report type');
    }

    // Output CSV
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $output = fopen('php://output', 'w');
    fputcsv($output, $headers);
    foreach ($rows as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

// Counts for display
$appCount = $db->querySingle("SELECT COUNT(*) FROM applications");
$paymentCount = $db->querySingle("SELECT COUNT(*) FROM payments");
$userCount = $db->querySingle("SELECT COUNT(*) FROM users WHERE role != 'admin'");
$vendorCount = $db->querySingle("SELECT COUNT(*) FROM users WHERE role = 'vendor'");

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Reports</h1>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="bg-white rounded shadow p-6 text-center card-hover">
            <i class="fas fa-file-alt fa-3x text-green-600 mb-3"></i>
            <h3 class="text-xl font-semibold mb-2">Applications</h3>
            <p class="text-gray-600 mb-4">Total: <?= $appCount ?></p>
            <a href="?page=admin_reports&export=applications&format=csv" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm transition">Export CSV</a>
        </div>
        <div class="bg-white rounded shadow p-6 text-center card-hover">
            <i class="fas fa-credit-card fa-3x text-green-600 mb-3"></i>
            <h3 class="text-xl font-semibold mb-2">Payments</h3>
            <p class="text-gray-600 mb-4">Total: <?= $paymentCount ?></p>
            <a href="?page=admin_reports&export=payments&format=csv" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm transition">Export CSV</a>
        </div>
        <div class="bg-white rounded shadow p-6 text-center card-hover">
            <i class="fas fa-users fa-3x text-green-600 mb-3"></i>
            <h3 class="text-xl font-semibold mb-2">Users</h3>
            <p class="text-gray-600 mb-4">Total: <?= $userCount ?></p>
            <a href="?page=admin_reports&export=users&format=csv" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm transition">Export CSV</a>
        </div>
        <div class="bg-white rounded shadow p-6 text-center card-hover">
            <i class="fas fa-store fa-3x text-green-600 mb-3"></i>
            <h3 class="text-xl font-semibold mb-2">Vendors</h3>
            <p class="text-gray-600 mb-4">Total: <?= $vendorCount ?></p>
            <a href="?page=admin_reports&export=vendors&format=csv" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm transition">Export CSV</a>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>