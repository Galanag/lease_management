<?php
// pages/admin/transfer_requests.php
$pageTitle = 'Transfer Requests';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();

// Handle approval/rejection
if (isset($_GET['approve'])) {
    $req_id = intval($_GET['approve']);
    $req = $db->querySingle("SELECT * FROM transfer_requests WHERE id = $req_id", true);
    if ($req) {
        // Update request status
        $db->exec("UPDATE transfer_requests SET status = 'accepted', responded_at = datetime('now') WHERE id = $req_id");
        // Actually change the application's branch
        $db->exec("UPDATE applications SET branch_id = {$req['to_branch_id']} WHERE id = {$req['application_id']}");
        // Notify the client
        addNotification($req['requested_by_user'], $req['application_id'], "Your branch transfer request has been approved.", "?page=view_application&id={$req['application_id']}");
        $_SESSION['message'] = 'Transfer approved and application updated.';
    }
    redirect(BASE_URL . '?page=admin_transfer_requests');
}
if (isset($_GET['reject'])) {
    $req_id = intval($_GET['reject']);
    $db->exec("UPDATE transfer_requests SET status = 'rejected', responded_at = datetime('now') WHERE id = $req_id");
    $req = $db->querySingle("SELECT * FROM transfer_requests WHERE id = $req_id", true);
    if ($req) {
        addNotification($req['requested_by_user'], $req['application_id'], "Your branch transfer request has been rejected.", "?page=view_application&id={$req['application_id']}");
    }
    $_SESSION['message'] = 'Transfer rejected.';
    redirect(BASE_URL . '?page=admin_transfer_requests');
}

$requests = $db->query("SELECT r.*, a.lease_id, u.username as requester_name, fb.name as from_branch, tb.name as to_branch
                        FROM transfer_requests r
                        JOIN applications a ON r.application_id = a.id
                        JOIN users u ON r.requested_by_user = u.id
                        JOIN branches fb ON r.from_branch_id = fb.id
                        JOIN branches tb ON r.to_branch_id = tb.id
                        ORDER BY r.created_at DESC");

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Branch Transfer Requests</h1>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
    <?php endif; ?>

    <div class="overflow-x-auto bg-white rounded shadow">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lease ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Requester</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">From Branch</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">To Branch</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reason</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php while($r = $requests->fetchArray(SQLITE3_ASSOC)): ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap"><?= $r['id'] ?>\\
                    <td class="px-6 py-4 whitespace-nowrap"><?= $r['lease_id'] ?>\\
                    <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($r['requester_name'] ?? '') ?>\\
                    <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($r['from_branch'] ?? '') ?>\\
                    <td class="px-6 py-4 whitespace-nowrap"><?= htmlspecialchars($r['to_branch'] ?? '') ?>\\
                    <td class="px-6 py-4"><?= htmlspecialchars($r['reason'] ?? '') ?>\\
                    <td class="px-6 py-4 whitespace-nowrap">
                        <?php if ($r['status'] == 'pending'): ?>
                            <span class="inline-block px-2 py-1 text-xs rounded bg-yellow-100 text-yellow-800">Pending</span>
                        <?php elseif ($r['status'] == 'accepted'): ?>
                            <span class="inline-block px-2 py-1 text-xs rounded bg-green-100 text-green-800">Accepted</span>
                        <?php else: ?>
                            <span class="inline-block px-2 py-1 text-xs rounded bg-red-100 text-red-800">Rejected</span>
                        <?php endif; ?>
                     \\
                    <td class="px-6 py-4 whitespace-nowrap"><?= $r['created_at'] ?>\\
                    <td class="px-6 py-4 whitespace-nowrap">
                        <?php if ($r['status'] == 'pending'): ?>
                            <a href="?page=admin_transfer_requests&approve=<?= $r['id'] ?>" class="text-green-600 hover:underline mr-2" onclick="return confirm('Approve this transfer?')">Approve</a>
                            <a href="?page=admin_transfer_requests&reject=<?= $r['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Reject this transfer?')">Reject</a>
                        <?php else: ?>
                            Done
                        <?php endif; ?>
                     \\
                 \\
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>