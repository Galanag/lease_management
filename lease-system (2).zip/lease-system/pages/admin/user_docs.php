<?php
// pages/admin/user_docs.php
$pageTitle = 'User Documents';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$user_id = intval($_GET['id'] ?? 0);
$db = getDb();

$user = $db->querySingle("SELECT username, email, role FROM users WHERE id = $user_id", true);
if (!$user) {
    $_SESSION['error'] = 'User not found.';
    redirect(BASE_URL . '?page=admin_users');
}

// Handle document deletion
if (isset($_GET['delete_doc'])) {
    $doc_id = intval($_GET['delete_doc']);
    $doc = $db->querySingle("SELECT file_path FROM user_documents WHERE id = $doc_id AND user_id = $user_id", true);
    if ($doc) {
        $file = __DIR__ . '/../../' . $doc['file_path'];
        if (file_exists($file)) unlink($file);
        $db->exec("DELETE FROM user_documents WHERE id = $doc_id");
        $_SESSION['message'] = 'Document deleted.';
    }
    redirect(BASE_URL . '?page=admin_user_docs&id=' . $user_id);
}

// Fetch documents – from both user_documents and vendor_documents tables depending on role
$docs = $db->query("SELECT id, file_name, file_path, uploaded_at, 'user' as source FROM user_documents WHERE user_id = $user_id 
                    UNION ALL 
                    SELECT id, file_name, file_path, uploaded_at, 'vendor' as source FROM vendor_documents WHERE user_id = $user_id 
                    ORDER BY uploaded_at DESC");
?>
<?php include __DIR__ . '/../partials/header.php'; ?>

<main class="container">
    <h1>Documents for <?= htmlspecialchars($user['username']) ?></h1>
    <p><a href="<?= BASE_URL ?>?page=admin_users" class="button secondary">&larr; Back to Users</a></p>

    <?php if (isset($_SESSION['message'])): ?>
        <p class="success"><?= $_SESSION['message'] ?></p>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <?php if (!$docs->numColumns()): ?>
        <p>No documents uploaded by this user.</p>
    <?php else: ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>File Name</th>
                        <th>Source</th>
                        <th>Uploaded</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php while($d = $docs->fetchArray(SQLITE3_ASSOC)): ?>
                    <tr>
                        <td><a href="<?= BASE_URL . $d['file_path'] ?>" target="_blank"><?= htmlspecialchars($d['file_name']) ?></a></td>
                        <td><?= ucfirst($d['source']) ?></td>
                        <td><?= $d['uploaded_at'] ?></td>
                        <td>
                            <a href="?page=admin_user_docs&id=<?= $user_id ?>&delete_doc=<?= $d['id'] ?>" class="btn-small danger" onclick="return confirm('Delete this document?')">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</main>

<style>
.btn-small.danger {
    background: #b91c1c;
    color: white;
    padding: 0.25rem 0.5rem;
    border-radius: 0.25rem;
    text-decoration: none;
}
</style>

<?php include __DIR__ . '/../partials/footer.php'; ?>