<?php
// pages/admin/users.php
$pageTitle = 'Manage Users';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();

// Handle approval (for pending clients/vendors)
if (isset($_GET['approve'])) {
    $id = intval($_GET['approve']);
    $db->exec("UPDATE users SET approved = 1 WHERE id = $id");
    $_SESSION['message'] = 'User approved.';
    redirect(BASE_URL . '?page=admin_users');
}
if (isset($_GET['reject'])) {
    $id = intval($_GET['reject']);
    $db->exec("DELETE FROM users WHERE id = $id");
    $_SESSION['message'] = 'User rejected and removed.';
    redirect(BASE_URL . '?page=admin_users');
}
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $db->exec("DELETE FROM users WHERE id = $id");
    $_SESSION['message'] = 'User deleted.';
    redirect(BASE_URL . '?page=admin_users');
}

$filter = $_GET['role'] ?? '';
$where = '';
if ($filter && in_array($filter, ['client', 'vendor', 'admin', 'branch'])) {
    $where = "WHERE role = '$filter'";
}
$users = $db->query("SELECT * FROM users $where ORDER BY created_at DESC");

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Manage Users</h1>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
    <?php endif; ?>

    <!-- Filter tabs -->
    <div class="flex space-x-2 mb-6">
        <a href="?page=admin_users" class="px-4 py-2 rounded <?= !$filter ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">All</a>
        <a href="?page=admin_users&role=client" class="px-4 py-2 rounded <?= $filter == 'client' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Clients</a>
        <a href="?page=admin_users&role=vendor" class="px-4 py-2 rounded <?= $filter == 'vendor' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Vendors</a>
        <a href="?page=admin_users&role=admin" class="px-4 py-2 rounded <?= $filter == 'admin' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Admins</a>
        <a href="?page=admin_users&role=branch" class="px-4 py-2 rounded <?= $filter == 'branch' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800' ?>">Branch Staff</a>
    </div>

    <div class="overflow-x-auto bg-white rounded shadow">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                  <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Username</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Full Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Approved</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php while ($u = $users->fetchArray(SQLITE3_ASSOC)): ?>
                  <tr>
                    <td class="px-6 py-4 whitespace-nowrap"><?= $u['id'] ?></td>
                    <td class="px-6 py-4"><?= htmlspecialchars($u['username'] ?? '') ?></td>
                    <td class="px-6 py-4"><?= htmlspecialchars($u['full_name'] ?? '') ?></td>
                    <td class="px-6 py-4"><?= htmlspecialchars($u['email'] ?? '') ?></td>
                    <td class="px-6 py-4"><?= htmlspecialchars($u['phone'] ?? '') ?></td>
                    <td class="px-6 py-4"><?= htmlspecialchars($u['role'] ?? '') ?></td>
                    <td class="px-6 py-4">
                        <?php if ($u['approved'] ?? 0): ?>
                            <span class="inline-block px-2 py-1 text-xs rounded bg-green-100 text-green-800">Approved</span>
                        <?php else: ?>
                            <span class="inline-block px-2 py-1 text-xs rounded bg-yellow-100 text-yellow-800">Pending</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <a href="?page=admin_edit_user&id=<?= $u['id'] ?>" class="text-blue-600 hover:underline mr-2">Edit</a>
                        <?php if (!($u['approved'] ?? 0)): ?>
                            <a href="?page=admin_users&approve=<?= $u['id'] ?>" class="text-green-600 hover:underline mr-2" onclick="return confirm('Approve this user?')">Approve</a>
                            <a href="?page=admin_users&reject=<?= $u['id'] ?>" class="text-red-600 hover:underline mr-2" onclick="return confirm('Reject this user?')">Reject</a>
                        <?php endif; ?>
                        <a href="?page=admin_users&delete=<?= $u['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Delete this user?')">Delete</a>
                    </td>
                  </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>