<?php
// pages/admin/verify_document.php
require_once __DIR__ . '/../../config.php';

if (!isAdmin()) {
    redirect(BASE_URL . '?page=login');
}

$db = getDb();
$doc_id = $_GET['id'] ?? 0;
$doc = $db->querySingle("SELECT * FROM documents WHERE id = $doc_id", true);
if (!$doc) {
    die("Document not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify'])) {
    $db->exec("UPDATE documents SET is_verified = 1, verified_by = {$_SESSION['user_id']}, verified_at = datetime('now') WHERE id = $doc_id");
    // Notify client
    $app_id = $doc['application_id'];
    $app = $db->querySingle("SELECT user_id FROM applications WHERE id = $app_id", true);
    if ($app) {
        $db->exec("INSERT INTO notifications (user_id, type, subject, message) VALUES ({$app['user_id']}, 'email', 'Document Verified', 'Your document {$doc['document_type']} has been verified.')");
    }
    $_SESSION['success'] = "Document verified.";
    header("Location: ?page=admin_application&id={$doc['application_id']}");
    exit;
}

include __DIR__ . '/../../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Verify Document</h1>
    <div class="bg-white rounded-lg shadow-md p-6 max-w-lg mx-auto">
        <p><strong>Document:</strong> <?= htmlspecialchars($doc['document_type']) ?></p>
        <p><strong>File:</strong> <a href="<?= BASE_URL . $doc['file_path'] ?>" target="_blank" class="text-blue-600 underline">View</a></p>
        <p><strong>Uploaded:</strong> <?= $doc['uploaded_at'] ?></p>
        <form method="post" class="mt-6">
            <button type="submit" name="verify" class="bg-green-600 text-white px-4 py-2 rounded">Mark as Verified</button>
            <a href="?page=admin_application&id=<?= $doc['application_id'] ?>" class="ml-4 text-gray-600">Cancel</a>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>