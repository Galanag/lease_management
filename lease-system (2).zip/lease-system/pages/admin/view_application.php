<?php
// pages/admin/view_application.php
$pageTitle = 'Application Details';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$app_id = intval($_GET['id'] ?? 0);
$db = getDb();

$app = $db->querySingle("SELECT a.*, u.username, u.email, p.name as product_name, b.name as branch_name 
                         FROM applications a 
                         JOIN users u ON a.user_id = u.id 
                         JOIN products p ON a.product_id = p.id 
                         JOIN branches b ON a.branch_id = b.id 
                         WHERE a.id = $app_id", true);
if (!$app) {
    $_SESSION['error'] = 'Application not found.';
    redirect(BASE_URL . '?page=admin');
}

// Handle status/stage update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_app'])) {
    $status = $_POST['status'];
    $stage_name = $_POST['stage'];
    $admin_comment = $_POST['admin_comment'];
    $equity = floatval($_POST['equity_amount']);
    $total = floatval($_POST['total_amount']);
    $term = intval($_POST['lease_term']);
    $rate = floatval($_POST['interest_rate']);

    $stage_map = [
        'Inquiry' => 1, 'Application' => 2, 'Assessment' => 3, 'Approval' => 4,
        'Contract' => 5, 'Procurement' => 6, 'Delivery' => 7, 'Active' => 8
    ];
    $stage = $stage_map[$stage_name] ?? 1;

    $stmt = $db->prepare("UPDATE applications SET status = ?, current_stage = ?, admin_comment = ?, equity_amount = ?, total_amount = ?, lease_term = ?, interest_rate = ?, updated_at = datetime('now') WHERE id = ?");
    $stmt->bindValue(1, $status, SQLITE3_TEXT);
    $stmt->bindValue(2, $stage, SQLITE3_INTEGER);
    $stmt->bindValue(3, $admin_comment, SQLITE3_TEXT);
    $stmt->bindValue(4, $equity, SQLITE3_FLOAT);
    $stmt->bindValue(5, $total, SQLITE3_FLOAT);
    $stmt->bindValue(6, $term, SQLITE3_INTEGER);
    $stmt->bindValue(7, $rate, SQLITE3_FLOAT);
    $stmt->bindValue(8, $app_id, SQLITE3_INTEGER);
    $stmt->execute();

    // Insert stage history
    $db->exec("INSERT INTO stages (application_id, stage_number, stage_name, completed_at) 
               SELECT $app_id, $stage, '$stage_name', datetime('now')
               WHERE NOT EXISTS (SELECT 1 FROM stages WHERE application_id = $app_id AND stage_number = $stage)");

    // If status becomes Active, generate installments if needed
    if ($status == 'Active') {
        $existing = $db->querySingle("SELECT COUNT(*) FROM payment_installments WHERE application_id = $app_id");
        if ($existing == 0 && $term > 0 && $total > 0) {
            generateLeaseInstallments($app_id, $app['sector'], $total, $term, $rate, $app['proposed_repayment_method']);
        }
    }

    // Notify client
    addNotification($app['user_id'], $app_id, "Your application status changed to $status.", "?page=view_application&id=$app_id");

    $_SESSION['message'] = 'Application updated.';
    redirect(BASE_URL . '?page=admin_view_application&id=' . $app_id);
}

// Handle comment addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_comment'])) {
    $comment = $_POST['comment'];
    addComment($app_id, $_SESSION['user_id'], $comment, 1);
    $_SESSION['message'] = 'Comment added.';
    redirect(BASE_URL . '?page=admin_view_application&id=' . $app_id);
}

// Handle document upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_doc'])) {
    if (uploadDocument($app_id, $_SESSION['user_id'], $_FILES['document'], $_POST['stage'], $_POST['description'])) {
        $_SESSION['message'] = 'Document uploaded.';
    } else {
        $_SESSION['error'] = 'Upload failed.';
    }
    redirect(BASE_URL . '?page=admin_view_application&id=' . $app_id);
}

// Fetch related data
$comments = getComments($app_id);
$documents = getDocuments($app_id);
$installments = $db->query("SELECT * FROM payment_installments WHERE application_id = $app_id ORDER BY due_date");

// Fetch transfer requests for this application
$transfers = $db->query("SELECT r.*, fb.name as from_branch, tb.name as to_branch 
                         FROM transfer_requests r 
                         JOIN branches fb ON r.from_branch_id = fb.id 
                         JOIN branches tb ON r.to_branch_id = tb.id 
                         WHERE r.application_id = $app_id 
                         ORDER BY r.requested_at DESC");

// Fetch shareholders, management, etc.
$shareholders = $db->query("SELECT * FROM application_shareholders WHERE application_id = $app_id");
$management = $db->query("SELECT * FROM application_management WHERE application_id = $app_id");
$assets = $db->query("SELECT * FROM application_assets WHERE application_id = $app_id");
$liabilities = $db->query("SELECT * FROM application_liabilities WHERE application_id = $app_id");
$collateral = $db->query("SELECT * FROM application_collateral WHERE application_id = $app_id");
$banking = $db->query("SELECT * FROM application_banking WHERE application_id = $app_id");
?>
<?php include __DIR__ . '/../partials/header.php'; ?>

<main class="container">
    <h1>Application Details</h1>
    <p><a href="<?= BASE_URL ?>?page=admin" class="button secondary">&larr; Back to Admin</a></p>

    <?php if (isset($_SESSION['message'])) echo "<p class='success'>".$_SESSION['message']."</p>"; unset($_SESSION['message']); ?>
    <?php if (isset($_SESSION['error'])) echo "<p class='error'>".$_SESSION['error']."</p>"; unset($_SESSION['error']); ?>

    <!-- Application Summary -->
    <div class="application-card">
        <h2>Lease #<?= $app['lease_id'] ?></h2>
        <div class="details-grid">
            <!-- Client Info -->
            <div class="detail-section">
                <h3>Client</h3>
                <p><strong>Name:</strong> <?= htmlspecialchars($app['username']) ?></p>
                <p><strong>Email:</strong> <?= $app['email'] ?></p>
                <p><strong>Business:</strong> <?= htmlspecialchars($app['business_name']) ?></p>
            </div>
            <!-- Product & Financing -->
            <div class="detail-section">
                <h3>Product & Financing</h3>
                <p><strong>Product:</strong> <?= htmlspecialchars($app['product_name']) ?></p>
                <p><strong>Value:</strong> <?= formatMoney($app['total_amount']) ?></p>
                <p><strong>Down Payment:</strong> <?= formatMoney($app['equity_amount']) ?></p>
                <p><strong>Term:</strong> <?= $app['lease_term'] ?> months</p>
                <p><strong>Rate:</strong> <?= $app['interest_rate'] ?>%</p>
            </div>
            <!-- Branch & Status -->
            <div class="detail-section">
                <h3>Branch & Status</h3>
                <p><strong>Branch:</strong> <?= htmlspecialchars($app['branch_name']) ?></p>
                <p><strong>Status:</strong> <?= $app['status'] ?></p>
                <p><strong>Stage:</strong> <?= getStageName($app['current_stage']) ?></p>
            </div>
        </div>

        <!-- Eligibility Fields (abridged) – you can expand as needed -->
        <div class="details-grid">
            <div class="detail-section">
                <h3>Eligibility</h3>
                <p><strong>Birth Place:</strong> <?= htmlspecialchars($app['applicant_birth_place'] ?? 'N/A') ?></p>
                <p><strong>Marriage:</strong> <?= htmlspecialchars($app['marriage_status'] ?? 'N/A') ?></p>
                <p><strong>Members:</strong> M:<?= $app['total_members_male'] ?> F:<?= $app['total_members_female'] ?></p>
                <p><strong>Enterprise Stage:</strong> <?= htmlspecialchars($app['enterprise_stage'] ?? 'N/A') ?></p>
            </div>
        </div>

        <!-- Progress Bar -->
        <div class="progress-container">
            <div class="progress-bar">
                <?php $progress = ($app['current_stage'] / 8) * 100; ?>
                <div class="progress-fill" style="width: <?= $progress ?>%;"></div>
            </div>
            <div class="stage-labels">
                <?php $stages = ['Inquiry','Application','Assessment','Approval','Contract','Procurement','Delivery','Active']; ?>
                <?php foreach ($stages as $i => $name): ?>
                    <span class="<?= ($i+1 <= $app['current_stage']) ? 'completed' : '' ?>"><?= $name ?></span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Transfer Requests -->
    <?php if ($transfers->numColumns()): ?>
    <h2>Transfer Requests</h2>
    <table class="table">
        <thead><tr><th>From</th><th>To</th><th>Reason</th><th>Status</th><th>Requested</th></tr></thead>
        <tbody>
        <?php while($t = $transfers->fetchArray(SQLITE3_ASSOC)): ?>
            <tr>
                <td><?= htmlspecialchars($t['from_branch']) ?></td>
                <td><?= htmlspecialchars($t['to_branch']) ?></td>
                <td><?= htmlspecialchars($t['reason']) ?></td>
                <td><?= ucfirst($t['status']) ?></td>
                <td><?= $t['requested_at'] ?></td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <!-- Payment Installments -->
    <h2>Payment Installments</h2>
    <?php if ($installments->numColumns()): ?>
        <table class="table">
            <thead><tr><th>Due Date</th><th>Amount</th><th>Status</th></tr></thead>
            <tbody>
            <?php while($i = $installments->fetchArray(SQLITE3_ASSOC)): ?>
                <tr>
                    <td><?= $i['due_date'] ?></td>
                    <td><?= formatMoney($i['amount']) ?></td>
                    <td><?= ucfirst($i['status']) ?></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No installments generated.</p>
    <?php endif; ?>

    <!-- Comments -->
    <h2>Comments</h2>
    <div class="comments-section">
        <?php while($c = $comments->fetchArray(SQLITE3_ASSOC)): ?>
            <div class="comment <?= $c['is_admin'] ? 'admin-comment' : '' ?>">
                <strong><?= htmlspecialchars($c['username']) ?></strong> <small><?= $c['created_at'] ?></small>
                <p><?= nl2br(htmlspecialchars($c['comment'])) ?></p>
            </div>
        <?php endwhile; ?>
    </div>
    <form method="post">
        <div class="form-group">
            <label>Add Comment</label>
            <textarea name="comment" rows="3" required></textarea>
        </div>
        <button type="submit" name="add_comment">Post Comment</button>
    </form>

    <!-- Documents -->
    <h2>Documents</h2>
    <div class="documents-list">
        <?php while($d = $documents->fetchArray(SQLITE3_ASSOC)): ?>
            <div class="document-item">
                <a href="<?= BASE_URL . $d['file_path'] ?>" target="_blank"><?= htmlspecialchars($d['file_name']) ?></a>
                <small>Uploaded at stage <?= $d['stage_number'] ?: 'N/A' ?></small>
                <p><?= htmlspecialchars($d['description']) ?></p>
            </div>
        <?php endwhile; ?>
    </div>
    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="app_id" value="<?= $app_id ?>">
        <div class="form-group">
            <label>Upload Document</label>
            <input type="file" name="document" required>
        </div>
        <div class="form-group">
            <label>Stage (optional)</label>
            <input type="number" name="stage" min="1" max="8">
        </div>
        <div class="form-group">
            <label>Description</label>
            <input type="text" name="description">
        </div>
        <button type="submit" name="upload_doc">Upload</button>
    </form>

    <!-- Edit Application Form -->
    <h2>Edit Application</h2>
    <form method="post" class="edit-form">
        <input type="hidden" name="app_id" value="<?= $app_id ?>">
        <div class="form-row">
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option <?= $app['status']=='Submitted'?'selected':'' ?>>Submitted</option>
                    <option <?= $app['status']=='Under Review'?'selected':'' ?>>Under Review</option>
                    <option <?= $app['status']=='Approved'?'selected':'' ?>>Approved</option>
                    <option <?= $app['status']=='Rejected'?'selected':'' ?>>Rejected</option>
                    <option <?= $app['status']=='Active'?'selected':'' ?>>Active</option>
                    <option <?= $app['status']=='Completed'?'selected':'' ?>>Completed</option>
                </select>
            </div>
            <div class="form-group">
                <label>Stage</label>
                <select name="stage" required>
                    <?php
                    $stage_opts = ['Inquiry','Application','Assessment','Approval','Contract','Procurement','Delivery','Active'];
                    $current_stage_name = getStageName($app['current_stage']);
                    foreach ($stage_opts as $opt):
                    ?>
                    <option value="<?= $opt ?>" <?= $opt == $current_stage_name ? 'selected' : '' ?>><?= $opt ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>Admin Comment</label>
            <textarea name="admin_comment"><?= htmlspecialchars($app['admin_comment']) ?></textarea>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Equity Amount</label>
                <input type="number" name="equity_amount" value="<?= $app['equity_amount'] ?>" step="0.01">
            </div>
            <div class="form-group">
                <label>Total Amount</label>
                <input type="number" name="total_amount" value="<?= $app['total_amount'] ?>" step="0.01">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Lease Term (months)</label>
                <input type="number" name="lease_term" value="<?= $app['lease_term'] ?>" min="1">
            </div>
            <div class="form-group">
                <label>Service Rate (%)</label>
                <input type="number" name="interest_rate" value="<?= $app['interest_rate'] ?>" step="0.1">
            </div>
        </div>
        <button type="submit" name="update_app">Update Application</button>
    </form>
</main>

<style>
.details-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
    margin: 1rem 0;
}
.detail-section {
    background: #f8fafc;
    padding: 1rem;
    border-radius: 0.5rem;
}
.progress-container {
    margin: 2rem 0;
}
.progress-bar {
    background: #e2e8f0;
    height: 0.75rem;
    border-radius: 1rem;
    overflow: hidden;
}
.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #059669 0%, #10b981 100%);
}
.stage-labels {
    display: flex;
    justify-content: space-between;
    font-size: 0.75rem;
    margin-top: 0.25rem;
}
.stage-labels span.completed {
    color: #059669;
    font-weight: 600;
}
.comments-section {
    max-height: 300px;
    overflow-y: auto;
    border: 1px solid #e2e8f0;
    padding: 1rem;
    border-radius: 0.5rem;
    background: #f8fafc;
    margin: 1rem 0;
}
.comment {
    margin-bottom: 1rem;
    padding-bottom: 0.5rem;
    border-bottom: 1px dashed #cbd5e1;
}
.comment.admin-comment {
    background: #e0f2fe;
    padding: 0.5rem;
    border-radius: 0.5rem;
}
.documents-list {
    margin: 1rem 0;
}
.document-item {
    background: #f1f5f9;
    padding: 0.5rem;
    margin-bottom: 0.5rem;
    border-radius: 0.25rem;
}
.table {
    width: 100%;
    border-collapse: collapse;
    margin: 1rem 0;
}
.table th {
    background: #e2e8f0;
    padding: 0.5rem;
    text-align: left;
}
.table td {
    padding: 0.5rem;
    border-bottom: 1px solid #cbd5e1;
}
</style>

<?php include __DIR__ . '/../partials/footer.php'; ?>