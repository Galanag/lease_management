<!--<?php-->
// pages/apply.php
<!--$pageTitle = 'Apply for Lease';-->
<!--require_once __DIR__ . '/../includes/config.php';-->

<!--if (!isLoggedIn()) {-->
<!--    $_SESSION['redirect_after_login'] = 'apply';-->
<!--    redirect(BASE_URL . '?page=login');-->
<!--}-->

<!--$db = getDb();-->
<!--$user_id = $_SESSION['user_id'];-->
<!--$user = $db->querySingle("SELECT * FROM users WHERE id = $user_id", true);-->
<!--$branches = $db->query("SELECT * FROM branches ORDER BY name");-->
<!--$products = $db->query("SELECT id, name, price, sector FROM products WHERE available = 1 ORDER BY name");-->
<!--$sectors = $db->query("SELECT DISTINCT sector FROM down_payment_rates ORDER BY sector");-->

// Determine default branch based on user's city
<!--$defaultBranchId = null;-->
<!--$defaultBranchInfo = null;-->
<!--if (!empty($user['city'])) {-->
<!--    $stmt = $db->prepare("SELECT id, name, city FROM branches WHERE city = ? COLLATE NOCASE LIMIT 1");-->
<!--    $stmt->bindValue(1, $user['city'], SQLITE3_TEXT);-->
<!--    $res = $stmt->execute();-->
<!--    if ($row = $res->fetchArray(SQLITE3_ASSOC)) {-->
<!--        $defaultBranchId = $row['id'];-->
<!--        $defaultBranchInfo = $row;-->
<!--    }-->
<!--}-->

<!--$branchesAll = $db->query("SELECT * FROM branches ORDER BY name");-->

// Handle form submission
<!--if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply'])) {-->
<!--    $lease_id = generateLeaseId();-->
<!--    $sector = $_POST['sector'] ?? '';-->
<!--    $price = floatval($_POST['total_amount'] ?? 0);-->
<!--    $down = floatval($_POST['equity_amount'] ?? 0);-->
<!--    $term = intval($_POST['lease_term'] ?? 0);-->
<!--    $rate = getServiceChargeRate($sector, $term);-->
<!--    $errors = [];-->

    // Validate down payment
<!--    $minRate = getDownPaymentRate($sector);-->
<!--    $minDown = $price * $minRate / 100;-->
<!--    if ($down < $minDown) {-->
<!--        $errors[] = "Down payment must be at least " . formatMoney($minDown) . " for the $sector sector.";-->
<!--    }-->
<!--    if ($sector == 'Agriculture' && $term > 60) {-->
<!--        $errors[] = "Agriculture sector lease term cannot exceed 60 months.";-->
<!--    }-->
<!--    if ($term > 84) {-->
<!--        $errors[] = "Maximum lease term is 84 months.";-->
<!--    }-->
<!--    if ($rate <= 0) {-->
<!--        $errors[] = "Could not determine service rate. Please recalculate.";-->
<!--    }-->

<!--    if (empty($errors)) {-->
<!--        $db->exec('BEGIN');-->

        // Insert main application with all fields
<!--        $stmt = $db->prepare("INSERT INTO applications (-->
<!--            lease_id, user_id, branch_id, product_id,-->
<!--            applicant_full_name, applicant_gender, applicant_dob, nationality, applicant_national_id,-->
<!--            business_name, business_form, business_reg_number, business_license_number, year_established,-->
<!--            sector, target_status, former_client, preferred_date, comment,-->
<!--            equity_amount, total_amount, lease_term, interest_rate,-->
<!--            phone, alternative_phone, email,-->
<!--            region, zone, woreda, house_number,-->
<!--            tin, business_activity, main_products, num_employees, annual_revenue, business_location,-->
<!--            equipment_supplier, equipment_origin, equipment_quantity, equipment_installation_location,-->
<!--            requested_financing_amount, financing_tenure, proposed_repayment_method,-->
<!--            equipment_purpose, expected_production_increase, estimated_annual_income_after,-->
<!--            lease_type,-->
<!--            applicant_birth_place, marriage_status, total_members_male, total_members_female,-->
<!--            enterprise_stage, business_status, business_year_registered, business_type_engaged,-->
<!--            machine_name_other, machine_availability,-->
<!--            purpose_cg, electric_power_applicant_kw, electric_power_required_kw,-->
<!--            working_place_status, raw_materials_availability,-->
<!--            key_competitors, area_market_condition,-->
<!--            current_asset_cash, fixed_asset_types, fixed_asset_evidences, total_fixed_asset,-->
<!--            loan_amount, outstanding_loan, loan_evidences-->
<!--        ) VALUES (-->
<!--            :lease_id, :user_id, :branch_id, :product_id,-->
<!--            :applicant_full_name, :applicant_gender, :applicant_dob, :nationality, :applicant_national_id,-->
<!--            :business_name, :business_form, :business_reg_number, :business_license_number, :year_established,-->
<!--            :sector, :target_status, :former_client, :preferred_date, :comment,-->
<!--            :equity_amount, :total_amount, :lease_term, :interest_rate,-->
<!--            :phone, :alternative_phone, :email,-->
<!--            :region, :zone, :woreda, :house_number,-->
<!--            :tin, :business_activity, :main_products, :num_employees, :annual_revenue, :business_location,-->
<!--            :equipment_supplier, :equipment_origin, :equipment_quantity, :equipment_installation_location,-->
<!--            :requested_financing_amount, :financing_tenure, :proposed_repayment_method,-->
<!--            :equipment_purpose, :expected_production_increase, :estimated_annual_income_after,-->
<!--            :lease_type,-->
<!--            :applicant_birth_place, :marriage_status, :total_members_male, :total_members_female,-->
<!--            :enterprise_stage, :business_status, :business_year_registered, :business_type_engaged,-->
<!--            :machine_name_other, :machine_availability,-->
<!--            :purpose_cg, :electric_power_applicant_kw, :electric_power_required_kw,-->
<!--            :working_place_status, :raw_materials_availability,-->
<!--            :key_competitors, :area_market_condition,-->
<!--            :current_asset_cash, :fixed_asset_types, :fixed_asset_evidences, :total_fixed_asset,-->
<!--            :loan_amount, :outstanding_loan, :loan_evidences-->
<!--        )");-->

        // Bind all parameters
<!--        $stmt->bindValue(':lease_id', $lease_id, SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);-->
<!--        $branch_id = $defaultBranchId ?: intval($_POST['branch_id']);-->
<!--        $stmt->bindValue(':branch_id', $branch_id, SQLITE3_INTEGER);-->
<!--        $stmt->bindValue(':product_id', $_POST['product_id'], SQLITE3_INTEGER);-->
<!--        $stmt->bindValue(':applicant_full_name', $_POST['applicant_full_name'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':applicant_gender', $_POST['applicant_gender'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':applicant_dob', $_POST['applicant_dob'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':nationality', $_POST['nationality'] ?? 'Ethiopian', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':applicant_national_id', $_POST['applicant_national_id'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':business_name', $_POST['business_name'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':business_form', $_POST['business_form'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':business_reg_number', $_POST['business_reg_number'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':business_license_number', $_POST['business_license_number'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':year_established', $_POST['year_established'] ? intval($_POST['year_established']) : null, SQLITE3_INTEGER);-->
<!--        $stmt->bindValue(':sector', $sector, SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':target_status', $_POST['target_status'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':former_client', $_POST['former_client'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':preferred_date', $_POST['preferred_date'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':comment', $_POST['comment'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':equity_amount', $down, SQLITE3_FLOAT);-->
<!--        $stmt->bindValue(':total_amount', $price, SQLITE3_FLOAT);-->
<!--        $stmt->bindValue(':lease_term', $term, SQLITE3_INTEGER);-->
<!--        $stmt->bindValue(':interest_rate', $rate, SQLITE3_FLOAT);-->
<!--        $stmt->bindValue(':phone', $_POST['phone'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':alternative_phone', $_POST['alternative_phone'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':email', $_POST['email'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':region', $_POST['region'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':zone', $_POST['zone'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':woreda', $_POST['woreda'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':house_number', $_POST['house_number'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':tin', $_POST['tin'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':business_activity', $_POST['business_activity'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':main_products', $_POST['main_products'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':num_employees', intval($_POST['num_employees'] ?? 0), SQLITE3_INTEGER);-->
<!--        $stmt->bindValue(':annual_revenue', floatval($_POST['annual_revenue'] ?? 0), SQLITE3_FLOAT);-->
<!--        $stmt->bindValue(':business_location', $_POST['business_location'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':equipment_supplier', $_POST['equipment_supplier'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':equipment_origin', $_POST['equipment_origin'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':equipment_quantity', intval($_POST['equipment_quantity'] ?? 1), SQLITE3_INTEGER);-->
<!--        $stmt->bindValue(':equipment_installation_location', $_POST['equipment_installation_location'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':requested_financing_amount', floatval($_POST['requested_financing_amount'] ?? 0), SQLITE3_FLOAT);-->
<!--        $stmt->bindValue(':financing_tenure', $_POST['financing_tenure'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':proposed_repayment_method', $_POST['proposed_repayment_method'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':equipment_purpose', $_POST['equipment_purpose'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':expected_production_increase', $_POST['expected_production_increase'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':estimated_annual_income_after', floatval($_POST['estimated_annual_income_after'] ?? 0), SQLITE3_FLOAT);-->
<!--        $stmt->bindValue(':lease_type', $_POST['lease_type'] ?? 'financial', SQLITE3_TEXT);-->
        // New eligibility fields
<!--        $stmt->bindValue(':applicant_birth_place', $_POST['applicant_birth_place'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':marriage_status', $_POST['marriage_status'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':total_members_male', intval($_POST['total_members_male'] ?? 0), SQLITE3_INTEGER);-->
<!--        $stmt->bindValue(':total_members_female', intval($_POST['total_members_female'] ?? 0), SQLITE3_INTEGER);-->
<!--        $stmt->bindValue(':enterprise_stage', $_POST['enterprise_stage'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':business_status', $_POST['business_status'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':business_year_registered', intval($_POST['business_year_registered'] ?? 0), SQLITE3_INTEGER);-->
<!--        $stmt->bindValue(':business_type_engaged', $_POST['business_type_engaged'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':machine_name_other', $_POST['machine_name_other'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':machine_availability', $_POST['machine_availability'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':purpose_cg', $_POST['purpose_cg'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':electric_power_applicant_kw', $_POST['electric_power_applicant_kw'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':electric_power_required_kw', $_POST['electric_power_required_kw'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':working_place_status', $_POST['working_place_status'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':raw_materials_availability', $_POST['raw_materials_availability'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':key_competitors', $_POST['key_competitors'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':area_market_condition', $_POST['area_market_condition'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':current_asset_cash', floatval($_POST['current_asset_cash'] ?? 0), SQLITE3_FLOAT);-->
<!--        $stmt->bindValue(':fixed_asset_types', $_POST['fixed_asset_types'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':fixed_asset_evidences', $_POST['fixed_asset_evidences'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->bindValue(':total_fixed_asset', floatval($_POST['total_fixed_asset'] ?? 0), SQLITE3_FLOAT);-->
<!--        $stmt->bindValue(':loan_amount', floatval($_POST['loan_amount'] ?? 0), SQLITE3_FLOAT);-->
<!--        $stmt->bindValue(':outstanding_loan', floatval($_POST['outstanding_loan'] ?? 0), SQLITE3_FLOAT);-->
<!--        $stmt->bindValue(':loan_evidences', $_POST['loan_evidences'] ?? '', SQLITE3_TEXT);-->
<!--        $stmt->execute();-->
<!--        $app_id = $db->lastInsertRowID();-->
        
        // Handle branch option: if user selected a different branch, create a transfer request
<!--if (isset($_POST['branch_option']) && $_POST['branch_option'] === 'other' && !empty($_POST['requested_branch_id'])) {-->
<!--    $requested_branch_id = intval($_POST['requested_branch_id']);-->
<!--    $reason = trim($_POST['branch_request_reason'] ?? '');-->
    // The current branch is either the default one or the manually selected one from earlier.
    // In your code, $branch_id is set to $defaultBranchId ?: intval($_POST['branch_id']).
    // Use that same variable as the from_branch.
    $current_branch = $branch_id; // this should already hold the assigned branch
    

<!--    $stmt = $db->prepare("INSERT INTO transfer_requests (application_id, requested_by_user, from_branch_id, to_branch_id, reason) VALUES (?, ?, ?, ?, ?)");-->
<!--    $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);-->
<!--    $stmt->bindValue(2, $user_id, SQLITE3_INTEGER);-->
<!--    $stmt->bindValue(3, $current_branch, SQLITE3_INTEGER);-->
<!--    $stmt->bindValue(4, $requested_branch_id, SQLITE3_INTEGER);-->
<!--    $stmt->bindValue(5, $reason, SQLITE3_TEXT);-->
<!--    $stmt->execute();-->

    // Notify admin
<!--    addNotification(1, $app_id, "Client requested branch transfer for application #$app_id", "?page=admin_transfer_requests");-->
<!--}-->

        // Insert shareholders (dynamic table)
<!--        if (isset($_POST['shareholder_name'])) {-->
<!--            for ($i = 0; $i < count($_POST['shareholder_name']); $i++) {-->
<!--                if (empty($_POST['shareholder_name'][$i])) continue;-->
<!--                $stmt = $db->prepare("INSERT INTO application_shareholders (application_id, name, position, ownership_percent, national_id_tin) VALUES (?, ?, ?, ?, ?)");-->
<!--                $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);-->
<!--                $stmt->bindValue(2, $_POST['shareholder_name'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(3, $_POST['shareholder_position'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(4, floatval($_POST['shareholder_percent'][$i]), SQLITE3_FLOAT);-->
<!--                $stmt->bindValue(5, $_POST['shareholder_national_id'][$i], SQLITE3_TEXT);-->
<!--                $stmt->execute();-->
<!--            }-->
<!--        }-->

        // Insert management
<!--        if (isset($_POST['management_name'])) {-->
<!--            for ($i = 0; $i < count($_POST['management_name']); $i++) {-->
<!--                if (empty($_POST['management_name'][$i])) continue;-->
<!--                $stmt = $db->prepare("INSERT INTO application_management (application_id, name, position, qualification, experience) VALUES (?, ?, ?, ?, ?)");-->
<!--                $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);-->
<!--                $stmt->bindValue(2, $_POST['management_name'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(3, $_POST['management_position'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(4, $_POST['management_qualification'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(5, $_POST['management_experience'][$i], SQLITE3_TEXT);-->
<!--                $stmt->execute();-->
<!--            }-->
<!--        }-->

        // Insert assets
<!--        if (isset($_POST['asset_description'])) {-->
<!--            for ($i = 0; $i < count($_POST['asset_description']); $i++) {-->
<!--                if (empty($_POST['asset_description'][$i])) continue;-->
<!--                $stmt = $db->prepare("INSERT INTO application_assets (application_id, description, estimated_value) VALUES (?, ?, ?)");-->
<!--                $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);-->
<!--                $stmt->bindValue(2, $_POST['asset_description'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(3, floatval($_POST['asset_value'][$i]), SQLITE3_FLOAT);-->
<!--                $stmt->execute();-->
<!--            }-->
<!--        }-->

        // Insert liabilities
<!--        if (isset($_POST['liability_description'])) {-->
<!--            for ($i = 0; $i < count($_POST['liability_description']); $i++) {-->
<!--                if (empty($_POST['liability_description'][$i])) continue;-->
<!--                $stmt = $db->prepare("INSERT INTO application_liabilities (application_id, description, amount) VALUES (?, ?, ?)");-->
<!--                $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);-->
<!--                $stmt->bindValue(2, $_POST['liability_description'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(3, floatval($_POST['liability_amount'][$i]), SQLITE3_FLOAT);-->
<!--                $stmt->execute();-->
<!--            }-->
<!--        }-->

        // Insert collateral
<!--        if (isset($_POST['collateral_type'])) {-->
<!--            for ($i = 0; $i < count($_POST['collateral_type']); $i++) {-->
<!--                if (empty($_POST['collateral_type'][$i])) continue;-->
<!--                $stmt = $db->prepare("INSERT INTO application_collateral (application_id, type, location, estimated_value) VALUES (?, ?, ?, ?)");-->
<!--                $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);-->
<!--                $stmt->bindValue(2, $_POST['collateral_type'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(3, $_POST['collateral_location'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(4, floatval($_POST['collateral_value'][$i]), SQLITE3_FLOAT);-->
<!--                $stmt->execute();-->
<!--            }-->
<!--        }-->

        // Insert banking
<!--        if (isset($_POST['bank_name'])) {-->
<!--            for ($i = 0; $i < count($_POST['bank_name']); $i++) {-->
<!--                if (empty($_POST['bank_name'][$i])) continue;-->
<!--                $stmt = $db->prepare("INSERT INTO application_banking (application_id, bank_name, account_number, credit_history) VALUES (?, ?, ?, ?)");-->
<!--                $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);-->
<!--                $stmt->bindValue(2, $_POST['bank_name'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(3, $_POST['bank_account'][$i], SQLITE3_TEXT);-->
<!--                $stmt->bindValue(4, $_POST['bank_credit_history'][$i], SQLITE3_TEXT);-->
<!--                $stmt->execute();-->
<!--            }-->
<!--        }-->

<!--        $db->exec('COMMIT');-->

        // Insert initial stage
<!--        $db->exec("INSERT INTO stages (application_id, stage_number, stage_name, completed_at) VALUES ($app_id, 1, 'Inquiry Received', datetime('now'))");-->

        // Handle document uploads
<!--        if (!empty($_FILES['documents']['name'][0])) {-->
<!--            $upload_dir = __DIR__ . '/../uploads/';-->
<!--            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);-->
<!--            $files = $_FILES['documents'];-->
<!--            for ($i = 0; $i < count($files['name']); $i++) {-->
<!--                if ($files['error'][$i] == 0) {-->
<!--                    $tmp = $files['tmp_name'][$i];-->
<!--                    $name = basename($files['name'][$i]);-->
<!--                    $filename = uniqid() . '_' . $name;-->
<!--                    move_uploaded_file($tmp, $upload_dir . $filename);-->
<!--                    $db->exec("INSERT INTO documents (application_id, user_id, file_name, file_path, stage_number, description) -->
<!--                               VALUES ($app_id, $user_id, '$name', 'uploads/$filename', 1, 'Application document')");-->
<!--                }-->
<!--            }-->
<!--        }-->

        // Application fee
<!--        $fee = getApplicationFee($sector);-->
<!--        if ($fee > 0) {-->
<!--            $stmt = $db->prepare("INSERT INTO payments (application_id, amount, method, status, notes) VALUES (?, ?, 'pending', 'Pending', 'Application fee')");-->
<!--            $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);-->
<!--            $stmt->bindValue(2, $fee, SQLITE3_FLOAT);-->
<!--            $stmt->execute();-->
<!--        }-->

        // Notify admin
<!--        addNotification(1, $app_id, "New application submitted.", "?page=admin&view=$app_id");-->

        // Notify vendor if product has a vendor
<!--        $product_id = $_POST['product_id'];-->
<!--        if ($product_id) {-->
<!--            $vendor_id = $db->querySingle("SELECT vendor_id FROM products WHERE id = $product_id");-->
<!--            if ($vendor_id) {-->
<!--                $product_name = $db->querySingle("SELECT name FROM products WHERE id = $product_id");-->
<!--                addNotification($vendor_id, $app_id, "New application for your product: " . $product_name, "?page=vendor_view_application&id=$app_id");-->
<!--            }-->
<!--        }-->

<!--        $_SESSION['message'] = "Application submitted! Your Lease ID: $lease_id";-->
<!--        redirect(BASE_URL . '?page=dashboard');-->
<!--    } else {-->
<!--        $error = implode('<br>', $errors);-->
<!--    }-->
<!--}-->

// Pre‑fill from URL (calculator)
<!--$sector = $_GET['sector'] ?? '';-->
<!--$price = $_GET['price'] ?? '';-->
<!--$down = $_GET['down'] ?? '';-->
<!--$term = $_GET['term'] ?? '';-->
<!--$rate = $_GET['rate'] ?? '';-->
<!--$product_id_prefill = $_GET['product_id'] ?? '';-->
<!--$repayment_method = $_GET['proposed_repayment_method'] ?? '';-->
<!--?>-->
<!--<?php include __DIR__ . '/partials/header.php'; ?>-->

<!--<main class="container">-->
<!--    <h1><i class="fas fa-file-signature"></i> Apply for Lease</h1>-->

<!--    <div class="step-indicator">-->
<!--        <div class="step active">1. Application</div>-->
<!--        <div class="step">2. Review</div>-->
<!--        <div class="step">3. Approval</div>-->
<!--        <div class="step">4. Contract</div>-->
<!--    </div>-->

<!--    <div style="display:grid; grid-template-columns:2fr 1fr; gap:2rem;">-->
<!--        <form method="post" enctype="multipart/form-data" id="applyForm">-->
<!--            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>-->

            <!-- 1. Applicant Information -->
<!--            <h2>1. Applicant Information</h2>-->
<!--            <h3>1.1 Individual Applicant</h3>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Full Name *</label>-->
<!--                    <input type="text" name="applicant_full_name" value="<?= htmlspecialchars($user['full_name'] ?? '') ?>" required>-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Gender</label>-->
<!--                    <select name="applicant_gender">-->
<!--                        <option value="">Select</option>-->
<!--                        <option value="Male" <?= ($user['gender'] ?? '') == 'Male' ? 'selected' : '' ?>>Male</option>-->
<!--                        <option value="Female" <?= ($user['gender'] ?? '') == 'Female' ? 'selected' : '' ?>>Female</option>-->
<!--                    </select>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Date of Birth</label>-->
<!--                    <input type="date" name="applicant_dob" value="<?= htmlspecialchars($user['birth_date'] ?? '') ?>">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Nationality</label>-->
<!--                    <input type="text" name="nationality" value="<?= htmlspecialchars($user['nationality'] ?? 'Ethiopian') ?>">-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>National ID / Passport Number *</label>-->
<!--                    <input type="text" name="applicant_national_id" value="<?= htmlspecialchars($user['national_id'] ?? '') ?>" required>-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Tax Identification Number (TIN) *</label>-->
<!--                    <input type="text" name="tin" value="<?= htmlspecialchars($user['tin'] ?? '') ?>" required placeholder="10 digits">-->
<!--                </div>-->
<!--            </div>-->

            <!-- New Eligibility Criteria -->
<!--            <h2>Eligibility Criteria</h2>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Birth Place</label>-->
<!--                    <input type="text" name="applicant_birth_place">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Marriage Status</label>-->
<!--                    <select name="marriage_status">-->
<!--                        <option value="">Select</option>-->
<!--                        <option value="Married">Married</option>-->
<!--                        <option value="Single">Single</option>-->
<!--                        <option value="Divorced">Divorced</option>-->
<!--                        <option value="Widowed">Widowed</option>-->
<!--                    </select>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Total Members (Male)</label>-->
<!--                    <input type="number" name="total_members_male" min="0">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Total Members (Female)</label>-->
<!--                    <input type="number" name="total_members_female" min="0">-->
<!--                </div>-->
<!--            </div>-->

<!--            <h3>Business Form</h3>-->
<!--            <div class="form-group">-->
<!--                <select name="business_form">-->
<!--                    <option value="">Select Business Form</option>-->
<!--                    <option value="IMX">Grouped by Gov’t (IMX)</option>-->
<!--                    <option value="PLC">PLC</option>-->
<!--                    <option value="Partnership">Partnership</option>-->
<!--                    <option value="Sole Proprietorship">Sole Proprietorship</option>-->
<!--                    <option value="Share Company">Share Company</option>-->
<!--                    <option value="Cooperative">Cooperative Union</option>-->
<!--                    <option value="Other">Other</option>-->
<!--                </select>-->
<!--            </div>-->

<!--            <div class="form-group">-->
<!--                <label>Enterprise Stage (based on capital)</label>-->
<!--                <select name="enterprise_stage">-->
<!--                    <option value="">Select</option>-->
<!--                    <option value="Start up">Start up</option>-->
<!--                    <option value="Micro">Micro</option>-->
<!--                    <option value="Small">Small</option>-->
<!--                    <option value="Medium">Medium</option>-->
<!--                    <option value="Large">Large</option>-->
<!--                </select>-->
<!--            </div>-->

<!--            <div class="form-group">-->
<!--                <label>Business Status</label>-->
<!--                <select name="business_status" id="business_status">-->
<!--                    <option value="">Select</option>-->
<!--                    <option value="Existing">Existing / In Business</option>-->
<!--                    <option value="New">New (not yet in business)</option>-->
<!--                </select>-->
<!--            </div>-->
<!--            <div id="existing_business_fields" style="display:none;">-->
<!--                <div class="form-row">-->
<!--                    <div class="form-group">-->
<!--                        <label>Year Registered</label>-->
<!--                        <input type="number" name="business_year_registered" min="1900" max="<?= date('Y') ?>">-->
<!--                    </div>-->
<!--                    <div class="form-group">-->
<!--                        <label>Type of Business Engaged In</label>-->
<!--                        <input type="text" name="business_type_engaged">-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->

<!--            <h3>Requested Capital Goods</h3>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Machine Name (if not in product list)</label>-->
<!--                    <input type="text" name="machine_name_other">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Machine Availability</label>-->
<!--                    <select name="machine_availability">-->
<!--                        <option value="">Select</option>-->
<!--                        <option value="Foreign">Foreign</option>-->
<!--                        <option value="Local">Local</option>-->
<!--                    </select>-->
<!--                </div>-->
<!--            </div>-->

<!--            <div class="form-group">-->
<!--                <label>Purpose of Requested Capital Goods</label>-->
<!--                <select name="purpose_cg">-->
<!--                    <option value="">Select</option>-->
<!--                    <option value="Expansion">For expansion</option>-->
<!--                    <option value="Diversification">For diversification</option>-->
<!--                    <option value="New Business">To start new business</option>-->
<!--                </select>-->
<!--            </div>-->

<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Electric Power Available (KW/KV)</label>-->
<!--                    <input type="text" name="electric_power_applicant_kw">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Requested Machine Power (KW/KV)</label>-->
<!--                    <input type="text" name="electric_power_required_kw">-->
<!--                </div>-->
<!--            </div>-->

<!--            <div class="form-group">-->
<!--                <label>Working Place Status</label>-->
<!--                <select name="working_place_status">-->
<!--                    <option value="">Select</option>-->
<!--                    <option value="Own">Own</option>-->
<!--                    <option value="Rental">Rental</option>-->
<!--                    <option value="Investment">Investment</option>-->
<!--                    <option value="Gov't cluster">Gov’t cluster</option>-->
<!--                    <option value="Other">Other</option>-->
<!--                </select>-->
<!--            </div>-->

<!--            <div class="form-group">-->
<!--                <label>Raw Materials Availability</label>-->
<!--                <select name="raw_materials_availability">-->
<!--                    <option value="">Select</option>-->
<!--                    <option value="Local">From local/central market</option>-->
<!--                    <option value="Imported">Imported</option>-->
<!--                </select>-->
<!--            </div>-->

<!--            <h3>Market Analysis</h3>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Key Competitors</label>-->
<!--                    <textarea name="key_competitors"></textarea>-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Area Market Condition (linkage)</label>-->
<!--                    <textarea name="area_market_condition"></textarea>-->
<!--                </div>-->
<!--            </div>-->

<!--            <h3>Financial Feasibility</h3>-->
<!--            <h4>Assets</h4>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Current Asset – Cash (ETB)</label>-->
<!--                    <input type="number" name="current_asset_cash" step="0.01">-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Fixed Asset Types (list)</label>-->
<!--                    <textarea name="fixed_asset_types"></textarea>-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Fixed Asset Evidences</label>-->
<!--                    <textarea name="fixed_asset_evidences"></textarea>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Total Fixed Asset (ETB)</label>-->
<!--                    <input type="number" name="total_fixed_asset" step="0.01">-->
<!--                </div>-->
<!--            </div>-->
<!--            <h4>Liabilities</h4>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Loan Amount Borrowed (ETB)</label>-->
<!--                    <input type="number" name="loan_amount" step="0.01">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Outstanding Loan Balance (ETB)</label>-->
<!--                    <input type="number" name="outstanding_loan" step="0.01">-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-group">-->
<!--                <label>Loan Evidences</label>-->
<!--                <textarea name="loan_evidences"></textarea>-->
<!--            </div>-->

            <!-- 2. Business Information (from earlier) -->
<!--            <h2>2. Business Information</h2>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Business / Company Name *</label>-->
<!--                    <input type="text" name="business_name" value="<?= htmlspecialchars($user['business_name'] ?? '') ?>" required>-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Sector of Operation *</label>-->
<!--                    <select name="sector" required>-->
<!--                        <option value="">Select sector</option>-->
<!--                        <?php while($s = $sectors->fetchArray(SQLITE3_ASSOC)): -->
<!--                            $displayName = $s['sector'];-->
<!--                            if ($s['sector'] == 'IMX') $displayName = 'IMX (Gov\'t cluster)';-->
<!--                            elseif ($s['sector'] == 'Employees') $displayName = 'Employees (5% down)';-->
<!--                        ?>-->
<!--                        <option value="<?= $s['sector'] ?>" <?= $sector == $s['sector'] ? 'selected' : '' ?>><?= htmlspecialchars($displayName) ?></option>-->
<!--                        <?php endwhile; ?>-->
<!--                    </select>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Type of Business Activity</label>-->
<!--                    <input type="text" name="business_activity">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Main Products / Services</label>-->
<!--                    <input type="text" name="main_products">-->
<!--                </div>-->
<!--            </div>-->
            <!-- Sector Info & Payment Preview -->
<!--<div id="sector-info" class="sector-info" style="display:none;">-->
<!--    <h3><i class="fas fa-info-circle"></i> Sector Information</h3>-->
<!--    <div class="info-grid">-->
<!--        <div class="info-item">-->
<!--            <span class="info-label">Service Charge Rate</span>-->
<!--            <span class="info-value" id="sector-rate"></span>-->
<!--        </div>-->
<!--        <div class="info-item">-->
<!--            <span class="info-label">Minimum Down Payment</span>-->
<!--            <span class="info-value" id="sector-down-rate"></span>-->
<!--        </div>-->
<!--        <div class="info-item">-->
<!--            <span class="info-label">Application Fee</span>-->
<!--            <span class="info-value" id="sector-app-fee"></span>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->

<!-- Live Payment Preview -->
<!--<div id="payment-preview" class="payment-preview" style="display:none;">-->
<!--    <h3><i class="fas fa-calculator"></i> Estimated Payment</h3>-->
<!--    <div class="preview-grid">-->
<!--        <div class="preview-item">-->
<!--            <span class="preview-label">Financed Amount</span>-->
<!--            <span class="preview-value" id="preview-financed">ETB 0.00</span>-->
<!--        </div>-->
<!--        <div class="preview-item">-->
<!--            <span class="preview-label">Service Fee</span>-->
<!--            <span class="preview-value" id="preview-service-fee">ETB 0.00</span>-->
<!--        </div>-->
<!--        <div class="preview-item">-->
<!--            <span class="preview-label">Total Payment</span>-->
<!--            <span class="preview-value" id="preview-total">ETB 0.00</span>-->
<!--        </div>-->
<!--        <div class="preview-item">-->
<!--            <span class="preview-label">Installment</span>-->
<!--            <span class="preview-value" id="preview-installment">ETB 0.00</span>-->
<!--        </div>-->
<!--    </div>-->
<!--    <p class="preview-note">Based on your inputs. Actual figures may vary upon approval.</p>-->
<!--</div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Number of Employees</label>-->
<!--                    <input type="number" name="num_employees">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Annual Revenue (Last Year) ETB</label>-->
<!--                    <input type="number" name="annual_revenue" step="0.01">-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-group">-->
<!--                <label>Business Location</label>-->
<!--                <input type="text" name="business_location">-->
<!--            </div>-->

            <!-- 3. Contact Information -->
<!--            <h2>3. Contact Information</h2>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Mobile Phone Number *</label>-->
<!--                    <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" required>-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Alternative Phone Number</label>-->
<!--                    <input type="text" name="alternative_phone" value="<?= htmlspecialchars($user['alternative_phone'] ?? '') ?>">-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Email Address *</label>-->
<!--                    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Region</label>-->
<!--                    <input type="text" name="region" value="<?= htmlspecialchars($user['region'] ?? '') ?>">-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Zone/Sub-City</label>-->
<!--                    <input type="text" name="zone" value="<?= htmlspecialchars($user['zone'] ?? '') ?>">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Woreda</label>-->
<!--                    <input type="text" name="woreda" value="<?= htmlspecialchars($user['woreda'] ?? '') ?>">-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>House Number</label>-->
<!--                    <input type="text" name="house_number" value="<?= htmlspecialchars($user['house_number'] ?? '') ?>">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>City</label>-->
<!--                    <input type="text" name="city" value="<?= htmlspecialchars($user['city'] ?? '') ?>" required>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-group">-->
<!--                <label>Address *</label>-->
<!--                <textarea name="address" required><?= htmlspecialchars($user['address'] ?? '') ?></textarea>-->
<!--            </div>-->
            
                        <!-- Branch Selection -->
<!--            <h2>Branch Preference</h2>-->
<!--            <div class="form-group">-->
<!--                <label>Your Nearest Branch</label>-->
<!--                <?php if ($defaultBranchId): ?>-->
<!--                    <p><strong><?= htmlspecialchars($defaultBranchInfo['name']) ?></strong> (<?= htmlspecialchars($defaultBranchInfo['city']) ?>)</p>-->
<!--                    <input type="hidden" name="branch_id" value="<?= $defaultBranchId ?>">-->
<!--                <?php else: ?>-->
<!--                    <p>We could not determine your nearest branch. Please select one:</p>-->
<!--                    <select name="branch_id" required>-->
<!--                        <option value="">Select branch</option>-->
<!--                        <?php while($b = $branchesAll->fetchArray(SQLITE3_ASSOC)): ?>-->
<!--                        <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>-->
<!--                        <?php endwhile; ?>-->
<!--                    </select>-->
<!--                <?php endif; ?>-->
<!--            </div>-->

<!--            <div class="form-group">-->
<!--                <label>Preferred Branch Option</label>-->
<!--                <div class="branch-options">-->
<!--                    <label>-->
<!--                        <input type="radio" name="branch_option" value="default" checked> Use the branch above-->
<!--                    </label>-->
<!--                    <label>-->
<!--                        <input type="radio" name="branch_option" value="other"> I want to apply through a different branch-->
<!--                    </label>-->
<!--                </div>-->
<!--                <div id="other-branch-fields" style="display:none; margin-top:1rem;">-->
<!--                    <div class="form-group">-->
<!--                        <label>Select Branch</label>-->
<!--                        <select name="requested_branch_id">-->
<!--                            <option value="">-- Select Branch --</option>-->
<!--                            <?php-->
                            // Re-fetch branches to avoid cursor issues
<!--                            $branch_res = $db->query("SELECT id, name FROM branches ORDER BY name");-->
<!--                            while ($br = $branch_res->fetchArray(SQLITE3_ASSOC)) {-->
<!--                                echo '<option value="' . $br['id'] . '">' . htmlspecialchars($br['name']) . '</option>';-->
<!--                            }-->
<!--                            ?>-->
<!--                        </select>-->
<!--                    </div>-->
<!--                    <div class="form-group">-->
<!--                        <label>Reason for choosing this branch</label>-->
<!--                        <textarea name="branch_request_reason" rows="3"></textarea>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->

            <!-- 4. Equipment Requested -->
<!--            <h2>4. Equipment Requested</h2>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Type of Equipment / Machinery *</label>-->
<!--                    <select name="product_id" required>-->
<!--                        <option value="">Select from available products</option>-->
<!--                        <?php while($p = $products->fetchArray(SQLITE3_ASSOC)): ?>-->
<!--                        <option value="<?= $p['id'] ?>" <?= $product_id_prefill == $p['id'] ? 'selected' : '' ?>><?= htmlspecialchars($p['name']) ?></option>-->
<!--                        <?php endwhile; ?>-->
<!--                    </select>-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Supplier / Vendor Name</label>-->
<!--                    <input type="text" name="equipment_supplier">-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Equipment Country of Origin</label>-->
<!--                    <input type="text" name="equipment_origin">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Quantity</label>-->
<!--                    <input type="number" name="equipment_quantity" value="1" min="1">-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-group">-->
<!--                <label>Installation Location</label>-->
<!--                <input type="text" name="equipment_installation_location">-->
<!--            </div>-->

            <!-- 5. Financing Request -->
<!--            <h2>5. Financing Request</h2>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Requested Financing Amount *</label>-->
<!--                    <input type="number" name="requested_financing_amount" value="<?= $price ?: '' ?>" required step="0.01">-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Down Payment (Equity) *</label>-->
<!--                    <input type="number" name="equity_amount" value="<?= $down ?: '' ?>" required step="0.01">-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-row">-->
<!--                <div class="form-group">-->
<!--                    <label>Financing Tenure Requested</label>-->
<!--                    <select name="financing_tenure">-->
<!--                        <option value="">Select</option>-->
<!--                        <option value="1 year">1 year</option>-->
<!--                        <option value="2 years">2 years</option>-->
<!--                        <option value="3 years">3 years</option>-->
<!--                        <option value="4 years">4 years</option>-->
<!--                        <option value="5 years">5 years</option>-->
<!--                        <option value="6 years">6 years</option>-->
<!--                        <option value="7 years">7 years</option>-->
<!--                    </select>-->
<!--                </div>-->
<!--                <div class="form-group">-->
<!--                    <label>Lease Term (months)</label>-->
<!--                    <select name="lease_term">-->
<!--                        <?php for ($t=12; $t<=84; $t+=12): ?>-->
<!--                        <option value="<?= $t ?>" <?= $term == $t ? 'selected' : '' ?>><?= $t/12 ?> year<?= $t>12?'s':'' ?> (<?= $t ?> months)</option>-->
<!--                        <?php endfor; ?>-->
<!--                    </select>-->
<!--                </div>-->
<!--            </div>-->
<!--            <div class="form-group">-->
<!--                <label>Proposed Repayment Method</label>-->
<!--                <select name="proposed_repayment_method">-->
<!--                    <option value="">Select</option>-->
<!--                    <option value="Monthly" <?= $repayment_method=='Monthly'?'selected':'' ?>>Monthly</option>-->
<!--                    <option value="Quarterly" <?= $repayment_method=='Quarterly'?'selected':'' ?>>Quarterly</option>-->
<!--                    <option value="Semi-Annual" <?= $repayment_method=='Semi-Annual'?'selected':'' ?>>Semi-Annual</option>-->
<!--                    <option value="Annual" <?= $repayment_method=='Annual'?'selected':'' ?>>Annual</option>-->
<!--                </select>-->
<!--            </div>-->
<!--            <div class="form-group">-->
<!--                <label>Lease Type *</label>-->
<!--                <select name="lease_type" required>-->
<!--                    <option value="financial">Financial Lease</option>-->
<!--                    <option value="technical">Technical Lease</option>-->
<!--                </select>-->
<!--            </div>-->

            <!-- 6. Business Plan and Utilization -->
<!--            <h2>6. Business Plan and Utilization</h2>-->
<!--            <div class="form-group">-->
<!--                <label>Purpose of the Equipment</label>-->
<!--                <textarea name="equipment_purpose" rows="3"></textarea>-->
<!--            </div>-->
<!--            <div class="form-group">-->
<!--                <label>Expected Increase in Production / Service</label>-->
<!--                <input type="text" name="expected_production_increase">-->
<!--            </div>-->
<!--            <div class="form-group">-->
<!--                <label>Estimated Annual Income After Financing</label>-->
<!--                <input type="number" name="estimated_annual_income_after" step="0.01">-->
<!--            </div>-->

            <!-- 7. Financial Information (Assets & Liabilities) – already included above -->
            <!-- 8. Banking Relationship -->
<!--            <h2>8. Banking Relationship</h2>-->
<!--            <table id="bankingTable" class="dynamic-table">-->
<!--                <thead><tr><th>Bank Name</th><th>Account Number</th><th>Credit History</th><th>Action</th></tr></thead>-->
<!--                <tbody>-->
<!--                    <tr class="banking-row">-->
<!--                        <td><input type="text" name="bank_name[]"></td>-->
<!--                        <td><input type="text" name="bank_account[]"></td>-->
<!--                        <td><input type="text" name="bank_credit_history[]"></td>-->
<!--                        <td><button type="button" onclick="removeRow(this)" class="btn-small danger">Remove</button></td>-->
<!--                    </tr>-->
<!--                </tbody>-->
<!--            </table>-->
<!--            <button type="button" onclick="addRow('bankingTable', 'banking-row')" class="button small">Add Bank</button>-->

            <!-- 9. Collateral -->
<!--            <h2>9. Collateral / Security Information</h2>-->
<!--            <table id="collateralTable" class="dynamic-table">-->
<!--                <thead><tr><th>Type of Collateral</th><th>Location</th><th>Estimated Value (ETB)</th><th>Action</th></tr></thead>-->
<!--                <tbody>-->
<!--                    <tr class="collateral-row">-->
<!--                        <td><input type="text" name="collateral_type[]"></td>-->
<!--                        <td><input type="text" name="collateral_location[]"></td>-->
<!--                        <td><input type="number" name="collateral_value[]" step="0.01"></td>-->
<!--                        <td><button type="button" onclick="removeRow(this)" class="btn-small danger">Remove</button></td>-->
<!--                    </tr>-->
<!--                </tbody>-->
<!--            </table>-->
<!--            <button type="button" onclick="addRow('collateralTable', 'collateral-row')" class="button small">Add Collateral</button>-->

            <!-- 10. Shareholders and Management (dynamic tables) -->
<!--            <h2>10. Ownership and Management</h2>-->
<!--            <h3>Shareholders / Owners</h3>-->
<!--            <table id="shareholdersTable" class="dynamic-table">-->
<!--                <thead><tr><th>Name</th><th>Position</th><th>Ownership %</th><th>National ID/TIN</th><th>Action</th></tr></thead>-->
<!--                <tbody>-->
<!--                    <tr class="shareholder-row">-->
<!--                        <td><input type="text" name="shareholder_name[]"></td>-->
<!--                        <td><input type="text" name="shareholder_position[]"></td>-->
<!--                        <td><input type="number" name="shareholder_percent[]" step="0.01" min="0" max="100"></td>-->
<!--                        <td><input type="text" name="shareholder_national_id[]"></td>-->
<!--                        <td><button type="button" onclick="removeRow(this)" class="btn-small danger">Remove</button></td>-->
<!--                    </tr>-->
<!--                </tbody>-->
<!--            </table>-->
<!--            <button type="button" onclick="addRow('shareholdersTable', 'shareholder-row')" class="button small">Add Shareholder</button>-->

<!--            <h3>Key Management</h3>-->
<!--            <table id="managementTable" class="dynamic-table">-->
<!--                <thead><tr><th>Name</th><th>Position</th><th>Qualification</th><th>Experience</th><th>Action</th></tr></thead>-->
<!--                <tbody>-->
<!--                    <tr class="management-row">-->
<!--                        <td><input type="text" name="management_name[]"></td>-->
<!--                        <td><input type="text" name="management_position[]"></td>-->
<!--                        <td><input type="text" name="management_qualification[]"></td>-->
<!--                        <td><input type="text" name="management_experience[]"></td>-->
<!--                        <td><button type="button" onclick="removeRow(this)" class="btn-small danger">Remove</button></td>-->
<!--                    </tr>-->
<!--                </tbody>-->
<!--            </table>-->
<!--            <button type="button" onclick="addRow('managementTable', 'management-row')" class="button small">Add Manager</button>-->

            <!-- 11. Documents upload -->
<!--            <h2>11. Required Documents</h2>-->
<!--            <div class="form-group">-->
<!--                <label>Upload multiple documents</label>-->
<!--                <input type="file" name="documents[]" multiple accept=".pdf,.jpg,.png,.jpeg">-->
<!--                <p class="text-sm text-gray-600">You can upload multiple files.</p>-->
<!--            </div>-->

            <!-- Hidden fields for estimate -->
<!--            <?php if ($price && $down && $term && $rate): ?>-->
<!--            <input type="hidden" name="equity_amount" value="<?= $down ?>">-->
<!--            <input type="hidden" name="total_amount" value="<?= $price ?>">-->
<!--            <input type="hidden" name="lease_term" value="<?= $term ?>">-->
<!--            <input type="hidden" name="interest_rate" value="<?= $rate ?>">-->
<!--            <?php endif; ?>-->

<!--            <button type="submit" name="apply" class="button large">Submit Application</button>-->
<!--        </form>-->

<!--        <div class="summary-card">-->
<!--            <h3>Application Summary</h3>-->
<!--            <p>Please ensure all information is accurate. Incomplete applications may delay processing.</p>-->
<!--            <hr>-->
<!--            <p><i class="fas fa-info-circle"></i> An application fee may apply.</p>-->
<!--            <p><i class="fas fa-clock"></i> Typical processing time: 3‑5 business days.</p>-->
<!--        </div>-->
<!--    </div>-->
<!--</main>-->

<!--<script>-->
<!--function addRow(tableId, rowClass) {-->
<!--    const table = document.getElementById(tableId);-->
<!--    const tbody = table.getElementsByTagName('tbody')[0];-->
<!--    const newRow = document.querySelector('.' + rowClass).cloneNode(true);-->
<!--    const inputs = newRow.getElementsByTagName('input');-->
<!--    for (let i = 0; i < inputs.length; i++) inputs[i].value = '';-->
<!--    tbody.appendChild(newRow);-->
<!--}-->
<!--function removeRow(btn) {-->
<!--    const row = btn.closest('tr');-->
<!--    const tbody = row.parentNode;-->
<!--    if (tbody.getElementsByTagName('tr').length > 1) {-->
<!--        row.remove();-->
<!--    } else {-->
<!--        alert('You must keep at least one row.');-->
<!--    }-->
<!--}-->
// Fetch sector info when sector changes
<!--document.getElementById('sector')?.addEventListener('change', function() {-->
<!--    const sector = this.value;-->
<!--    const price = parseFloat(document.getElementById('price')?.value || 0);-->
<!--    const down = parseFloat(document.getElementById('down')?.value || 0);-->
<!--    const term = parseInt(document.getElementById('term')?.value || 12);-->
<!--    const freq = document.getElementById('freq')?.value || 'monthly';-->
<!--    if (!sector) {-->
<!--        document.getElementById('sector-info').style.display = 'none';-->
<!--        document.getElementById('payment-preview').style.display = 'none';-->
<!--        return;-->
<!--    }-->
<!--    fetchSectorInfo(sector, term, price, down, freq);-->
<!--});-->

// Also update when price, down, term, or frequency changes
<!--['price', 'down', 'term', 'freq'].forEach(id => {-->
<!--    document.getElementById(id)?.addEventListener('input', updatePreview);-->
<!--    document.getElementById(id)?.addEventListener('change', updatePreview);-->
<!--});-->

<!--function fetchSectorInfo(sector, term, price, down, freq) {-->
<!--    fetch('<?= BASE_URL ?>api/get_service_rate.php?sector=' + encodeURIComponent(sector) + '&term=' + term)-->
<!--        .then(res => res.json())-->
<!--        .then(data => {-->
<!--            if (data.error) {-->
<!--                console.error(data.error);-->
<!--                return;-->
<!--            }-->
            // Display sector info
<!--            document.getElementById('sector-rate').innerHTML = data.rate + '% per annum';-->
<!--            document.getElementById('sector-down-rate').innerHTML = data.down_payment_rate + '%';-->
<!--            document.getElementById('sector-app-fee').innerHTML = 'ETB ' + data.application_fee.toLocaleString();-->
<!--            document.getElementById('sector-info').style.display = 'block';-->

            // Store rate for later calculations
<!--            window.currentRate = data.rate;-->
<!--            updatePreview();-->
<!--        });-->
<!--}-->

<!--function updatePreview() {-->
<!--    const sector = document.getElementById('sector')?.value;-->
<!--    const price = parseFloat(document.getElementById('price')?.value || 0);-->
<!--    const down = parseFloat(document.getElementById('down')?.value || 0);-->
<!--    const term = parseInt(document.getElementById('term')?.value || 12);-->
<!--    const freq = document.getElementById('freq')?.value || 'monthly';-->
<!--    const rate = window.currentRate;-->
<!--    if (!sector || !rate) return;-->

<!--    const financed = price - down;-->
<!--    const serviceFee = financed * (rate/100) * (term / 12);-->
<!--    const total = financed + serviceFee;-->

    // Calculate installment based on frequency
<!--    let numInstallments;-->
<!--    switch (freq) {-->
<!--        case 'monthly': numInstallments = term; break;-->
<!--        case 'quarterly': numInstallments = Math.ceil(term / 3); break;-->
<!--        case 'semi-annual': numInstallments = Math.ceil(term / 6); break;-->
<!--        case 'annual': numInstallments = Math.ceil(term / 12); break;-->
<!--        default: numInstallments = term;-->
<!--    }-->
<!--    const installment = total / numInstallments;-->

    // Update preview
<!--    document.getElementById('preview-financed').innerHTML = 'ETB ' + financed.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');-->
<!--    document.getElementById('preview-service-fee').innerHTML = 'ETB ' + serviceFee.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');-->
<!--    document.getElementById('preview-total').innerHTML = 'ETB ' + total.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');-->
<!--    document.getElementById('preview-installment').innerHTML = 'ETB ' + installment.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');-->
<!--    document.getElementById('payment-preview').style.display = 'block';-->
<!--}-->
<!--document.getElementById('business_status')?.addEventListener('change', function() {-->
<!--    document.getElementById('existing_business_fields').style.display = this.value === 'Existing' ? 'block' : 'none';-->
<!--});-->
// Branch toggle
<!--document.querySelectorAll('input[name="branch_option"]').forEach(radio => {-->
<!--    radio.addEventListener('change', function() {-->
<!--        document.getElementById('other-branch-fields').style.display = this.value === 'other' ? 'block' : 'none';-->
<!--    });-->
<!--});-->
<!--</script>-->

<!--<style>-->
<!--.dynamic-table {-->
<!--    width: 100%;-->
<!--    border-collapse: collapse;-->
<!--    margin: 1rem 0;-->
<!--}-->
<!--.dynamic-table th {-->
<!--    background: #f8fafc;-->
<!--    padding: 0.5rem;-->
<!--    text-align: left;-->
<!--    border-bottom: 2px solid #e2e8f0;-->
<!--}-->
<!--.dynamic-table td {-->
<!--    padding: 0.3rem;-->
<!--    border-bottom: 1px solid #e2e8f0;-->
<!--}-->
<!--.dynamic-table input {-->
<!--    width: 100%;-->
<!--    padding: 0.3rem;-->
<!--    border: 1px solid #cbd5e1;-->
<!--    border-radius: 0.25rem;-->
<!--}-->
<!--.btn-small.danger {-->
<!--    background: #b91c1c;-->
<!--    color: white;-->
<!--    border: none;-->
<!--    padding: 0.25rem 0.5rem;-->
<!--    border-radius: 0.25rem;-->
<!--    cursor: pointer;-->
<!--}-->
<!--.button.small { padding: 0.25rem 0.5rem; font-size: 0.9rem; }-->
<!--.button.large { width: 100%; padding: 1rem; font-size: 1.2rem; }-->
<!--#existing_business_fields { margin-top: 1rem; }-->
<!--</style>-->

<!--<?php include __DIR__ . '/partials/footer.php'; ?>-->