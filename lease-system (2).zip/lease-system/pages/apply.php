<?php
// pages/apply.php
$pageTitle = 'Apply for Lease';
require_once __DIR__ . '/../config.php';
requireLogin();

$db = getDb();  // <-- This line is essential
$user_id = $_SESSION['user_id'];
$user = $db->querySingle("SELECT * FROM users WHERE id = $user_id", true);
if (!$user) {
    die("User not found.");
}

// Check if user is approved
$user = $db->querySingle("SELECT * FROM users WHERE id = $user_id", true);
if ($user['approved'] != 1) {
    $_SESSION['error'] = 'Your account is pending approval. You will be notified when approved.';
    redirect(BASE_URL . '?page=dashboard');
}


// Fetch all zones for dropdown
$zones = $db->query("SELECT DISTINCT name FROM zones ORDER BY name");

// Fetch sectors excluding 'Employees'
$sectors = $db->query("SELECT sector FROM down_payment_rates WHERE sector != 'Employees' ORDER BY sector");

// Fetch all products (for equipment dropdown)
$allProducts = [];
$productsRes = $db->query("SELECT id, name, price, sector FROM products WHERE available = 1 ORDER BY name");
while ($p = $productsRes->fetchArray(SQLITE3_ASSOC)) {
    $allProducts[] = $p;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['apply'])) {
    $errors = [];

    // Personal info
    $full_name = trim($_POST['full_name'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $birth_date = $_POST['birth_date'] ?? '';
    $nationality = $_POST['nationality'] ?? 'Ethiopian';
    $national_id = trim($_POST['national_id'] ?? '');
    $tin = trim($_POST['tin'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $alternative_phone = trim($_POST['alternative_phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $region = trim($_POST['region'] ?? '');
    $zone = trim($_POST['zone'] ?? ''); // selected zone from dropdown
    $woreda = trim($_POST['woreda'] ?? '');
    $house_number = trim($_POST['house_number'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $birth_place = trim($_POST['birth_place'] ?? '');
    $marriage_status = $_POST['marriage_status'] ?? '';
    $total_members_male = intval($_POST['total_members_male'] ?? 0);
    $total_members_female = intval($_POST['total_members_female'] ?? 0);

    // Business info (no sector here)
    $business_name = trim($_POST['business_name'] ?? '');
    $business_form = $_POST['business_form'] ?? '';
    $enterprise_stage = $_POST['enterprise_stage'] ?? '';
    $business_status = $_POST['business_status'] ?? '';
    $business_reg_number = trim($_POST['business_reg_number'] ?? '');
    $business_license_number = trim($_POST['business_license_number'] ?? '');
    $year_established = $_POST['year_established'] ? intval($_POST['year_established']) : null;
    $business_activity = trim($_POST['business_activity'] ?? '');
    $main_products = trim($_POST['main_products'] ?? '');
    $num_employees = intval($_POST['num_employees'] ?? 0);
    $annual_revenue = floatval($_POST['annual_revenue'] ?? 0);
    $business_location = trim($_POST['business_location'] ?? '');
    $year_registered = $_POST['year_registered'] ? intval($_POST['year_registered']) : null;
    $business_type_engaged = trim($_POST['business_type_engaged'] ?? '');

    // Equipment & financing fields
    $requested_amount = floatval($_POST['requested_amount'] ?? 0);
    $equity_amount = floatval($_POST['equity_amount'] ?? 0);
    $lease_term = intval($_POST['lease_term'] ?? 0);
    $frequency = $_POST['frequency'] ?? 'Monthly';
    $electric_power_applicant = trim($_POST['electric_power_applicant'] ?? '');
    $electric_power_required = trim($_POST['electric_power_required'] ?? '');
    $working_place_status = $_POST['working_place_status'] ?? '';

        // Equipment product handling (optional)
    $product_id = null;
    $other_product_name = null;
    $other_product_price = null;
    $equipment_name = '';

    if (isset($_POST['use_manual']) && $_POST['use_manual'] == '1') {
        // Manual entry
        $other_product_name = trim($_POST['manual_product_name'] ?? '');
        $other_product_price = floatval($_POST['manual_product_price'] ?? 0);
        $equipment_name = $other_product_name;
        if (empty($other_product_name) || $other_product_price <= 0) {
            $errors[] = 'Manual product details are required.';
        }
    } else {
        // Select from dropdown (optional)
        $product_id = intval($_POST['product_id'] ?? 0);
        if ($product_id > 0) {
            $product = $db->querySingle("SELECT name, price FROM products WHERE id = $product_id", true);
            if ($product) {
                $equipment_name = $product['name'];
                if ($requested_amount == 0) {
                    $requested_amount = $product['price'];
                }
            }
        }
        // No error if no product selected
    }

    // Sector (from equipment section)
    $sector = $_POST['equipment_sector'] ?? '';
    if (empty($sector)) {
        $errors[] = 'Sector is required.';
    }

    // Determine branch based on selected zone
    $branch_id = null;
    if (!empty($zone)) {
        $stmt = $db->prepare("SELECT branch_id FROM zones WHERE name = :zone");
        $stmt->bindValue(':zone', $zone, SQLITE3_TEXT);
        $res = $stmt->execute();
        $row = $res->fetchArray(SQLITE3_ASSOC);
        if ($row) {
            $branch_id = $row['branch_id'];
        }
    }
    if (!$branch_id) {
        // Fallback to user's registered branch or CRMD
        $branch_id = $user['branch_id'];
        if (!$branch_id) {
            $crmd = $db->querySingle("SELECT id FROM branches WHERE name = 'CRMD'");
            $branch_id = $crmd ?: $db->querySingle("SELECT id FROM branches LIMIT 1");
        }
    }

    // Get sector rates
    $down_rate = getDownPaymentRate($sector);
    $service_rate = getServiceChargeRate($sector, $lease_term);
    $app_fee = getApplicationFee($sector);

    if ($down_rate === null || $service_rate === null) {
        $errors[] = 'Unable to determine rates for the selected sector.';
    }

    // Validation
    if (empty($full_name)) $errors[] = 'Full name is required.';
    if (empty($national_id)) $errors[] = 'National ID is required.';
    if (empty($tin)) $errors[] = 'TIN is required.';
    if (empty($phone)) $errors[] = 'Phone is required.';
    if (empty($email)) $errors[] = 'Email is required.';
    if (empty($city)) $errors[] = 'City is required.';
    if (empty($address)) $errors[] = 'Address is required.';
    if (empty($business_name)) $errors[] = 'Business name is required.';
    if (empty($zone)) $errors[] = 'Please select your zone/town.';
    if ($requested_amount <= 0) $errors[] = 'Requested amount must be greater than 0.';
    // Down payment validation removed – no longer required.
    // if ($equity_amount < $requested_amount * ($down_rate / 100)) {
    //     $errors[] = "Down payment must be at least " . formatMoney($requested_amount * $down_rate / 100) . " for the $sector sector.";
    // }
    if ($lease_term < 12 || $lease_term > 84) $errors[] = 'Lease term must be between 12 and 84 months.';
    if ($sector == 'Agriculture' && $lease_term > 60) $errors[] = 'Agriculture sector lease term cannot exceed 60 months.';
    // Frequency restrictions
    $allowedFrequencies = getAllowedFrequencies($sector);
    if (!in_array($frequency, $allowedFrequencies)) {
        $errors[] = "Repayment frequency $frequency is not allowed for the $sector sector.";
    }

    if (empty($errors)) {
        $financed = $requested_amount - $equity_amount;
        $service_charge = $financed * ($service_rate / 100) * ($lease_term / 12);
        $total_repayment = $financed + $service_charge;
        $installment = $total_repayment / ($frequency == 'Monthly' ? $lease_term : ($frequency == 'Quarterly' ? ceil($lease_term / 3) : ceil($lease_term / 6)));

        // Generate lease ID
        $lease_id = 'L-' . date('Ymd') . '-' . rand(1000, 9999);

        $stmt = $db->prepare("INSERT INTO applications (
            lease_id, user_id, branch_id, sector, status, current_stage,
            total_amount, down_payment, financed_amount, service_charge, total_repayment, term_months, frequency,
            applicant_full_name, applicant_gender, applicant_dob, nationality, applicant_national_id, tin,
            phone, alternative_phone, email,
            region, zone, woreda, house_number, city, address,
            applicant_birth_place, marriage_status, total_members_male, total_members_female,
            business_name, business_form, enterprise_stage, business_status,
            business_reg_number, business_license_number, year_established,
            business_activity, main_products, num_employees, annual_revenue, business_location,
            business_year_registered, business_type_engaged,
            electric_power_applicant_kw, electric_power_required_kw, working_place_status,
            equipment_name, other_product_name, other_product_price
        ) VALUES (
            :lease_id, :user_id, :branch_id, :sector, 'pending', 1,
            :total_amount, :down_payment, :financed_amount, :service_charge, :total_repayment, :term_months, :frequency,
            :full_name, :gender, :birth_date, :nationality, :national_id, :tin,
            :phone, :alternative_phone, :email,
            :region, :zone, :woreda, :house_number, :city, :address,
            :birth_place, :marriage_status, :total_members_male, :total_members_female,
            :business_name, :business_form, :enterprise_stage, :business_status,
            :business_reg_number, :business_license_number, :year_established,
            :business_activity, :main_products, :num_employees, :annual_revenue, :business_location,
            :year_registered, :business_type_engaged,
            :electric_power_applicant, :electric_power_required, :working_place_status,
            :equipment_name, :other_product_name, :other_product_price
        )");

        $stmt->bindValue(':lease_id', $lease_id, SQLITE3_TEXT);
        $stmt->bindValue(':user_id', $user_id, SQLITE3_INTEGER);
        $stmt->bindValue(':branch_id', $branch_id, SQLITE3_INTEGER);
        $stmt->bindValue(':sector', $sector, SQLITE3_TEXT);
        $stmt->bindValue(':total_amount', $requested_amount, SQLITE3_FLOAT);
        $stmt->bindValue(':down_payment', $equity_amount, SQLITE3_FLOAT);
        $stmt->bindValue(':financed_amount', $financed, SQLITE3_FLOAT);
        $stmt->bindValue(':service_charge', $service_charge, SQLITE3_FLOAT);
        $stmt->bindValue(':total_repayment', $total_repayment, SQLITE3_FLOAT);
        $stmt->bindValue(':term_months', $lease_term, SQLITE3_INTEGER);
        $stmt->bindValue(':frequency', $frequency, SQLITE3_TEXT);
        $stmt->bindValue(':full_name', $full_name, SQLITE3_TEXT);
        $stmt->bindValue(':gender', $gender, SQLITE3_TEXT);
        $stmt->bindValue(':birth_date', $birth_date, SQLITE3_TEXT);
        $stmt->bindValue(':nationality', $nationality, SQLITE3_TEXT);
        $stmt->bindValue(':national_id', $national_id, SQLITE3_TEXT);
        $stmt->bindValue(':tin', $tin, SQLITE3_TEXT);
        $stmt->bindValue(':phone', $phone, SQLITE3_TEXT);
        $stmt->bindValue(':alternative_phone', $alternative_phone, SQLITE3_TEXT);
        $stmt->bindValue(':email', $email, SQLITE3_TEXT);
        $stmt->bindValue(':region', $region, SQLITE3_TEXT);
        $stmt->bindValue(':zone', $zone, SQLITE3_TEXT);
        $stmt->bindValue(':woreda', $woreda, SQLITE3_TEXT);
        $stmt->bindValue(':house_number', $house_number, SQLITE3_TEXT);
        $stmt->bindValue(':city', $city, SQLITE3_TEXT);
        $stmt->bindValue(':address', $address, SQLITE3_TEXT);
        $stmt->bindValue(':birth_place', $birth_place, SQLITE3_TEXT);
        $stmt->bindValue(':marriage_status', $marriage_status, SQLITE3_TEXT);
        $stmt->bindValue(':total_members_male', $total_members_male, SQLITE3_INTEGER);
        $stmt->bindValue(':total_members_female', $total_members_female, SQLITE3_INTEGER);
        $stmt->bindValue(':business_name', $business_name, SQLITE3_TEXT);
        $stmt->bindValue(':business_form', $business_form, SQLITE3_TEXT);
        $stmt->bindValue(':enterprise_stage', $enterprise_stage, SQLITE3_TEXT);
        $stmt->bindValue(':business_status', $business_status, SQLITE3_TEXT);
        $stmt->bindValue(':business_reg_number', $business_reg_number, SQLITE3_TEXT);
        $stmt->bindValue(':business_license_number', $business_license_number, SQLITE3_TEXT);
        $stmt->bindValue(':year_established', $year_established, SQLITE3_INTEGER);
        $stmt->bindValue(':business_activity', $business_activity, SQLITE3_TEXT);
        $stmt->bindValue(':main_products', $main_products, SQLITE3_TEXT);
        $stmt->bindValue(':num_employees', $num_employees, SQLITE3_INTEGER);
        $stmt->bindValue(':annual_revenue', $annual_revenue, SQLITE3_FLOAT);
        $stmt->bindValue(':business_location', $business_location, SQLITE3_TEXT);
        $stmt->bindValue(':year_registered', $year_registered, SQLITE3_INTEGER);
        $stmt->bindValue(':business_type_engaged', $business_type_engaged, SQLITE3_TEXT);
        $stmt->bindValue(':electric_power_applicant', $electric_power_applicant, SQLITE3_TEXT);
        $stmt->bindValue(':electric_power_required', $electric_power_required, SQLITE3_TEXT);
        $stmt->bindValue(':working_place_status', $working_place_status, SQLITE3_TEXT);
        $stmt->bindValue(':equipment_name', $equipment_name, SQLITE3_TEXT);
        $stmt->bindValue(':other_product_name', $other_product_name, SQLITE3_TEXT);
        $stmt->bindValue(':other_product_price', $other_product_price, SQLITE3_FLOAT);
        $stmt->execute();

        $app_id = $db->lastInsertRowID();

        // Insert initial stage
        $db->exec("INSERT INTO application_stages (application_id, stage_number, stage_name, completed_at) VALUES ($app_id, 1, 'Inquiry Received', datetime('now'))");

        // Notify branch managers (all users with role = 'branch' for that branch)
        $branchManagers = $db->query("SELECT id FROM users WHERE role = 'branch' AND branch_id = $branch_id");
        while ($bm = $branchManagers->fetchArray(SQLITE3_ASSOC)) {
            addNotification($bm['id'], $app_id, "New application #$lease_id assigned to your branch.", "?page=view_application&id=$app_id");
        }

        // Notify CRMD (users with role = 'admin' or 'crmd')
        $crmdUsers = $db->query("SELECT id FROM users WHERE role IN ('admin', 'crmd')");
        while ($crmd = $crmdUsers->fetchArray(SQLITE3_ASSOC)) {
            addNotification($crmd['id'], $app_id, "New application #$lease_id submitted.", "?page=admin_application&id=$app_id");
        }

        // Notify the client
        addNotification($user_id, $app_id, "Your application has been submitted and is pending review.", "?page=view_application&id=$app_id");

        $_SESSION['message'] = 'Application submitted successfully.';
        redirect(BASE_URL . '?page=dashboard');
    }
}

include __DIR__ . '/../partials/header.php';
?>

<div class="container mx-auto px-4 py-8 max-w-4xl">
    <h1 class="text-3xl font-bold mb-6">Apply for Lease</h1>
    <p class="text-gray-600 mb-6">Please fill in all sections. Fields marked * are required.</p>

    <?php if (!empty($errors)): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
            <?php foreach ($errors as $err): ?>
                <p><?= htmlspecialchars($err) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" class="bg-white p-6 rounded shadow">
        <!-- Section 1: Personal Information -->
        <h2 class="text-2xl font-semibold mb-4">1. Personal Information</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Full Name *</label>
                <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name'] ?? '') ?>" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Gender</label>
                <select name="gender" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="Male" <?= ($user['gender'] ?? '') == 'Male' ? 'selected' : '' ?>>Male</option>
                    <option value="Female" <?= ($user['gender'] ?? '') == 'Female' ? 'selected' : '' ?>>Female</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Date of Birth</label>
                <input type="date" name="birth_date" value="<?= htmlspecialchars($user['birth_date'] ?? '') ?>" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Nationality</label>
                <input type="text" name="nationality" value="<?= htmlspecialchars($user['nationality'] ?? 'Ethiopian') ?>" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">National ID / Passport *</label>
                <input type="text" name="national_id" value="<?= htmlspecialchars($user['national_id'] ?? '') ?>" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">TIN Number *</label>
                <input type="text" name="tin" value="<?= htmlspecialchars($user['tin'] ?? '') ?>" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Phone *</label>
                <input type="text" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Alternative Phone</label>
                <input type="text" name="alternative_phone" value="<?= htmlspecialchars($user['alternative_phone'] ?? '') ?>" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Email *</label>
                <input type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Region</label>
                <input type="text" name="region" value="<?= htmlspecialchars($user['region'] ?? '') ?>" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Zone / Town *</label>
                <select name="zone" id="zone" required class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select your zone/town</option>
                    <?php while ($z = $zones->fetchArray(SQLITE3_ASSOC)): ?>
                        <option value="<?= htmlspecialchars($z['name']) ?>"><?= htmlspecialchars($z['name']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Woreda</label>
                <input type="text" name="woreda" value="<?= htmlspecialchars($user['woreda'] ?? '') ?>" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">House Number</label>
                <input type="text" name="house_number" value="<?= htmlspecialchars($user['house_number'] ?? '') ?>" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">City</label>
                <input type="text" name="city" value="<?= htmlspecialchars($user['city'] ?? '') ?>" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium mb-1">Address *</label>
                <textarea name="address" required rows="3" class="w-full border border-gray-300 rounded p-2"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
            </div>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div>
                <label class="block text-sm font-medium mb-1">Birth Place</label>
                <input type="text" name="birth_place" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Marriage Status</label>
                <select name="marriage_status" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="Married">Married</option>
                    <option value="Single">Single</option>
                    <option value="Divorced">Divorced</option>
                    <option value="Widowed">Widowed</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Total Members (Male)</label>
                <input type="number" name="total_members_male" min="0" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Total Members (Female)</label>
                <input type="number" name="total_members_female" min="0" class="w-full border border-gray-300 rounded p-2">
            </div>
        </div>

        <!-- Section 2: Business Information (no sector) -->
        <h2 class="text-2xl font-semibold mt-6 mb-4">2. Business Information</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Business / Company Name *</label>
                <input type="text" name="business_name" value="<?= htmlspecialchars($user['business_name'] ?? '') ?>" required class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Business Form</label>
                <select name="business_form" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="IMX">Grouped by Gov’t (IMX)</option>
                    <option value="PLC">PLC</option>
                    <option value="Partnership">Partnership</option>
                    <option value="Sole Proprietorship">Sole Proprietorship</option>
                    <option value="Share Company">Share Company</option>
                    <option value="Cooperative">Cooperative Union</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Enterprise Stage</label>
                <select name="enterprise_stage" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="Start up">Start up</option>
                    <option value="Micro">Micro</option>
                    <option value="Small">Small</option>
                    <option value="Medium">Medium</option>
                    <option value="Large">Large</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Business Status</label>
                <select name="business_status" id="business_status" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="Existing">Existing / In Business</option>
                    <option value="New">New (not yet in business)</option>
                </select>
            </div>
            <div id="existing_business_fields" style="display:none;" class="grid grid-cols-2 gap-4 md:col-span-2">
                <div>
                    <label class="block text-sm font-medium mb-1">Year Registered</label>
                    <input type="number" name="year_registered" min="1900" max="<?= date('Y') ?>" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Type of Business Engaged In</label>
                    <input type="text" name="business_type_engaged" class="w-full border border-gray-300 rounded p-2">
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Business Registration Number</label>
                <input type="text" name="business_reg_number" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Business License Number</label>
                <input type="text" name="business_license_number" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Year of Establishment</label>
                <input type="number" name="year_established" min="1900" max="<?= date('Y') ?>" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Type of Business Activity</label>
                <input type="text" name="business_activity" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Main Products / Services</label>
                <input type="text" name="main_products" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Number of Employees</label>
                <input type="number" name="num_employees" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Annual Revenue (Last Year) ETB</label>
                <input type="number" name="annual_revenue" step="0.01" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium mb-1">Business Location</label>
                <input type="text" name="business_location" class="w-full border border-gray-300 rounded p-2">
            </div>
        </div>

        <!-- Section 3: Equipment Requested Info -->
        <h2 class="text-2xl font-semibold mt-6 mb-4">3. Equipment Requested Info</h2>

        <!-- Sector constants info box -->
        <div id="sector-info-box" class="bg-blue-50 p-4 rounded mb-4 hidden">
            <h3 class="font-semibold text-blue-800">Sector Information</h3>
            <div class="grid grid-cols-3 gap-4 mt-2 text-sm">
                <div><strong>Application Fee:</strong> <span id="display-app-fee">-</span></div>
                <div><strong>Minimum Down Payment:</strong> <span id="display-down-payment">-</span>%</div>
                <div><strong>Service Charge Range:</strong> <span id="display-service-charge">-</span></div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Sector *</label>
                <select name="equipment_sector" id="equipment_sector" required class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select sector</option>
                    <?php while ($s = $sectors->fetchArray(SQLITE3_ASSOC)): ?>
                        <option value="<?= $s['sector'] ?>"><?= $s['sector'] ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div id="equipment-field">
                <label class="block text-sm font-medium mb-1">Equipment / Product *</label>
                <div id="product-dropdown-container" style="display: block;">
                    <select name="product_id" id="product_select" class="w-full border border-gray-300 rounded p-2">
                        <option value="">Select a product</option>
                        <!-- Options will be filled by JS -->
                    </select>
                </div>
                <div id="manual-product-container" style="display: none;">
                    <input type="text" name="manual_product_name" id="manual_product_name" class="w-full border border-gray-300 rounded p-2" placeholder="Enter product name">
                    <input type="number" name="manual_product_price" id="manual_product_price" step="0.01" class="w-full border border-gray-300 rounded p-2 mt-2" placeholder="Price (ETB)">
                </div>
                <button type="button" id="toggle_manual_btn" class="text-sm text-blue-600 mt-1">Or enter manually</button>
                <p id="equipment-note" class="text-xs text-gray-500 mt-1"></p>
                <input type="hidden" name="use_manual" id="use_manual" value="0">
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div>
                <label class="block text-sm font-medium mb-1">Requested Financing Amount (ETB) *</label>
                <input type="number" name="requested_amount" id="price" required step="0.01" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Down Payment (Equity) (ETB) *</label>
                <input type="number" name="equity_amount" id="down" required step="0.01" class="w-full border border-gray-300 rounded p-2">
                <p class="text-xs text-gray-500 mt-1">Minimum: <span id="min_down_display">0</span>% of total</p>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Lease Term (months)</label>
                <select name="lease_term" id="term" class="w-full border border-gray-300 rounded p-2">
                    <?php for ($t=12; $t<=84; $t+=12): ?>
                        <option value="<?= $t ?>"><?= $t/12 ?> year<?= $t>12?'s':'' ?> (<?= $t ?> months)</option>
                    <?php endfor; ?>
                </select>
                <p id="term_note" class="text-xs text-gray-500"></p>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Repayment Frequency</label>
                <select name="frequency" id="freq" class="w-full border border-gray-300 rounded p-2">
                    <option value="Monthly">Monthly</option>
                    <option value="Quarterly">Quarterly</option>
                    <option value="Semi-Annual">Semi-Annual</option>
                </select>
                <p id="freq_note" class="text-xs text-gray-500"></p>
            </div>
        </div>

        <!-- Payment Preview -->
        <div id="payment-preview" class="bg-gray-50 p-4 rounded mt-4" style="display:none;">
            <h3 class="text-lg font-semibold">Estimated Payment</h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2">
                <div><span class="text-sm text-gray-600">Financed Amount:</span><br><span id="preview-financed" class="font-semibold">ETB 0.00</span></div>
                <div><span class="text-sm text-gray-600">Service Fee:</span><br><span id="preview-service-fee" class="font-semibold">ETB 0.00</span></div>
                <div><span class="text-sm text-gray-600">Total Payment:</span><br><span id="preview-total" class="font-semibold">ETB 0.00</span></div>
                <div><span class="text-sm text-gray-600">Installment:</span><br><span id="preview-installment" class="font-semibold">ETB 0.00</span></div>
            </div>
        </div>

        <!-- Additional fields -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div>
                <label class="block text-sm font-medium mb-1">Electric Power Availability (Applicant) (KW/KV)</label>
                <input type="text" name="electric_power_applicant" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Electric Power Required (Machine) (KW/KV)</label>
                <input type="text" name="electric_power_required" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Working Place Status</label>
                <select name="working_place_status" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select</option>
                    <option value="Own">Own</option>
                    <option value="Rental">Rental</option>
                    <option value="Investment">Investment</option>
                    <option value="Gov't cluster">Gov’t cluster</option>
                    <option value="Other">Other</option>
                </select>
            </div>
        </div>

        <div class="mt-6">
            <button type="submit" name="apply" class="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg text-lg transition w-full md:w-auto">Submit Application</button>
        </div>
    </form>
</div>

<script>
// Sector constants (from tariff document)
const sectorConstants = {
    'IMX': { appFee: 500, downRate: 10, serviceRange: '20% - 22%' },
    'Agriculture': { appFee: 1500, downRate: 20, serviceRange: '20% - 22%' },
    'Manufacturing': { appFee: 1500, downRate: 15, serviceRange: '20% - 22.5%' },
    'Services': { appFee: 1500, downRate: 20, serviceRange: '20% - 22.5%' },
    'Construction': { appFee: 2000, downRate: 25, serviceRange: '21% - 23%' }
};

// Service charge rates based on sector and term (in years)
const serviceRates = {
    'IMX': {
        1: 20, 2: 20,
        3: 20.5, 4: 20.5,
        5: 21.5,
        6: 22, 7: 22
    },
    'Agriculture': {
        1: 20, 2: 20,
        3: 21.5, 4: 21.5,
        5: 22,
        6: null, 7: null   // not allowed beyond 5 years
    },
    'Manufacturing': {
        1: 20, 2: 20,
        3: 21.5, 4: 21.5,
        5: 22,
        6: 22.5, 7: 22.5
    },
    'Services': {
        1: 20, 2: 20,
        3: 21.5, 4: 21.5,
        5: 22,
        6: 22.5, 7: 22.5
    },
    'Construction': {
        1: 21, 2: 21,
        3: 21.5, 4: 21.5,
        5: 22.5,
        6: 23, 7: 23
    }
};

// Allowed frequencies per sector (base)
const allowedFrequencies = {
    'IMX': ['Monthly', 'Quarterly'],
    'Agriculture': ['Monthly', 'Quarterly', 'Semi-Annual'],
    'Manufacturing': ['Monthly', 'Quarterly'],
    'Services': ['Monthly'],
    'Construction': ['Monthly', 'Quarterly']
};

// Product data from PHP
const allProducts = <?= json_encode($allProducts) ?>;

function getServiceRate(sector, termMonths) {
    if (!sector || !serviceRates[sector]) return null;
    const years = Math.ceil(termMonths / 12);
    const rate = serviceRates[sector][years];
    return rate !== undefined ? rate : null;
}

function fetchEquipmentSectorInfo() {
    const sector = document.getElementById('equipment_sector').value;
    const term = parseInt(document.getElementById('term').value) || 12;
    const infoBox = document.getElementById('sector-info-box');
    const termNote = document.getElementById('term_note');
    const freqSelect = document.getElementById('freq');
    const freqNote = document.getElementById('freq_note');

    if (!sector) {
        infoBox.classList.add('hidden');
        document.getElementById('payment-preview').style.display = 'none';
        updateProductDropdown(sector);
        return;
    }

    const data = sectorConstants[sector];
    if (data) {
        document.getElementById('display-app-fee').innerText = 'ETB ' + data.appFee;
        document.getElementById('display-down-payment').innerText = data.downRate;
        document.getElementById('display-service-charge').innerText = data.serviceRange;
        infoBox.classList.remove('hidden');
    }

    // Update term note for Agriculture (max 5 years)
    const years = term / 12;
    if (sector === 'Agriculture' && years > 5) {
        termNote.innerText = 'Agriculture sector maximum term is 5 years (60 months).';
    } else {
        termNote.innerText = '';
    }

    // Update frequency dropdown based on sector (base)
    const allowed = allowedFrequencies[sector] || ['Monthly'];
    const currentFreq = freqSelect.value;
    freqSelect.innerHTML = '';
    allowed.forEach(freq => {
        const option = document.createElement('option');
        option.value = freq;
        option.text = freq;
        if (freq === currentFreq) option.selected = true;
        freqSelect.appendChild(option);
    });
    if (!allowed.includes(currentFreq)) {
        freqSelect.value = allowed[0];
    }
    freqNote.innerText = allowed.includes('Semi-Annual') ? '' : 'Semi-annual not allowed for this sector.';

    // Update minimum down payment display
    document.getElementById('min_down_display').innerText = data.downRate;
    window.currentRate = getServiceRate(sector, term);
    updatePreview();
    updateProductDropdown(sector);
    // Auto-fill down payment minimum
    setMinimumDownPayment();
}

function updateProductDropdown(sector) {
    const dropdownContainer = document.getElementById('product-dropdown-container');
    const selectEl = document.getElementById('product_select');
    const manualContainer = document.getElementById('manual-product-container');
    const manualBtn = document.getElementById('toggle_manual_btn');
    const useManual = document.getElementById('use_manual');

    if (!sector) {
        selectEl.innerHTML = '<option value="">Select a product</option>';
        return;
    }

    const productsInSector = allProducts.filter(p => p.sector === sector);
    if (productsInSector.length > 0) {
        dropdownContainer.style.display = 'block';
        manualContainer.style.display = 'none';
        manualBtn.style.display = 'inline-block';
        useManual.value = '0';
        selectEl.innerHTML = '<option value="">Select a product</option>';
        productsInSector.forEach(p => {
            const option = document.createElement('option');
            option.value = p.id;
            option.textContent = `${p.name} (ETB ${p.price})`;
            selectEl.appendChild(option);
        });
    } else {
        dropdownContainer.style.display = 'none';
        manualContainer.style.display = 'block';
        manualBtn.style.display = 'none';
        useManual.value = '1';
    }
}

function updatePreview() {
    const sector = document.getElementById('equipment_sector').value;
    const price = parseFloat(document.getElementById('price').value) || 0;
    const down = parseFloat(document.getElementById('down').value) || 0;
    const term = parseInt(document.getElementById('term').value) || 12;
    const freq = document.getElementById('freq').value;
    const rate = getServiceRate(sector, term);

    if (!sector || !rate || price <= 0) {
        document.getElementById('payment-preview').style.display = 'none';
        return;
    }

    const financed = price - down;
    const serviceFee = financed * (rate/100) * (term / 12);
    const total = financed + serviceFee;

    let numInstallments;
    switch (freq) {
        case 'Monthly': numInstallments = term; break;
        case 'Quarterly': numInstallments = Math.ceil(term / 3); break;
        case 'Semi-Annual': numInstallments = Math.ceil(term / 6); break;
        default: numInstallments = term;
    }
    const installment = total / numInstallments;

    document.getElementById('preview-financed').innerHTML = 'ETB ' + financed.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('preview-service-fee').innerHTML = 'ETB ' + serviceFee.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('preview-total').innerHTML = 'ETB ' + total.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('preview-installment').innerHTML = 'ETB ' + installment.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('payment-preview').style.display = 'block';
}

function setMinimumDownPayment() {
    const sector = document.getElementById('equipment_sector').value;
    const price = parseFloat(document.getElementById('price').value) || 0;
    const downRate = sectorConstants[sector]?.downRate;
    if (downRate && price > 0) {
        const minDown = price * (downRate / 100);
        const downField = document.getElementById('down');
        // Only set if field is empty or less than minimum
        if (!downField.value || parseFloat(downField.value) < minDown) {
            downField.value = minDown.toFixed(2);
            updatePreview(); // refresh preview
        }
    }
}

// Toggle manual entry
const toggleManualBtn = document.getElementById('toggle_manual_btn');
const dropdownContainer = document.getElementById('product-dropdown-container');
const manualContainer = document.getElementById('manual-product-container');
const useManual = document.getElementById('use_manual');

toggleManualBtn.addEventListener('click', function() {
    if (dropdownContainer.style.display !== 'none') {
        // Switch to manual
        dropdownContainer.style.display = 'none';
        manualContainer.style.display = 'block';
        useManual.value = '1';
    } else {
        // Switch back to dropdown (if products exist)
        const sector = document.getElementById('equipment_sector').value;
        const productsInSector = allProducts.filter(p => p.sector === sector);
        if (productsInSector.length > 0) {
            dropdownContainer.style.display = 'block';
            manualContainer.style.display = 'none';
            useManual.value = '0';
        } else {
            alert('No products available for this sector to switch back to dropdown.');
        }
    }
});

// Attach event listeners
document.getElementById('equipment_sector').addEventListener('change', fetchEquipmentSectorInfo);
document.getElementById('price').addEventListener('input', function() {
    updatePreview();
    setMinimumDownPayment();
});
document.getElementById('down').addEventListener('input', updatePreview);
document.getElementById('term').addEventListener('change', function() { fetchEquipmentSectorInfo(); updatePreview(); });
document.getElementById('freq').addEventListener('change', updatePreview);

// Initialize
fetchEquipmentSectorInfo();

// Toggle existing business fields
document.getElementById('business_status')?.addEventListener('change', function() {
    document.getElementById('existing_business_fields').style.display = this.value === 'Existing' ? 'block' : 'none';
});
</script>

<?php include __DIR__ . '/../partials/footer.php'; ?>