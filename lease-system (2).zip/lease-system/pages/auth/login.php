<?php
// pages/auth/login.php
$pageTitle = 'Login';
require_once __DIR__ . '/../../config.php';

if (isLoggedIn()) {
    redirect(BASE_URL . '?page=dashboard');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $db = getDb();

    $stmt = $db->prepare("SELECT * FROM users WHERE email = :cred OR username = :cred");
    $stmt->bindValue(':cred', $username, SQLITE3_TEXT);
    $result = $stmt->execute();
    $user = $result->fetchArray(SQLITE3_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_name'] = $user['full_name'];
        $_SESSION['username'] = $user['username'] ?? '';
        $_SESSION['business_name'] = $user['business_name'] ?? $user['full_name'];

        if (isset($user['approved']) && $user['approved'] == 0) {
            $error = 'Your account is pending approval. You will be notified when approved.';
            unset($_SESSION['user_id']);
        } else {
            $redirect = $_SESSION['redirect_after_login'] ?? 'dashboard';
            unset($_SESSION['redirect_after_login']);
            redirect(BASE_URL . '?page=' . $redirect);
        }
    } else {
        $error = 'Invalid username or password.';
    }
}

// Now include the header (only after any redirects are done)
include __DIR__ . '/../../partials/header.php';
?>

<div class="flex items-center justify-center min-h-[70vh]">
    <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-6">Login to SiinQee Lease</h2>

        <?php if ($error): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4 rounded">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2">Username or Email</label>
                <input type="text" name="username" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500">
            </div>
            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-bold mb-2">Password</label>
                <input type="password" name="password" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500">
            </div>
            <button type="submit"
                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md transition duration-200">
                Login
            </button>
        </form>

        <div class="mt-6 text-center text-sm text-gray-600">
            <p>Don't have an account?
                <a href="<?= BASE_URL ?>?page=register_client" class="text-green-600 hover:underline">Register as Client</a>
                or
                <a href="<?= BASE_URL ?>?page=register_vendor" class="text-green-600 hover:underline">Register as Vendor</a>
            </p>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>