<?php
// pages/auth/register_client.php
$pageTitle = 'Client Registration';
require_once __DIR__ . '/../../config.php';

// ========== Define database connection (available for both POST and HTML) ==========
$db = getDb();

// ========== POST PROCESSING (must happen before any output) ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ensure the user_documents table exists
    $db->exec("CREATE TABLE IF NOT EXISTS user_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        file_name TEXT,
        file_path TEXT,
        document_type TEXT,
        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )");

    // Collect and sanitize input (same as before)
    $data = [
        'username' => $_POST['username'] ?? '',
        'email' => $_POST['email'] ?? '',
        'password' => $_POST['password'] ?? '',
        'full_name' => $_POST['full_name'] ?? '',
        'gender' => $_POST['gender'] ?? '',
        'birth_date' => $_POST['birth_date'] ?? '',
        'nationality' => $_POST['nationality'] ?? 'Ethiopian',
        'national_id' => $_POST['national_id'] ?? '',
        'tin' => $_POST['tin'] ?? '',
        'phone' => $_POST['phone'] ?? '',
        'alternative_phone' => $_POST['alternative_phone'] ?? '',
        'business_name' => $_POST['business_name'] ?? '',
        'business_form' => $_POST['business_form'] ?? '',
        'business_reg_number' => $_POST['business_reg_number'] ?? '',
        'business_license_number' => $_POST['business_license_number'] ?? '',
        'year_established' => $_POST['year_established'] ? intval($_POST['year_established']) : null,
        'sector' => $_POST['sector'] ?? '',
        'region' => $_POST['region'] ?? '',
        'zone' => $_POST['zone'] ?? '',
        'woreda' => $_POST['woreda'] ?? '',
        'house_number' => $_POST['house_number'] ?? '',
        'city' => $_POST['city'] ?? '',
        'address' => $_POST['address'] ?? '',
    ];

    // Basic validation
    $errors = [];
    if (empty($data['username'])) $errors[] = 'Username is required.';
    if (empty($data['email'])) $errors[] = 'Email is required.';
    if (empty($data['password'])) $errors[] = 'Password is required.';
    if (empty($data['full_name'])) $errors[] = 'Full name is required.';
    if (empty($data['tin'])) $errors[] = 'TIN is required.';
    if (empty($data['phone'])) $errors[] = 'Phone is required.';

    // Check if username or email already exists
    $existing = $db->querySingle("SELECT id FROM users WHERE username = '{$data['username']}' OR email = '{$data['email']}'");
    if ($existing) {
        $errors[] = 'Username or email already exists.';
    }

    if (empty($errors)) {
        // Hash password
        $password = password_hash($data['password'], PASSWORD_DEFAULT);

        // Insert user
        $stmt = $db->prepare("INSERT INTO users (
            username, email, password, role, approved,
            full_name, gender, birth_date, nationality, national_id, tin,
            phone, alternative_phone,
            business_name, business_form, business_reg_number, business_license_number, year_established, sector,
            region, zone, woreda, house_number, city, address
        ) VALUES (
            :username, :email, :password, 'client', 0,
            :full_name, :gender, :birth_date, :nationality, :national_id, :tin,
            :phone, :alternative_phone,
            :business_name, :business_form, :business_reg_number, :business_license_number, :year_established, :sector,
            :region, :zone, :woreda, :house_number, :city, :address
        )");
        // After $user_id = $db->lastInsertRowID();
$branch_id = getBranchByCity($data['city']);
$db->exec("UPDATE users SET branch_id = $branch_id WHERE id = $user_id");

        $stmt->bindValue(':username', $data['username'], SQLITE3_TEXT);
        $stmt->bindValue(':email', $data['email'], SQLITE3_TEXT);
        $stmt->bindValue(':password', $password, SQLITE3_TEXT);
        $stmt->bindValue(':full_name', $data['full_name'], SQLITE3_TEXT);
        $stmt->bindValue(':gender', $data['gender'], SQLITE3_TEXT);
        $stmt->bindValue(':birth_date', $data['birth_date'], SQLITE3_TEXT);
        $stmt->bindValue(':nationality', $data['nationality'], SQLITE3_TEXT);
        $stmt->bindValue(':national_id', $data['national_id'], SQLITE3_TEXT);
        $stmt->bindValue(':tin', $data['tin'], SQLITE3_TEXT);
        $stmt->bindValue(':phone', $data['phone'], SQLITE3_TEXT);
        $stmt->bindValue(':alternative_phone', $data['alternative_phone'], SQLITE3_TEXT);
        $stmt->bindValue(':business_name', $data['business_name'], SQLITE3_TEXT);
        $stmt->bindValue(':business_form', $data['business_form'], SQLITE3_TEXT);
        $stmt->bindValue(':business_reg_number', $data['business_reg_number'], SQLITE3_TEXT);
        $stmt->bindValue(':business_license_number', $data['business_license_number'], SQLITE3_TEXT);
        $stmt->bindValue(':year_established', $data['year_established'], SQLITE3_INTEGER);
        $stmt->bindValue(':sector', $data['sector'], SQLITE3_TEXT);
        $stmt->bindValue(':region', $data['region'], SQLITE3_TEXT);
        $stmt->bindValue(':zone', $data['zone'], SQLITE3_TEXT);
        $stmt->bindValue(':woreda', $data['woreda'], SQLITE3_TEXT);
        $stmt->bindValue(':house_number', $data['house_number'], SQLITE3_TEXT);
        $stmt->bindValue(':city', $data['city'], SQLITE3_TEXT);
        $stmt->bindValue(':address', $data['address'], SQLITE3_TEXT);
        $stmt->execute();

        $user_id = $db->lastInsertRowID();

        // Handle document uploads
        if (!empty($_FILES['documents']['name'][0])) {
            $upload_dir = __DIR__ . '/../../uploads/user_docs/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $doc_types = $_POST['doc_type'] ?? [];
            for ($i = 0; $i < count($_FILES['documents']['name']); $i++) {
                if ($_FILES['documents']['error'][$i] == 0) {
                    $tmp = $_FILES['documents']['tmp_name'][$i];
                    $name = basename($_FILES['documents']['name'][$i]);
                    $filename = uniqid() . '_' . $name;
                    move_uploaded_file($tmp, $upload_dir . $filename);
                    $type = $doc_types[$i] ?? 'other';
                    $db->exec("INSERT INTO user_documents (user_id, file_name, file_path, document_type) 
                               VALUES ($user_id, '$name', 'uploads/user_docs/$filename', '$type')");
                }
            }
        }

        // Notify admin
        addNotification(1, 0, "New client registration pending approval: " . $data['business_name'], "?page=admin_users&view=$user_id");

        $_SESSION['message'] = 'Registration successful. Your account is pending admin approval.';
        redirect(BASE_URL . '?page=login');
    }
}
// ========== END POST PROCESSING ==========

// Now include header (safe because no output has been sent yet)
include __DIR__ . '/../../partials/header.php';

// Fetch sectors for dropdown (use the already-defined $db)
$sectors = $db->query("SELECT DISTINCT sector FROM down_payment_rates ORDER BY sector");
?>

<div class="container mx-auto px-4 py-8 max-w-4xl">
    <h1 class="text-3xl font-bold mb-4">Client Registration</h1>
    <p class="text-gray-600 mb-6">Please fill in all details accurately. Fields marked * are required.</p>

    <?php if (!empty($errors)): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
            <?php foreach ($errors as $err): ?>
                <p><?= htmlspecialchars($err) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" id="registerForm">
        <!-- Step 1: Personal Information -->
        <div class="form-step" data-step="1">
            <h2 class="text-2xl font-semibold mb-4">1. Personal Information</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Username *</label>
                    <input type="text" name="username" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Email *</label>
                    <input type="email" name="email" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Password *</label>
                    <input type="password" name="password" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Full Name *</label>
                    <input type="text" name="full_name" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Gender</label>
                    <select name="gender" class="w-full border border-gray-300 rounded p-2">
                        <option value="">Select</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Date of Birth</label>
                    <input type="date" name="birth_date" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Nationality</label>
                    <input type="text" name="nationality" value="Ethiopian" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">National ID / Passport *</label>
                    <input type="text" name="national_id" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">TIN Number *</label>
                    <input type="text" name="tin" required placeholder="10 digits" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Phone *</label>
                    <input type="text" name="phone" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Alternative Phone</label>
                    <input type="text" name="alternative_phone" class="w-full border border-gray-300 rounded p-2">
                </div>
            </div>
        </div>

        <!-- Step 2: Business Information -->
        <div class="form-step" data-step="2" style="display:none;">
            <h2 class="text-2xl font-semibold mb-4">2. Business Information</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Business / Company Name *</label>
                    <input type="text" name="business_name" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Business Form</label>
                    <select name="business_form" class="w-full border border-gray-300 rounded p-2">
                        <option value="">Select</option>
                        <option value="IMX">Grouped by Gov’t (IMX)</option>
                        <option value="PLC">PLC</option>
                        <option value="Partnership">Partnership</option>
                        <option value="Sole Proprietorship">Sole Proprietorship</option>
                        <option value="Share Company">Share Company</option>
                        <option value="Cooperative">Cooperative Union</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Business Registration Number</label>
                    <input type="text" name="business_reg_number" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Business License Number</label>
                    <input type="text" name="business_license_number" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Year of Establishment</label>
                    <input type="number" name="year_established" min="1900" max="<?= date('Y') ?>" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Sector</label>
                    <select name="sector" class="w-full border border-gray-300 rounded p-2">
                        <option value="">Select</option>
                        <?php while($s = $sectors->fetchArray(SQLITE3_ASSOC)): ?>
                            <option value="<?= $s['sector'] ?>"><?= $s['sector'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
        </div>

        <!-- Step 3: Address -->
        <div class="form-step" data-step="3" style="display:none;">
            <h2 class="text-2xl font-semibold mb-4">3. Address</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Region</label>
                    <input type="text" name="region" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Zone/Sub-City</label>
                    <input type="text" name="zone" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Woreda</label>
                    <input type="text" name="woreda" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">House Number</label>
                    <input type="text" name="house_number" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">City *</label>
                    <input type="text" name="city" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Address *</label>
                    <textarea name="address" required rows="3" class="w-full border border-gray-300 rounded p-2"></textarea>
                </div>
            </div>
        </div>

        <!-- Step 4: Supporting Documents -->
        <div class="form-step" data-step="4" style="display:none;">
            <h2 class="text-2xl font-semibold mb-4">4. Supporting Documents</h2>
            <p class="mb-4">You can upload multiple documents. For each, select the type.</p>
            <div id="documents-container">
                <div class="document-row flex gap-2 mb-2">
                    <input type="file" name="documents[]" accept=".pdf,.jpg,.png,.jpeg" class="flex-1 border border-gray-300 rounded p-2">
                    <select name="doc_type[]" class="border border-gray-300 rounded p-2">
                        <option value="id">National ID / Passport</option>
                        <option value="tin">TIN Certificate</option>
                        <option value="license">Business License</option>
                        <option value="reg">Business Registration</option>
                        <option value="other">Other</option>
                    </select>
                    <button type="button" onclick="removeDocumentRow(this)" class="bg-red-500 text-white px-3 py-1 rounded">Remove</button>
                </div>
            </div>
            <button type="button" onclick="addDocumentRow()" class="bg-blue-500 text-white px-4 py-2 rounded mt-2">Add Another Document</button>
        </div>

        <!-- Navigation Buttons -->
        <div class="mt-8 flex justify-between">
            <button type="button" id="prevBtn" class="bg-gray-500 text-white px-6 py-2 rounded" style="display:none;">Previous</button>
            <button type="button" id="nextBtn" class="bg-blue-600 text-white px-6 py-2 rounded">Next</button>
            <button type="submit" id="submitBtn" class="bg-green-600 text-white px-6 py-2 rounded" style="display:none;">Register</button>
        </div>
    </form>
</div>

<script>
let currentStep = 1;
const totalSteps = 4;

function showStep(step) {
    document.querySelectorAll('.form-step').forEach(el => el.style.display = 'none');
    const stepEl = document.querySelector(`.form-step[data-step="${step}"]`);
    if (stepEl) stepEl.style.display = 'block';

    document.getElementById('prevBtn').style.display = step === 1 ? 'none' : 'inline-block';
    if (step === totalSteps) {
        document.getElementById('nextBtn').style.display = 'none';
        document.getElementById('submitBtn').style.display = 'inline-block';
    } else {
        document.getElementById('nextBtn').style.display = 'inline-block';
        document.getElementById('submitBtn').style.display = 'none';
    }
}

function changeStep(delta) {
    const newStep = currentStep + delta;
    if (newStep < 1 || newStep > totalSteps) return;

    if (delta === 1 && !validateStep(currentStep)) {
        alert('Please fill all required fields in this step before proceeding.');
        return;
    }

    currentStep = newStep;
    showStep(currentStep);
}

function validateStep(step) {
    const stepDiv = document.querySelector(`.form-step[data-step="${step}"]`);
    if (!stepDiv) return true;
    const requiredFields = stepDiv.querySelectorAll('[required]');
    for (let field of requiredFields) {
        if (!field.value.trim()) {
            field.focus();
            return false;
        }
    }
    return true;
}

function addDocumentRow() {
    const container = document.getElementById('documents-container');
    const newRow = document.querySelector('.document-row').cloneNode(true);
    newRow.querySelectorAll('input, select').forEach(el => el.value = '');
    container.appendChild(newRow);
}
function removeDocumentRow(btn) {
    const row = btn.closest('.document-row');
    const container = document.getElementById('documents-container');
    if (container.children.length > 1) row.remove();
    else alert('You must keep at least one document row.');
}

document.getElementById('nextBtn').addEventListener('click', () => changeStep(1));
document.getElementById('prevBtn').addEventListener('click', () => changeStep(-1));
document.getElementById('registerForm').addEventListener('submit', function(e) {
    for (let s = 1; s <= totalSteps; s++) {
        if (!validateStep(s)) {
            e.preventDefault();
            currentStep = s;
            showStep(s);
            alert('Please complete all required fields in step ' + s + ' before submitting.');
            return;
        }
    }
});

showStep(1);
</script>

<?php include __DIR__ . '/../../partials/footer.php'; ?>