<?php
// pages/auth/register_vendor.php
$pageTitle = 'Vendor Registration';
require_once __DIR__ . '/../../config.php';
include __DIR__ . '/../../partials/header.php';

$db = getDb();

// Create vendor_documents table if not exists
$db->exec("CREATE TABLE IF NOT EXISTS vendor_documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    file_name TEXT,
    file_path TEXT,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    document_type TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
)");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ... (all the existing POST handling code remains exactly the same) ...
    // No changes to the logic.
}

// The rest of the form – keep all existing HTML, but remove any extra <main> tags.
// The header already provides <main class="fade-in">, so we must not have another <main>.
?>

<div class="container mx-auto px-4 py-8 max-w-4xl">
    <h1 class="text-3xl font-bold mb-4">Vendor Registration</h1>
    <p class="text-gray-600 mb-6">Register as a vendor to list your equipment and products for lease. Fields marked * are required.</p>

    <?php if (!empty($errors)): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
            <?php foreach ($errors as $err): ?>
                <p><?= htmlspecialchars($err) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <!-- 1. Vendor Basic Information -->
        <div class="form-section">
            <h2 class="text-2xl font-semibold mb-4">1. Vendor Basic Information</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Username *</label>
                    <input type="text" name="username" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Email *</label>
                    <input type="email" name="email" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Password *</label>
                    <input type="password" name="password" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Vendor / Company Name *</label>
                    <input type="text" name="company_name" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Trade Name (if different)</label>
                    <input type="text" name="trade_name" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Year of Establishment</label>
                    <input type="number" name="year_established" min="1900" max="<?= date('Y') ?>" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Country of Registration</label>
                    <input type="text" name="country_registration" value="Ethiopia" class="w-full border border-gray-300 rounded p-2">
                </div>
            </div>

            <div class="mt-4">
                <label class="block text-sm font-medium mb-1">Type of Business (select all that apply)</label>
                <div class="flex flex-wrap gap-4">
                    <?php $businessTypes = ['Sole Proprietorship','Partnership','Private Limited Company (PLC)','Share Company','Importer','Manufacturer','Distributor']; ?>
                    <?php foreach ($businessTypes as $type): ?>
                        <label class="flex items-center gap-2">
                            <input type="checkbox" name="business_type[]" value="<?= $type ?>"> <?= $type ?>
                        </label>
                    <?php endforeach; ?>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="business_type[]" value="Other"> Other: 
                        <input type="text" name="business_type_other" placeholder="Specify" class="border border-gray-300 rounded p-1">
                    </label>
                </div>
            </div>
        </div>

        <!-- 2. Business Registration Details -->
        <div class="form-section">
            <h2 class="text-2xl font-semibold mb-4">2. Business Registration Details</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Business Registration Number</label>
                    <input type="text" name="business_reg_number" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Business License Number</label>
                    <input type="text" name="business_license_number" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Tax Identification Number (TIN) *</label>
                    <input type="text" name="tin" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">VAT Registration Number (if applicable)</label>
                    <input type="text" name="vat_number" class="w-full border border-gray-300 rounded p-2">
                </div>
            </div>
        </div>

        <!-- 3. Contact Information -->
        <div class="form-section">
            <h2 class="text-2xl font-semibold mb-4">3. Contact Information</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Contact Person Name *</label>
                    <input type="text" name="contact_person" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Position / Title</label>
                    <input type="text" name="position" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Mobile Phone *</label>
                    <input type="text" name="mobile_phone" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Office Phone</label>
                    <input type="text" name="office_phone" class="w-full border border-gray-300 rounded p-2">
                </div>
            </div>

            <h3 class="text-xl font-semibold mt-4 mb-2">Business Address</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Region / City</label>
                    <input type="text" name="region_city" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Sub-City / Zone</label>
                    <input type="text" name="zone" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Woreda</label>
                    <input type="text" name="woreda" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Office Address</label>
                    <input type="text" name="office_address" class="w-full border border-gray-300 rounded p-2">
                </div>
            </div>
        </div>

        <!-- 4. Equipment Supply Information -->
        <div class="form-section">
            <h2 class="text-2xl font-semibold mb-4">4. Equipment Supply Information</h2>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Type of Equipment Supplied (select all that apply)</label>
                <div class="flex flex-wrap gap-4">
                    <?php $equipTypes = ['Agricultural Machinery','Construction Machinery','Manufacturing Equipment','Transport Vehicles','Medical Equipment','ICT Equipment']; ?>
                    <?php foreach ($equipTypes as $type): ?>
                        <label class="flex items-center gap-2">
                            <input type="checkbox" name="equipment_types[]" value="<?= $type ?>"> <?= $type ?>
                        </label>
                    <?php endforeach; ?>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="equipment_types[]" value="Other"> Other: 
                        <input type="text" name="equipment_types_other" placeholder="Specify" class="border border-gray-300 rounded p-1">
                    </label>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Brand / Manufacturer Represented</label>
                    <input type="text" name="brand_represented" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Country of Origin of Equipment</label>
                    <input type="text" name="equipment_origin" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Average Supply Capacity (per year)</label>
                    <input type="text" name="avg_supply_capacity" placeholder="e.g., 100 units" class="w-full border border-gray-300 rounded p-2">
                </div>
            </div>
        </div>

        <!-- 5. Technical and Service Capability -->
        <div class="form-section">
            <h2 class="text-2xl font-semibold mb-4">5. Technical and Service Capability</h2>
            <table class="min-w-full divide-y divide-gray-200 mb-4">
                <thead>
                    <tr class="bg-gray-50">
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Service Capability</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Yes</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">No</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $services = ['Installation service','After-sales maintenance','Spare parts supply','Operator training','Warranty provision']; ?>
                    <?php foreach ($services as $service): ?>
                    <tr>
                        <td class="px-4 py-2"><?= $service ?></td>
                        <td class="px-4 py-2"><input type="checkbox" name="<?= strtolower(str_replace(' ', '_', $service)) ?>" value="1"></td>
                        <td class="px-4 py-2"></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div>
                <label class="block text-sm font-medium mb-1">Warranty Period Offered</label>
                <input type="text" name="warranty_period" placeholder="e.g., 1 year" class="w-full border border-gray-300 rounded p-2">
            </div>
        </div>

        <!-- 6. Financial and Banking Information -->
        <div class="form-section">
            <h2 class="text-2xl font-semibold mb-4">6. Financial and Banking Information</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-medium mb-1">Name of Bank</label>
                    <input type="text" name="bank_name" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Bank Account Name</label>
                    <input type="text" name="bank_account_name" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Bank Account Number</label>
                    <input type="text" name="bank_account_number" class="w-full border border-gray-300 rounded p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium mb-1">Branch Name</label>
                    <input type="text" name="bank_branch" class="w-full border border-gray-300 rounded p-2">
                </div>
            </div>
        </div>

        <!-- 7. Previous Experience -->
        <div class="form-section">
            <h2 class="text-2xl font-semibold mb-4">7. Previous Experience</h2>
            <div class="mb-4">
                <label class="block text-sm font-medium mb-1">Number of years supplying capital goods</label>
                <input type="number" name="years_supplying" min="0" class="w-full border border-gray-300 rounded p-2">
            </div>
            <h3 class="text-xl font-semibold mb-2">Major Clients / Institutions Supplied</h3>
            <table id="clientsTable" class="dynamic-table min-w-full divide-y divide-gray-200">
                <thead>
                    <tr class="bg-gray-50">
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Client Name</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Equipment Supplied</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Year</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="client-row">
                        <td><input type="text" name="client_name[]" class="w-full border border-gray-300 rounded p-1"></td>
                        <td><input type="text" name="client_equipment[]" class="w-full border border-gray-300 rounded p-1"></td>
                        <td><input type="number" name="client_year[]" min="1900" max="<?= date('Y') ?>" class="w-full border border-gray-300 rounded p-1"></td>
                        <td><button type="button" onclick="removeRow(this)" class="bg-red-500 text-white px-2 py-1 rounded text-sm">Remove</button></td>
                    </tr>
                </tbody>
            </table>
            <button type="button" onclick="addClientRow()" class="bg-blue-500 text-white px-4 py-2 rounded mt-2">Add Client</button>
        </div>

        <!-- 8. Documents to be Attached -->
        <div class="form-section">
            <h2 class="text-2xl font-semibold mb-4">8. Documents to be Attached</h2>
            <p class="mb-2">Upload multiple documents and indicate the type for each.</p>
            <div id="documents-container">
                <div class="document-row flex gap-2 mb-2">
                    <input type="file" name="documents[]" accept=".pdf,.jpg,.png,.jpeg" class="flex-1 border border-gray-300 rounded p-2">
                    <select name="doc_type[]" class="border border-gray-300 rounded p-2">
                        <option value="license">Business License</option>
                        <option value="registration">Business Registration Certificate</option>
                        <option value="tin">TIN Certificate</option>
                        <option value="vat">VAT Certificate</option>
                        <option value="profile">Company Profile</option>
                        <option value="catalogue">Product Catalogue / Brochure</option>
                        <option value="dealer">Authorized Dealer Certificate</option>
                        <option value="other">Other</option>
                    </select>
                    <button type="button" onclick="removeDocumentRow(this)" class="bg-red-500 text-white px-3 py-1 rounded">Remove</button>
                </div>
            </div>
            <button type="button" onclick="addDocumentRow()" class="bg-blue-500 text-white px-4 py-2 rounded mt-2">Add Another Document</button>
        </div>

        <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg transition duration-200">Register as Vendor</button>
    </form>
</div>

<script>
function addClientRow() {
    const table = document.getElementById('clientsTable').getElementsByTagName('tbody')[0];
    const newRow = document.querySelector('.client-row').cloneNode(true);
    const inputs = newRow.getElementsByTagName('input');
    for (let input of inputs) input.value = '';
    table.appendChild(newRow);
}
function removeRow(btn) {
    const row = btn.closest('tr');
    const tbody = row.parentNode;
    if (tbody.getElementsByTagName('tr').length > 1) {
        row.remove();
    } else {
        alert('You must keep at least one row.');
    }
}
function addDocumentRow() {
    const container = document.getElementById('documents-container');
    const newRow = document.querySelector('.document-row').cloneNode(true);
    const fileInput = newRow.querySelector('input[type="file"]');
    if (fileInput) fileInput.value = '';
    container.appendChild(newRow);
}
function removeDocumentRow(btn) {
    const row = btn.closest('.document-row');
    const container = document.getElementById('documents-container');
    if (container.children.length > 1) {
        row.remove();
    } else {
        alert('You must keep at least one document row.');
    }
}
</script>

<?php include __DIR__ . '/../../partials/footer.php'; ?>