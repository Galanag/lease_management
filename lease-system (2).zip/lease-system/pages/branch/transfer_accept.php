<?php
// pages/branch/transfer_accept.php
$pageTitle = 'Transfer Requests';
require_once __DIR__ . '/../../config.php';
if (!isBranchStaff()) redirect(BASE_URL . '?page=home');

$db = getDb();
$branch_id = getCurrentBranchId();

// Handle acceptance/rejection
if (isset($_GET['accept'])) {
    $req_id = intval($_GET['accept']);
    // Verify that the request is for this branch
    $req = $db->querySingle("SELECT * FROM transfer_requests WHERE id = $req_id AND to_branch_id = $branch_id AND status = 'pending'", true);
    if ($req) {
        $db->exec("UPDATE transfer_requests SET status = 'accepted', responded_at = datetime('now') WHERE id = $req_id");
        // Update application branch
        $db->exec("UPDATE applications SET branch_id = $branch_id WHERE id = {$req['application_id']}");
        addNotification($req['requested_by_user'], $req['application_id'], "Your transfer request has been accepted by the branch.", "?page=view_application&id={$req['application_id']}");
        addNotification(1, $req['application_id'], "Transfer request accepted by branch.", "?page=admin_transfer_requests");
        $_SESSION['message'] = 'Transfer accepted.';
    }
    redirect(BASE_URL . '?page=branch_transfer_accept');
}
if (isset($_GET['reject'])) {
    $req_id = intval($_GET['reject']);
    $req = $db->querySingle("SELECT * FROM transfer_requests WHERE id = $req_id AND to_branch_id = $branch_id AND status = 'pending'", true);
    if ($req) {
        $db->exec("UPDATE transfer_requests SET status = 'rejected', responded_at = datetime('now') WHERE id = $req_id");
        addNotification($req['requested_by_user'], $req['application_id'], "Your transfer request has been rejected by the branch.", "");
        addNotification(1, $req['application_id'], "Transfer request rejected by branch.", "?page=admin_transfer_requests");
        $_SESSION['message'] = 'Transfer rejected.';
    }
    redirect(BASE_URL . '?page=branch_transfer_accept');
}

$requests = $db->query("SELECT r.*, a.lease_id, u.username as requester_name, fb.name as from_branch
                        FROM transfer_requests r
                        JOIN applications a ON r.application_id = a.id
                        JOIN users u ON r.requested_by_user = u.id
                        JOIN branches fb ON r.from_branch_id = fb.id
                        WHERE r.to_branch_id = $branch_id AND r.status = 'pending'
                        ORDER BY r.requested_at DESC");
?>
<?php include __DIR__ . '/../partials/header.php'; ?>

<main class="container">
    <h1><i class="fas fa-exchange-alt"></i> Transfer Requests for Your Branch</h1>
    <?php if (isset($_SESSION['message'])) echo "<p class='success'>".$_SESSION['message']."</p>"; unset($_SESSION['message']); ?>
    <?php if (isset($_SESSION['error'])) echo "<p class='error'>".$_SESSION['error']."</p>"; unset($_SESSION['error']); ?>

    <?php if (!$requests->numColumns()): ?>
        <p>No pending transfer requests.</p>
    <?php else: ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Lease ID</th>
                        <th>Requester</th>
                        <th>From Branch</th>
                        <th>Reason</th>
                        <th>Requested</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php while($r = $requests->fetchArray(SQLITE3_ASSOC)): ?>
                    <tr>
                        <td><?= $r['lease_id'] ?></td>
                        <td><?= htmlspecialchars($r['requester_name']) ?></td>
                        <td><?= htmlspecialchars($r['from_branch']) ?></td>
                        <td><?= htmlspecialchars($r['reason']) ?></td>
                        <td><?= $r['requested_at'] ?></td>
                        <td>
                            <a href="?page=branch_transfer_accept&accept=<?= $r['id'] ?>" class="btn-small success" onclick="return confirm('Accept this transfer?')">Accept</a>
                            <a href="?page=branch_transfer_accept&reject=<?= $r['id'] ?>" class="btn-small danger" onclick="return confirm('Reject this transfer?')">Reject</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</main>

<style>
.btn-small.success { background: #10b981; color: white; padding: 0.25rem 0.5rem; border-radius: 0.25rem; text-decoration: none; }
.btn-small.danger { background: #b91c1c; color: white; padding: 0.25rem 0.5rem; border-radius: 0.25rem; text-decoration: none; }
</style>

<?php include __DIR__ . '/../partials/footer.php'; ?>