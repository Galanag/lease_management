<?php
// pages/calculator.php
$pageTitle = 'Lease Calculator';
require_once __DIR__ . '/../config.php';

$db = getDb();

// Fetch all products for dropdown (sector will filter them client‑side)
$allProducts = [];
$productsRes = $db->query("SELECT id, name, price, sector FROM products WHERE available = 1 AND status = 'approved' ORDER BY name");
while ($p = $productsRes->fetchArray(SQLITE3_ASSOC)) {
    $allProducts[] = $p;
}

// Fetch sectors (excluding Employees)
$sectors = $db->query("SELECT sector FROM down_payment_rates WHERE sector != 'Employees' ORDER BY sector");

include __DIR__ . '/../partials/header.php';
?>

<div class="container mx-auto px-4 py-8 max-w-4xl">
    <h1 class="text-3xl font-bold mb-6">Lease Payment Calculator</h1>
    <p class="text-gray-600 mb-6">Use this tool to estimate your lease payments based on the sector, product, and financing terms.</p>

    <!-- Calculator Form -->
    <div class="bg-white p-6 rounded shadow">
        <!-- Sector constants info box -->
        <div id="sector-info-box" class="bg-blue-50 p-4 rounded mb-4 hidden">
            <h3 class="font-semibold text-blue-800">Sector Information</h3>
            <div class="grid grid-cols-3 gap-4 mt-2 text-sm">
                <div><strong>Application Fee:</strong> <span id="display-app-fee">-</span></div>
                <div><strong>Minimum Down Payment:</strong> <span id="display-down-payment">-</span>%</div>
                <div><strong>Service Charge Range:</strong> <span id="display-service-charge">-</span></div>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Sector *</label>
                <select name="sector" id="sector" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select sector</option>
                    <?php while ($s = $sectors->fetchArray(SQLITE3_ASSOC)): ?>
                        <option value="<?= $s['sector'] ?>"><?= $s['sector'] ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Equipment / Product</label>
                <select name="product_id" id="product_select" class="w-full border border-gray-300 rounded p-2">
                    <option value="">Select a product (or enter price manually)</option>
                    <!-- Options will be filled by JS -->
                </select>
                <input type="number" name="manual_price" id="manual_price" placeholder="Or enter price manually" class="w-full border border-gray-300 rounded p-2 mt-2" step="0.01">
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div>
                <label class="block text-sm font-medium mb-1">Requested Financing Amount (ETB) *</label>
                <input type="number" name="price" id="price" required step="0.01" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Down Payment (Equity) (ETB) *</label>
                <input type="number" name="down" id="down" required step="0.01" class="w-full border border-gray-300 rounded p-2">
                <p class="text-xs text-gray-500 mt-1">Minimum: <span id="min_down_display">0</span>% of total</p>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Lease Term (months)</label>
                <select name="term" id="term" class="w-full border border-gray-300 rounded p-2">
                    <?php for ($t=12; $t<=84; $t+=12): ?>
                        <option value="<?= $t ?>"><?= $t/12 ?> year<?= $t>12?'s':'' ?> (<?= $t ?> months)</option>
                    <?php endfor; ?>
                </select>
                <p id="term_note" class="text-xs text-gray-500"></p>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Repayment Frequency</label>
                <select name="freq" id="freq" class="w-full border border-gray-300 rounded p-2">
                    <option value="Monthly">Monthly</option>
                    <option value="Quarterly">Quarterly</option>
                    <option value="Semi-Annual">Semi-Annual</option>
                </select>
                <p id="freq_note" class="text-xs text-gray-500"></p>
            </div>
        </div>

        <!-- Results -->
        <div id="results" class="bg-gray-50 p-4 rounded mt-4" style="display:none;">
            <h3 class="text-lg font-semibold">Estimated Payment</h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-2">
                <div><span class="text-sm text-gray-600">Financed Amount:</span><br><span id="result-financed" class="font-semibold">ETB 0.00</span></div>
                <div><span class="text-sm text-gray-600">Service Fee:</span><br><span id="result-service-fee" class="font-semibold">ETB 0.00</span></div>
                <div><span class="text-sm text-gray-600">Total Payment:</span><br><span id="result-total" class="font-semibold">ETB 0.00</span></div>
                <div><span class="text-sm text-gray-600">Installment:</span><br><span id="result-installment" class="font-semibold">ETB 0.00</span></div>
            </div>
        </div>
    </div>
</div>

<script>
// Sector constants (same as in apply.php)
const sectorConstants = {
    'IMX': { appFee: 500, downRate: 10, serviceRange: '20% - 22%' },
    'Agriculture': { appFee: 1500, downRate: 20, serviceRange: '20% - 22%' },
    'Manufacturing': { appFee: 1500, downRate: 15, serviceRange: '20% - 22.5%' },
    'Services': { appFee: 1500, downRate: 20, serviceRange: '20% - 22.5%' },
    'Construction': { appFee: 2000, downRate: 25, serviceRange: '21% - 23%' }
};

// Service charge rates (same as apply.php)
const serviceRates = {
    'IMX': {
        1: 20, 2: 20,
        3: 20.5, 4: 20.5,
        5: 21.5,
        6: 22, 7: 22
    },
    'Agriculture': {
        1: 20, 2: 20,
        3: 21.5, 4: 21.5,
        5: 22,
        6: null, 7: null
    },
    'Manufacturing': {
        1: 20, 2: 20,
        3: 21.5, 4: 21.5,
        5: 22,
        6: 22.5, 7: 22.5
    },
    'Services': {
        1: 20, 2: 20,
        3: 21.5, 4: 21.5,
        5: 22,
        6: 22.5, 7: 22.5
    },
    'Construction': {
        1: 21, 2: 21,
        3: 21.5, 4: 21.5,
        5: 22.5,
        6: 23, 7: 23
    }
};

// Allowed frequencies per sector (base)
const allowedFrequencies = {
    'IMX': ['Monthly', 'Quarterly'],
    'Agriculture': ['Monthly', 'Quarterly', 'Semi-Annual'],
    'Manufacturing': ['Monthly', 'Quarterly'],
    'Services': ['Monthly'],
    'Construction': ['Monthly', 'Quarterly']
};

// Product data from PHP
const allProducts = <?= json_encode($allProducts) ?>;

function getServiceRate(sector, termMonths) {
    if (!sector || !serviceRates[sector]) return null;
    const years = Math.ceil(termMonths / 12);
    const rate = serviceRates[sector][years];
    return rate !== undefined ? rate : null;
}

function updateSectorInfo() {
    const sector = document.getElementById('sector').value;
    const term = parseInt(document.getElementById('term').value) || 12;
    const infoBox = document.getElementById('sector-info-box');
    const termNote = document.getElementById('term_note');
    const freqSelect = document.getElementById('freq');
    const freqNote = document.getElementById('freq_note');

    if (!sector) {
        infoBox.classList.add('hidden');
        document.getElementById('results').style.display = 'none';
        return;
    }

    const data = sectorConstants[sector];
    if (data) {
        document.getElementById('display-app-fee').innerText = 'ETB ' + data.appFee;
        document.getElementById('display-down-payment').innerText = data.downRate;
        document.getElementById('display-service-charge').innerText = data.serviceRange;
        infoBox.classList.remove('hidden');
    }

    // Term note for Agriculture
    const years = term / 12;
    if (sector === 'Agriculture' && years > 5) {
        termNote.innerText = 'Agriculture sector maximum term is 5 years (60 months).';
    } else {
        termNote.innerText = '';
    }

    // Update frequency dropdown
    const allowed = allowedFrequencies[sector] || ['Monthly'];
    const currentFreq = freqSelect.value;
    freqSelect.innerHTML = '';
    allowed.forEach(freq => {
        const option = document.createElement('option');
        option.value = freq;
        option.text = freq;
        if (freq === currentFreq) option.selected = true;
        freqSelect.appendChild(option);
    });
    if (!allowed.includes(currentFreq)) {
        freqSelect.value = allowed[0];
    }
    freqNote.innerText = allowed.includes('Semi-Annual') ? '' : 'Semi-annual not allowed for this sector.';

    // Update product dropdown based on sector
    updateProductDropdown(sector);

    // Update minimum down payment display
    document.getElementById('min_down_display').innerText = data.downRate;
    calculate();
}

function updateProductDropdown(sector) {
    const select = document.getElementById('product_select');
    if (!sector) {
        select.innerHTML = '<option value="">Select a product (or enter price manually)</option>';
        return;
    }
    const productsInSector = allProducts.filter(p => p.sector === sector);
    select.innerHTML = '<option value="">Select a product (or enter price manually)</option>';
    productsInSector.forEach(p => {
        const option = document.createElement('option');
        option.value = p.price;
        option.textContent = `${p.name} (ETB ${p.price})`;
        select.appendChild(option);
    });
}

function setPriceFromProduct() {
    const select = document.getElementById('product_select');
    const priceField = document.getElementById('price');
    if (select.value) {
        priceField.value = parseFloat(select.value).toFixed(2);
        calculate();
    }
}

function setMinimumDownPayment() {
    const sector = document.getElementById('sector').value;
    const price = parseFloat(document.getElementById('price').value) || 0;
    const downRate = sectorConstants[sector]?.downRate;
    if (downRate && price > 0) {
        const minDown = price * (downRate / 100);
        const downField = document.getElementById('down');
        if (!downField.value || parseFloat(downField.value) < minDown) {
            downField.value = minDown.toFixed(2);
        }
    }
}

function calculate() {
    const sector = document.getElementById('sector').value;
    const price = parseFloat(document.getElementById('price').value) || 0;
    const down = parseFloat(document.getElementById('down').value) || 0;
    const term = parseInt(document.getElementById('term').value) || 12;
    const freq = document.getElementById('freq').value;
    const rate = getServiceRate(sector, term);

    if (!sector || !rate || price <= 0) {
        document.getElementById('results').style.display = 'none';
        return;
    }

    const financed = price - down;
    const serviceFee = financed * (rate/100) * (term / 12);
    const total = financed + serviceFee;

    let numInstallments;
    switch (freq) {
        case 'Monthly': numInstallments = term; break;
        case 'Quarterly': numInstallments = Math.ceil(term / 3); break;
        case 'Semi-Annual': numInstallments = Math.ceil(term / 6); break;
        default: numInstallments = term;
    }
    const installment = total / numInstallments;

    document.getElementById('result-financed').innerHTML = 'ETB ' + financed.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('result-service-fee').innerHTML = 'ETB ' + serviceFee.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('result-total').innerHTML = 'ETB ' + total.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('result-installment').innerHTML = 'ETB ' + installment.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    document.getElementById('results').style.display = 'block';
}

// Attach event listeners
document.getElementById('sector').addEventListener('change', updateSectorInfo);
document.getElementById('product_select').addEventListener('change', setPriceFromProduct);
document.getElementById('price').addEventListener('input', function() { calculate(); setMinimumDownPayment(); });
document.getElementById('down').addEventListener('input', calculate);
document.getElementById('term').addEventListener('change', function() { updateSectorInfo(); calculate(); });
document.getElementById('freq').addEventListener('change', calculate);

// Initialize
updateSectorInfo();
</script>

<?php include __DIR__ . '/../partials/footer.php'; ?>