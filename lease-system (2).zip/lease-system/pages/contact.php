<?php
// pages/contact.php
$pageTitle = 'Contact Us';
require_once __DIR__ . '/../config.php';

$db = getDb();

// Fetch all branches with their zones (grouped)
$branchesWithZones = $db->query("
    SELECT b.id, b.name, b.city, 
           GROUP_CONCAT(z.name, ', ') as zones
    FROM branches b
    LEFT JOIN zones z ON b.id = z.branch_id
    GROUP BY b.id
    ORDER BY b.name
");

// Fetch headquarters contact info
$contact = $db->querySingle("SELECT * FROM contact_info WHERE id = 1", true);
if (!$contact) {
    $contact = ['address' => 'Addis Ababa, Ethiopia', 'phone' => '+251 911 234 567', 'manager' => 'John Doe'];
}

include __DIR__ . '/../partials/header.php';
?>

<div class="max-w-7xl mx-auto">
    <h1 class="text-3xl font-bold mb-6">Contact Us</h1>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        <!-- Head Office Card -->
        <div class="bg-white p-6 rounded shadow">
            <h2 class="text-xl font-semibold mb-4">Head Office</h2>
            <p><strong>Address:</strong> <?= htmlspecialchars($contact['address']) ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($contact['phone']) ?></p>
            <p><strong>Manager:</strong> <?= htmlspecialchars($contact['manager']) ?></p>
        </div>

        <!-- Contact Form Card -->
        <div class="bg-white p-6 rounded shadow">
            <h2 class="text-xl font-semibold mb-4">Send a Message</h2>
            <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])): ?>
                <div class="mb-4 p-3 bg-green-100 text-green-700 rounded">Thank you! We'll get back to you soon.</div>
            <?php endif; ?>
            <form method="post">
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Name *</label>
                    <input type="text" name="name" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Email *</label>
                    <input type="email" name="email" required class="w-full border border-gray-300 rounded p-2">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1">Message *</label>
                    <textarea name="message" rows="4" required class="w-full border border-gray-300 rounded p-2"></textarea>
                </div>
                <button type="submit" name="send_message" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Send Message</button>
            </form>
        </div>
    </div>

    <h2 class="text-2xl font-semibold mb-4">Our Branches & Service Areas</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php while ($branch = $branchesWithZones->fetchArray(SQLITE3_ASSOC)): ?>
            <div class="bg-white p-4 rounded shadow">
                <h3 class="font-bold text-lg text-green-700"><?= htmlspecialchars($branch['name']) ?></h3>
                <?php if ($branch['city']): ?>
                    <p class="text-sm text-gray-600">📍 <?= htmlspecialchars($branch['city']) ?></p>
                <?php endif; ?>
                <?php if (!empty($branch['zones'])): ?>
                    <div class="mt-2">
                        <p class="text-sm font-medium text-gray-700">Service Areas:</p>
                        <ul class="text-sm text-gray-600 list-disc list-inside">
                            <?php
                            $zones = explode(',', $branch['zones']);
                            foreach ($zones as $zone):
                                $zone = trim($zone);
                                if ($zone):
                            ?>
                                <li><?= htmlspecialchars($zone) ?></li>
                            <?php endif; endforeach; ?>
                        </ul>
                    </div>
                <?php else: ?>
                    <p class="text-sm text-gray-500 mt-2">No specific zones listed.</p>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>