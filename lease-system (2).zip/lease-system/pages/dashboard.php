<?php
// pages/dashboard.php
require_once __DIR__ . '/../config.php';
requireAdmin();
if (!isLoggedIn() || $_SESSION['user_role'] !== 'client') {
    redirect(BASE_URL . '?page=login');
}

$db = getDb();
$user_id = $_SESSION['user_id'];

// Fetch the client's most recent application (for demo; handle multiple later)
$app = $db->querySingle("SELECT * FROM applications WHERE user_id = $user_id ORDER BY created_at DESC LIMIT 1", true);
if (!$app) {
    // No application yet
    $noApp = true;
} else {
    // Fetch stages for this application
    $stages = $db->query("SELECT * FROM application_stages WHERE application_id = {$app['id']} ORDER BY stage_number");
    $stagesList = [];
    while ($row = $stages->fetchArray(SQLITE3_ASSOC)) {
        $stagesList[] = $row;
    }
    // Fetch documents
    $docs = $db->query("SELECT * FROM documents WHERE application_id = {$app['id']} ORDER BY uploaded_at DESC");
    // Fetch document requirements for current stage
    $currentStage = $app['current_stage'];
    $reqs = $db->query("SELECT * FROM document_requirements WHERE stage_number <= $currentStage");
    // Fetch payment schedule
    $schedule = $db->querySingle("SELECT * FROM payment_schedules WHERE application_id = {$app['id']}", true);
    if ($schedule) {
        $installments = $db->query("SELECT * FROM installments WHERE schedule_id = {$schedule['id']} ORDER BY due_date");
    }
    // Fetch service requests
    $requests = $db->query("SELECT * FROM service_requests WHERE application_id = {$app['id']} ORDER BY created_at DESC");
}

include __DIR__ . '/../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">My Lease Dashboard</h1>

    <?php if (isset($noApp)): ?>
        <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6">
            <p>You haven't started an application yet. <a href="?page=apply" class="underline">Apply now</a>.</p>
        </div>
    <?php else: ?>
        <!-- Application Summary Card -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 class="text-xl font-semibold mb-2">Application #<?= $app['lease_id'] ?? $app['id'] ?></h2>
            <p class="text-gray-600">Submitted: <?= date('F j, Y', strtotime($app['created_at'])) ?></p>
            <p class="text-gray-600">Status: <span class="font-medium text-green-600"><?= ucfirst($app['status']) ?></span></p>
        </div>

        <!-- Visual Progress Bar -->
        <div class="mb-8">
            <h3 class="text-lg font-semibold mb-3">Application Progress</h3>
            <div class="relative">
                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                    <div style="width: <?= ($app['current_stage'] / 8) * 100 ?>%" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-500"></div>
                </div>
                <div class="flex justify-between text-xs text-gray-600">
                    <span>Inquiry</span>
                    <span>Application</span>
                    <span>Assessment</span>
                    <span>Approval</span>
                    <span>Contract</span>
                    <span>Procurement</span>
                    <span>Disbursement</span>
                    <span>Active</span>
                </div>
            </div>
        </div>

        <!-- Stage Details -->
        <div class="grid md:grid-cols-2 gap-6 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold mb-3">Current Stage: <?= $stagesList[$app['current_stage']-1]['stage_name'] ?></h3>
                <?php if ($app['current_stage'] < 8): ?>
                    <p class="text-gray-600 mb-2">Next: <?= $stagesList[$app['current_stage']]['stage_name'] ?? 'Completed' ?></p>
                    <p class="text-sm text-gray-500">Expected completion: <?= $stagesList[$app['current_stage']-1]['expected_completion'] ?? '3-5 working days' ?></p>
                <?php else: ?>
                    <p class="text-green-600">Your lease is active!</p>
                <?php endif; ?>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold mb-3">Assigned Contact</h3>
                <p class="text-gray-600">John Doe (Relationship Manager)</p>
                <p class="text-sm text-gray-500">john.doe@siinqee.com | +251 911 234 567</p>
            </div>
        </div>

        <!-- Document Checklist -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 class="text-lg font-semibold mb-3">Document Checklist</h3>
            <ul class="divide-y">
                <?php
                $requiredDocs = [];
                while ($req = $reqs->fetchArray(SQLITE3_ASSOC)) {
                    $requiredDocs[$req['document_type']] = $req;
                }
                // Mark uploaded docs
                $uploadedDocs = [];
                while ($doc = $docs->fetchArray(SQLITE3_ASSOC)) {
                    $uploadedDocs[$doc['document_type']] = $doc;
                }
                foreach ($requiredDocs as $type => $req):
                    $uploaded = isset($uploadedDocs[$type]);
                    $verified = $uploaded && $uploadedDocs[$type]['is_verified'];
                ?>
                <li class="py-3 flex items-center justify-between">
                    <span><?= htmlspecialchars($req['description']) ?></span>
                    <?php if ($verified): ?>
                        <span class="text-green-600 text-sm">✓ Verified</span>
                    <?php elseif ($uploaded): ?>
                        <span class="text-yellow-600 text-sm">⏳ Pending verification</span>
                    <?php else: ?>
                        <span class="text-red-600 text-sm">✗ Missing</span>
                        <a href="?page=upload_document&type=<?= urlencode($type) ?>" class="text-blue-600 text-sm underline">Upload</a>
                    <?php endif; ?>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Payment Schedule -->
        <?php if ($schedule): ?>
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h3 class="text-lg font-semibold mb-3">Payment Schedule</h3>
            <p class="text-gray-600 mb-2">Total financed: ETB <?= number_format($schedule['total_financed'], 2) ?></p>
            <p class="text-gray-600 mb-2">Total repayment: ETB <?= number_format($schedule['total_repayment'], 2) ?></p>
            <table class="min-w-full divide-y divide-gray-200 mt-4">
                <thead>
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Due Date</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Amount</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    <?php while ($inst = $installments->fetchArray(SQLITE3_ASSOC)): ?>
                    <tr>
                        <td class="px-4 py-2"><?= date('M j, Y', strtotime($inst['due_date'])) ?></td>
                        <td class="px-4 py-2">ETB <?= number_format($inst['amount'], 2) ?></td>
                        <td class="px-4 py-2">
                            <?php if ($inst['status'] == 'paid'): ?>
                                <span class="text-green-600">Paid</span>
                            <?php elseif ($inst['status'] == 'overdue'): ?>
                                <span class="text-red-600">Overdue</span>
                            <?php else: ?>
                                <span class="text-gray-600">Pending</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <!-- Service Requests -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-3">
                <h3 class="text-lg font-semibold">Service Requests</h3>
                <a href="?page=new_service_request" class="bg-blue-600 text-white px-4 py-2 rounded text-sm">New Request</a>
            </div>
            <?php if ($requests && $requests->numColumns() > 0): ?>
                <ul class="divide-y">
                    <?php while ($req = $requests->fetchArray(SQLITE3_ASSOC)): ?>
                    <li class="py-3">
                        <p class="font-medium"><?= htmlspecialchars($req['subject']) ?></p>
                        <p class="text-sm text-gray-600"><?= htmlspecialchars($req['description']) ?></p>
                        <p class="text-xs text-gray-400 mt-1">Status: <?= ucfirst($req['status']) ?></p>
                    </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p class="text-gray-500">No service requests yet.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>