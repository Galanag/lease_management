<?php
// pages/dashboard/admin.php
$pageTitle = 'Admin Dashboard';
require_once __DIR__ . '/../../config.php';
if (!isAdmin()) redirect(BASE_URL . '?page=home');

$db = getDb();

$stats = [
    'users' => $db->querySingle("SELECT COUNT(*) FROM users"),
    'vendors' => $db->querySingle("SELECT COUNT(*) FROM users WHERE role = 'vendor'"),
    'applications' => $db->querySingle("SELECT COUNT(*) FROM applications"),
    'pending' => $db->querySingle("SELECT COUNT(*) FROM applications WHERE status = 'pending'"),
    'pending_products' => $db->querySingle("SELECT COUNT(*) FROM products WHERE status = 'pending'"),
];

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-8">Admin Dashboard</h1>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow p-6 text-center card-hover">
            <div class="text-4xl text-blue-600 mb-2"><i class="fas fa-users"></i></div>
            <div class="text-2xl font-bold"><?= $stats['users'] ?></div>
            <div class="text-gray-600">Total Users</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6 text-center card-hover">
            <div class="text-4xl text-green-600 mb-2"><i class="fas fa-truck"></i></div>
            <div class="text-2xl font-bold"><?= $stats['vendors'] ?></div>
            <div class="text-gray-600">Vendors</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6 text-center card-hover">
            <div class="text-4xl text-purple-600 mb-2"><i class="fas fa-file-alt"></i></div>
            <div class="text-2xl font-bold"><?= $stats['applications'] ?></div>
            <div class="text-gray-600">Total Applications</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6 text-center card-hover">
            <div class="text-4xl text-yellow-600 mb-2"><i class="fas fa-clock"></i></div>
            <div class="text-2xl font-bold"><?= $stats['pending'] ?></div>
            <div class="text-gray-600">Pending Applications</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6 text-center card-hover">
            <div class="text-4xl text-red-600 mb-2"><i class="fas fa-box"></i></div>
            <div class="text-2xl font-bold"><?= $stats['pending_products'] ?></div>
            <div class="text-gray-600">Pending Products</div>
        </div>
    </div>

    <!-- Quick Action Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <a href="?page=admin_users" class="block bg-white rounded-lg shadow p-6 hover:shadow-lg transition card-hover">
            <div class="flex items-center">
                <div class="text-3xl text-blue-600 mr-4"><i class="fas fa-user-cog"></i></div>
                <div>
                    <h3 class="text-xl font-semibold">Manage Users</h3>
                    <p class="text-gray-600">Approve clients, vendors, and manage roles</p>
                </div>
            </div>
        </a>
        <a href="?page=admin_add_application" class="block bg-white rounded-lg shadow p-6 hover:shadow-lg transition card-hover">
            <div class="flex items-center">
                <div class="text-3xl text-indigo-600 mr-4"><i class="fas fa-plus-circle"></i></div>
                <div>
                    <h3 class="text-xl font-semibold">Add Application</h3>
                    <p class="text-gray-600">Create a new lease application on behalf of a client</p>
                </div>
            </div>
        </a>
        <a href="?page=admin_products" class="block bg-white rounded-lg shadow p-6 hover:shadow-lg transition card-hover">
            <div class="flex items-center">
                <div class="text-3xl text-green-600 mr-4"><i class="fas fa-boxes"></i></div>
                <div>
                    <h3 class="text-xl font-semibold">Manage Products</h3>
                    <p class="text-gray-600">Approve or reject vendor products</p>
                </div>
            </div>
        </a>
        <a href="?page=admin_applications" class="block bg-white rounded-lg shadow p-6 hover:shadow-lg transition card-hover">
            <div class="flex items-center">
                <div class="text-3xl text-purple-600 mr-4"><i class="fas fa-file-signature"></i></div>
                <div>
                    <h3 class="text-xl font-semibold">View Applications</h3>
                    <p class="text-gray-600">Review lease applications and update stages</p>
                </div>
            </div>
        </a>
        <a href="?page=admin_branches" class="block bg-white rounded-lg shadow p-6 hover:shadow-lg transition card-hover">
            <div class="flex items-center">
                <div class="text-3xl text-yellow-600 mr-4"><i class="fas fa-store"></i></div>
                <div>
                    <h3 class="text-xl font-semibold">Manage Branches</h3>
                    <p class="text-gray-600">Add or edit branch information</p>
                </div>
            </div>
        </a>
        <a href="?page=admin_reports" class="block bg-white rounded-lg shadow p-6 hover:shadow-lg transition card-hover">
            <div class="flex items-center">
                <div class="text-3xl text-red-600 mr-4"><i class="fas fa-chart-bar"></i></div>
                <div>
                    <h3 class="text-xl font-semibold">Reports</h3>
                    <p class="text-gray-600">View financial and activity reports</p>
                </div>
            </div>
        </a>
        <a href="?page=admin_transfer_requests" class="block bg-white rounded-lg shadow p-6 hover:shadow-lg transition card-hover">
            <div class="flex items-center">
                <div class="text-3xl text-indigo-600 mr-4"><i class="fas fa-exchange-alt"></i></div>
                <div>
                    <h3 class="text-xl font-semibold">Transfer Requests</h3>
                    <p class="text-gray-600">Review branch transfer requests</p>
                </div>
            </div>
        </a>
    </div>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>