<?php
// pages/dashboard/branch.php
$pageTitle = 'Branch Dashboard';
require_once __DIR__ . '/../../config.php';
if (!isBranchStaff()) redirect(BASE_URL . '?page=home');

$db = getDb();
// $branch_id = getCurrentBranchId();
$branch_id = getCurrentBranchId();
if (!$branch_id) {
    // Handle case where user is not a manager of any branch
    echo 'You are not assigned to any branch.';
    exit;
}

// Get all sub‑branch IDs (including current branch)
function getBranchTreeIds($db, $branch_id) {
    $ids = [$branch_id];
    $queue = [$branch_id];
    while (!empty($queue)) {
        $current = array_shift($queue);
        $res = $db->query("SELECT id FROM branches WHERE parent_id = $current");
        while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
            $ids[] = $row['id'];
            $queue[] = $row['id'];
        }
    }
    return $ids;
}
$branch_ids = getBranchTreeIds($db, $branch_id);
$branch_list = implode(',', $branch_ids);

// Fetch applications for these branches
$apps = $db->query("SELECT a.*, u.username, p.name as product_name 
                    FROM applications a 
                    JOIN users u ON a.user_id = u.id 
                    JOIN products p ON a.product_id = p.id 
                    WHERE a.branch_id IN ($branch_list)
                    ORDER BY a.created_at DESC");

// Count pending transfer requests to this branch
$pending_transfers = $db->querySingle("SELECT COUNT(*) FROM transfer_requests WHERE to_branch_id = $branch_id AND status = 'pending'");
?>
<?php include __DIR__ . '/../../partials/header.php'; ?>

<main class="container">
    <h1><i class="fas fa-store-alt"></i> Branch Dashboard</h1>

    <?php if ($pending_transfers > 0): ?>
        <div class="alert info">
            <i class="fas fa-exchange-alt"></i> You have <?= $pending_transfers ?> pending transfer request(s).
            <a href="<?= BASE_URL ?>?page=branch_transfer_accept" class="button small">View Requests</a>
        </div>
    <?php endif; ?>

    <div class="quick-stats">
        <div class="stat-card">
            <i class="fas fa-file-alt"></i>
            <div>Total Applications</div>
            <strong><?= $db->querySingle("SELECT COUNT(*) FROM applications WHERE branch_id IN ($branch_list)") ?></strong>
        </div>
        <div class="stat-card">
            <i class="fas fa-clock"></i>
            <div>Pending Forward</div>
            <strong><?= $db->querySingle("SELECT COUNT(*) FROM applications WHERE branch_id IN ($branch_list) AND forwarded_to_head_office = 0 AND status IN ('Submitted','Under Review')") ?></strong>
        </div>
        <div class="stat-card">
            <i class="fas fa-check-circle"></i>
            <div>Active Leases</div>
            <strong><?= $db->querySingle("SELECT COUNT(*) FROM applications WHERE branch_id IN ($branch_list) AND status = 'Active'") ?></strong>
        </div>
    </div>

    <h2>Applications for Your Branch</h2>
    <?php if (!$apps->numColumns()): ?>
        <p>No applications found for your branch.</p>
    <?php else: ?>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Lease ID</th>
                        <th>Client</th>
                        <th>Product</th>
                        <th>Status</th>
                        <th>Stage</th>
                        <th>Forwarded</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php while($app = $apps->fetchArray(SQLITE3_ASSOC)): ?>
                    <tr>
                        <td><?= $app['lease_id'] ?></td>
                        <td><?= htmlspecialchars($app['username']) ?></td>
                        <td><?= htmlspecialchars($app['product_name']) ?></td>
                        <td><?= $app['status'] ?></td>
                        <td><?= $app['current_stage'] ?>/8</td>
                        <td><?= $app['forwarded_to_head_office'] ? 'Yes' : 'No' ?></td>
                        <td>
                            <a href="<?= BASE_URL ?>?page=view_application&id=<?= $app['id'] ?>" class="btn-small">View</a>
                            <?php if (!$app['forwarded_to_head_office'] && in_array($app['status'], ['Submitted','Under Review'])): ?>
                                <a href="<?= BASE_URL ?>?page=forward_application&id=<?= $app['id'] ?>" class="btn-small">Forward</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</main>

<style>
.quick-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin: 2rem 0;
}
.stat-card {
    background: white;
    padding: 1rem;
    border-radius: 0.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    text-align: center;
}
.stat-card i {
    font-size: 2rem;
    color: #059669;
    margin-bottom: 0.5rem;
    display: block;
}
.stat-card strong {
    font-size: 1.5rem;
    display: block;
    margin-top: 0.5rem;
}
.alert {
    background: #d1fae5;
    color: #065f46;
    padding: 1rem;
    border-radius: 0.5rem;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 1rem;
}
.alert .button.small {
    background: #065f46;
    color: white;
    padding: 0.25rem 0.5rem;
    border-radius: 0.25rem;
    text-decoration: none;
    margin-left: auto;
}
.btn-small {
    padding: 0.25rem 0.5rem;
    background: #059669;
    color: white;
    border-radius: 0.25rem;
    text-decoration: none;
    font-size: 0.875rem;
    margin-right: 0.25rem;
}
</style>

<?php include __DIR__ . '/../../partials/footer.php'; ?>