<?php
// pages/dashboard/client.php
$pageTitle = 'Client Dashboard';
require_once __DIR__ . '/../../config.php';
if (!isClient()) redirect(BASE_URL . '?page=home');

$db = getDb();
$user_id = $_SESSION['user_id'];

// Check if user is approved BEFORE including header
$user = $db->querySingle("SELECT approved FROM users WHERE id = $user_id", true);
if (!$user['approved']) {
    include __DIR__ . '/../../partials/header.php';
    echo '<div class="container mx-auto px-4 py-8"><div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4">Your account is pending approval. You will be notified once approved.</div></div>';
    include __DIR__ . '/../../partials/footer.php';
    exit;
}

// Mark notifications as read
markNotificationsRead($user_id);
$unreadCount = getUnreadNotificationCount($user_id);

// Fetch user's applications
$apps = $db->query("SELECT a.*, p.name as product_name, p.image_url as product_image, b.name as branch_name, b.phone as branch_phone
                    FROM applications a
                    JOIN products p ON a.product_id = p.id
                    JOIN branches b ON a.branch_id = b.id
                    WHERE a.user_id = $user_id
                    ORDER BY a.created_at DESC");

$totalApps = $db->querySingle("SELECT COUNT(*) FROM applications WHERE user_id = $user_id");
$activeLeases = $db->querySingle("SELECT COUNT(*) FROM applications WHERE user_id = $user_id AND status = 'Active'");
$paymentsMade = $db->querySingle("SELECT COUNT(*) FROM payment_installments WHERE application_id IN (SELECT id FROM applications WHERE user_id = $user_id) AND status = 'paid'");

include __DIR__ . '/../../partials/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <div class="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-6 mb-8">
        <h1 class="text-2xl md:text-3xl font-bold text-gray-800">Welcome back, <?= htmlspecialchars($_SESSION['business_name'] ?? $_SESSION['username']) ?>!</h1>
        <?php if ($unreadCount > 0): ?>
            <p class="mt-2 inline-block bg-yellow-200 text-yellow-800 px-3 py-1 rounded-full text-sm"><i class="fas fa-bell mr-1"></i> You have <?= $unreadCount ?> new notification<?= $unreadCount > 1 ? 's' : '' ?>.</p>
        <?php endif; ?>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow p-6 text-center">
            <i class="fas fa-file-alt text-3xl text-green-600 mb-2"></i>
            <div class="text-2xl font-bold"><?= $totalApps ?></div>
            <div class="text-gray-600">Total Applications</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6 text-center">
            <i class="fas fa-check-circle text-3xl text-green-600 mb-2"></i>
            <div class="text-2xl font-bold"><?= $activeLeases ?></div>
            <div class="text-gray-600">Active Leases</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6 text-center">
            <i class="fas fa-credit-card text-3xl text-green-600 mb-2"></i>
            <div class="text-2xl font-bold"><?= $paymentsMade ?></div>
            <div class="text-gray-600">Payments Made</div>
        </div>
    </div>

    <div class="mb-6">
        <a href="<?= BASE_URL ?>?page=apply" class="inline-block bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition"><i class="fas fa-plus mr-2"></i> Apply for New Lease</a>
    </div>

    <h2 class="text-2xl font-bold mb-4">Your Lease Applications</h2>
    <?php if ($totalApps == 0): ?>
        <p class="text-gray-600">No applications yet.</p>
    <?php else: ?>
        <?php while($app = $apps->fetchArray(SQLITE3_ASSOC)):
            $progress = ($app['current_stage'] / 8) * 100;
            $stageNames = ['Inquiry','Application','Assessment','Approval','Contract','Procurement','Delivery','Active'];
            $stageLabels = [
                1 => 'Inquiry Received – Under Initial Review',
                2 => 'Application Submitted – Document Verification',
                3 => 'Under Financial & Risk Assessment',
                4 => 'Approved – Action Required',
                5 => 'Contract Preparation & Signing',
                6 => 'Asset Procurement in Progress',
                7 => 'Lease Activated',
                8 => 'Active Lease – Performing'
            ];

            // Fetch installments (using payment_installments table)
            $installments = $db->query("SELECT * FROM payment_installments WHERE application_id = {$app['id']} ORDER BY due_date");

            // Calculate totals
            $totalPayable = 0;
            $paid = 0;
            $maturedDue = 0;
            $future = 0;
            while($inst = $installments->fetchArray(SQLITE3_ASSOC)) {
                $totalPayable += $inst['amount'];
                if ($inst['status'] == 'paid') {
                    $paid += $inst['amount'];
                } elseif ($inst['status'] == 'pending' && strtotime($inst['due_date']) <= time()) {
                    $maturedDue += $inst['amount'];
                } elseif ($inst['status'] == 'pending' && strtotime($inst['due_date']) > time()) {
                    $future += $inst['amount'];
                }
            }
            $installments->reset();
            $outstanding = $totalPayable - $paid;

            // Check upcoming payments (within 10 days)
            $upcoming = $db->query("SELECT * FROM payment_installments WHERE application_id = {$app['id']} AND status = 'pending' AND due_date <= date('now', '+10 days') ORDER BY due_date");
            $hasUpcoming = $upcoming->numColumns() > 0;

            // Fetch site visit
            $visit = $db->querySingle("SELECT * FROM site_visits WHERE application_id = {$app['id']} ORDER BY scheduled_date DESC LIMIT 1", true);

            // Fetch asset tracking
            $asset = $db->querySingle("SELECT * FROM asset_tracking WHERE application_id = {$app['id']}", true);
        ?>
        <div class="bg-white rounded-lg shadow mb-8 overflow-hidden">
            <div class="border-b p-4 flex flex-wrap justify-between items-center bg-gray-50">
                <div>
                    <span class="font-semibold text-gray-600">Lease ID:</span> <?= $app['lease_id'] ?>
                    <span class="ml-4 font-semibold text-gray-600">Product:</span> <?= htmlspecialchars($app['product_name']) ?>
                </div>
                <span class="inline-block px-3 py-1 text-sm rounded-full 
                    <?= $app['status'] == 'approved' ? 'bg-green-100 text-green-800' : 
                       ($app['status'] == 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800') ?>">
                    <?= ucfirst($app['status']) ?>
                </span>
            </div>

            <?php if ($app['product_image']): ?>
                <img src="<?= BASE_URL . $app['product_image'] ?>" alt="<?= htmlspecialchars($app['product_name']) ?>" class="w-full h-48 object-cover">
            <?php endif; ?>

            <div class="p-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                        <p><strong>Product:</strong> <?= htmlspecialchars($app['product_name']) ?></p>
                        <p><strong>Branch:</strong> <?= htmlspecialchars($app['branch_name']) ?> (Phone: <?= $app['branch_phone'] ?>)</p>
                        <p><strong>Next Step:</strong> <?= $stageLabels[$app['current_stage']] ?></p>
                        <p><strong>Expected Timeline:</strong> <?= ($app['current_stage'] == 2) ? '3‑5 working days' : 'Varies by stage' ?></p>
                    </div>
                    <div>
                        <?php if ($app['status'] === 'conditional_approved' && !empty($app['conditions'])): ?>
                            <div class="bg-yellow-50 border-l-4 border-yellow-400 p-3">
                                <p class="font-semibold text-yellow-800">Conditional Approval</p>
                                <pre class="text-sm text-yellow-700 whitespace-pre-wrap"><?= htmlspecialchars($app['conditions']) ?></pre>
                                <form method="post" action="<?= BASE_URL ?>?page=accept_conditions" class="mt-2">
                                    <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                                    <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm">Accept Conditions</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Progress bar -->
                <div class="mb-4">
                    <div class="relative pt-1">
                        <div class="flex mb-2 items-center justify-between">
                            <div class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">Progress</div>
                            <div class="text-right text-xs font-semibold text-green-600"><?= round($progress) ?>%</div>
                        </div>
                        <div class="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                            <div style="width:<?= $progress ?>%" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-500"></div>
                        </div>
                        <div class="flex justify-between text-xs text-gray-500 mt-1">
                            <?php foreach ($stageNames as $stage): ?>
                                <span><?= $stage ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <?php if ($hasUpcoming): ?>
                    <div class="bg-yellow-100 border-l-4 border-yellow-400 p-3 mb-4">
                        <i class="fas fa-exclamation-triangle text-yellow-600 mr-2"></i> You have upcoming payments within 10 days.
                    </div>
                <?php endif; ?>

                <!-- Site Visit Display -->
                <?php if ($visit): ?>
                    <div class="bg-blue-50 border-l-4 border-blue-400 p-3 mb-4">
                        <p><strong>Site Visit Scheduled:</strong> <?= date('F j, Y', strtotime($visit['scheduled_date'])) ?></p>
                        <p><strong>Status:</strong> <?= ucfirst($visit['status']) ?></p>
                        <?php if ($visit['visited_date']): ?>
                            <p><strong>Visited on:</strong> <?= date('F j, Y', strtotime($visit['visited_date'])) ?></p>
                        <?php endif; ?>
                        <?php if ($visit['report']): ?>
                            <p><strong>Report:</strong> <?= nl2br(htmlspecialchars($visit['report'])) ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <!-- Asset Procurement Display -->
                <?php if ($asset): ?>
                    <div class="bg-green-50 border-l-4 border-green-400 p-3 mb-4">
                        <h3 class="font-semibold">Asset Procurement Status</h3>
                        <dl class="grid grid-cols-2 gap-2 mt-2 text-sm">
                            <dt class="text-gray-600">Supplier:</dt><dd><?= htmlspecialchars($asset['supplier'] ?? '—') ?></dd>
                            <dt class="text-gray-600">Order Date:</dt><dd><?= $asset['order_date'] ? date('M j, Y', strtotime($asset['order_date'])) : '—' ?></dd>
                            <dt class="text-gray-600">Expected Delivery:</dt><dd><?= $asset['expected_delivery'] ? date('M j, Y', strtotime($asset['expected_delivery'])) : '—' ?></dd>
                            <dt class="text-gray-600">Actual Delivery:</dt><dd><?= $asset['actual_delivery'] ? date('M j, Y', strtotime($asset['actual_delivery'])) : '—' ?></dd>
                            <dt class="text-gray-600">Status:</dt><dd class="capitalize"><?= $asset['status'] ?? 'ordered' ?></dd>
                        </dl>
                    </div>
                <?php endif; ?>
                
<!-- Branch Transfer Request -->
<?php
$pendingTransfer = $db->querySingle("SELECT id FROM transfer_requests WHERE application_id = {$app['id']} AND status = 'pending'", true);
?>
<div class="mt-4 border-t pt-4">
    <?php if ($pendingTransfer): ?>
        <p class="text-yellow-600 text-sm"><i class="fas fa-clock"></i> You have a pending branch transfer request. Please wait for approval.</p>
    <?php else: ?>
        <form method="post" action="<?= BASE_URL ?>?page=request_transfer" class="space-y-2">
            <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
            <label class="block text-sm font-medium mb-1">Request Branch Transfer</label>
            <div class="grid grid-cols-1 gap-2">
                <select name="target_branch_id" class="border border-gray-300 rounded p-2 text-sm w-full" required>
                    <option value="">Select new branch</option>
                    <?php
                    $branches = $db->query("SELECT id, name FROM branches WHERE id != {$app['branch_id']} ORDER BY name");
                    while ($b = $branches->fetchArray(SQLITE3_ASSOC)):
                    ?>
                        <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
                    <?php endwhile; ?>
                </select>
                <textarea name="reason" rows="2" class="border border-gray-300 rounded p-2 text-sm w-full" placeholder="Reason for transfer (optional)"></textarea>
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm">Request Transfer</button>
            </div>
        </form>
    <?php endif; ?>
</div>

                <!-- Financial Summary -->
                <div class="bg-gray-50 p-4 rounded-lg mb-4">
                    <h3 class="text-lg font-semibold mb-2">Lease Account Summary</h3>
                    <?php if ($totalPayable == 0): ?>
                        <p class="text-gray-600"><i class="fas fa-info-circle mr-1"></i> Your application is pending approval. Once approved, your payment schedule will appear here.</p>
                    <?php else: ?>
                        <div class="grid grid-cols-2 gap-2">
                            <div>Total Lease Amount:</div><div class="text-right font-semibold"><?= formatMoney($totalPayable) ?></div>
                            <div>Amount Paid to Date:</div><div class="text-right"><?= formatMoney($paid) ?></div>
                            <div>Matured (Due) Amount:</div><div class="text-right text-red-600"><?= formatMoney($maturedDue) ?></div>
                            <div>Future Installments:</div><div class="text-right"><?= formatMoney($future) ?></div>
                            <div class="font-bold">Total Outstanding:</div><div class="text-right font-bold text-red-600"><?= formatMoney($outstanding) ?></div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Payment Schedule -->
                <?php if ($totalPayable > 0): ?>
                    <div class="mb-4">
                        <h3 class="text-lg font-semibold mb-2">Payment Schedule</h3>
                        <div class="overflow-x-auto">
                            <table class="min-w-full text-sm">
                                <thead class="bg-gray-100">
                                    <tr>
                                        <th class="px-4 py-2 text-left">Due Date</th>
                                        <th class="px-4 py-2 text-left">Amount</th>
                                        <th class="px-4 py-2 text-left">Status</th>
                                        <th class="px-4 py-2 text-left">Penalty</th>
                                        <th class="px-4 py-2 text-left">Action</th>
                                     </thead>
                                <tbody>
                                <?php while($inst = $installments->fetchArray(SQLITE3_ASSOC)):
                                    $penalty = 0;
                                    if ($inst['status'] == 'pending' && strtotime($inst['due_date']) < time()) {
                                        $penalty = calculateLatePenalty($inst['amount'], $inst['due_date']);
                                    }
                                ?>
                                    <tr class="border-b">
                                        <td class="px-4 py-2"><?= $inst['due_date'] ?></td>
                                        <td class="px-4 py-2"><?= formatMoney($inst['amount']) ?></td>
                                        <td class="px-4 py-2">
                                            <?php if ($inst['status'] == 'paid'): ?>
                                                <span class="inline-block px-2 py-1 text-xs rounded bg-green-100 text-green-800">Paid</span>
                                            <?php elseif ($penalty > 0): ?>
                                                <span class="inline-block px-2 py-1 text-xs rounded bg-red-100 text-red-800">Overdue</span>
                                            <?php else: ?>
                                                <span class="inline-block px-2 py-1 text-xs rounded bg-yellow-100 text-yellow-800">Pending</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-4 py-2"><?= $penalty > 0 ? formatMoney($penalty) : '-' ?></td>
                                        <td class="px-4 py-2">
                                            <?php if ($inst['status'] == 'pending'): ?>
                                                <a href="<?= BASE_URL ?>?page=pay&app_id=<?= $app['id'] ?>&installment_id=<?= $inst['id'] ?>" class="text-blue-600 hover:underline">Pay Now</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                                </tbody>
                             </table>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="text-right">
                    <a href="<?= BASE_URL ?>?page=view_application&id=<?= $app['id'] ?>" class="text-blue-600 hover:underline">View Details & Comments →</a>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>