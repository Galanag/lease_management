<?php
// pages/dashboard/vendor.php
require_once __DIR__ . '/../../config.php';
if (!isVendor()) {
    redirect(BASE_URL . '?page=login');
}
include __DIR__ . '/../../partials/header.php';
?>

<h1 class="text-3xl font-bold mb-4">Vendor Dashboard</h1>
<p class="text-gray-700">Welcome, vendor. Use the links below to manage your products and view applications.</p>
<div class="mt-6 space-x-4">
    <a href="?page=vendor_products" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">My Products</a>
    <a href="?page=vendor_applications" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition">Applications</a>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>