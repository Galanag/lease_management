<?php
// pages/export_schedule_pdf.php
require_once __DIR__ . '/../config.php';

if (!isAdmin()) {
    die('Unauthorized');
}

$schedule_id = $_GET['id'] ?? 0;
$db = getDb();

$schedule = $db->querySingle("SELECT * FROM payment_schedules WHERE id = $schedule_id", true);
if (!$schedule) {
    die("Schedule not found.");
}

$installments = $db->query("SELECT * FROM installments WHERE schedule_id = $schedule_id ORDER BY due_date");
$app = $db->querySingle("SELECT a.*, u.full_name FROM applications a JOIN users u ON a.user_id = u.id WHERE a.id = {$schedule['application_id']}", true);

// Build HTML content for PDF
$html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Schedule</title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
        h1 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .footer { margin-top: 30px; text-align: center; font-size: 10px; }
    </style>
</head>
<body>
    <h1>Payment Schedule</h1>
    <p><strong>Application ID:</strong> ' . htmlspecialchars($app['id']) . '</p>
    <p><strong>Client:</strong> ' . htmlspecialchars($app['full_name']) . '</p>
    <p><strong>Total Repayment:</strong> ETB ' . number_format($schedule['total_repayment'], 2) . '</p>
    <p><strong>Installment Count:</strong> ' . $schedule['installment_count'] . '</p>
    <p><strong>Frequency:</strong> ' . ucfirst($schedule['frequency']) . '</p>
    <table>
        <thead>
             <tr>
                <th>Due Date</th>
                <th>Amount (ETB)</th>
                <th>Status</th>
             </tr>
        </thead>
        <tbody>';
while ($inst = $installments->fetchArray(SQLITE3_ASSOC)) {
    $html .= '<tr>
                <td>' . $inst['due_date'] . '</td>
                <td>' . number_format($inst['amount'], 2) . '</td>
                <td>' . ucfirst($inst['status']) . '</td>
              </tr>';
}
$html .= '</tbody>
    </table>
    <div class="footer">Generated on ' . date('Y-m-d H:i') . '</div>
</body>
</html>';

// Use mPDF if installed (via Composer)
// If not, fallback to simple HTML output (but we'll assume you want PDF)
// For PDF generation, we need mPDF. If you haven't installed it, run: composer require mpdf/mpdf
if (class_exists('Mpdf\Mpdf')) {
    $mpdf = new \Mpdf\Mpdf();
    $mpdf->WriteHTML($html);
    $mpdf->Output('payment_schedule_' . $schedule_id . '.pdf', 'D');
} else {
    // Fallback: display as HTML (not ideal but works)
    echo $html;
    exit;
}