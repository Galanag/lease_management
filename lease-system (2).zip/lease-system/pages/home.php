<?php
// pages/home.php
require_once __DIR__ . '/../config.php';
include __DIR__ . '/../partials/header.php';
?>

<div class="relative overflow-hidden bg-gradient-to-r from-green-50 to-blue-50 py-20">
    <div class="container mx-auto px-4 text-center relative z-10">
        <h1 class="text-5xl md:text-6xl font-bold text-gray-800 mb-4">Welcome to <span class="text-green-600">SiinQee Lease</span></h1>
        <p class="text-xl text-gray-600 mb-8">Your trusted partner for capital goods leasing in Ethiopia.</p>
        <div class="space-x-4">
            <a href="<?= BASE_URL ?>?page=calculator" class="inline-block bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg text-lg transition transform hover:scale-105 btn-animate"><i class="fas fa-calculator mr-2"></i> Calculator</a>
            <a href="<?= BASE_URL ?>?page=apply" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg text-lg transition transform hover:scale-105 btn-animate"><i class="fas fa-file-signature mr-2"></i> Apply Now</a>
        </div>
    </div>
    <div class="absolute bottom-0 left-0 w-full">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" class="w-full">
            <path fill="#ffffff" fill-opacity="1" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,154.7C960,171,1056,181,1152,165.3C1248,149,1344,107,1392,85.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
        </svg>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
    <div class="bg-white p-6 rounded shadow card-hover">
        <h3 class="text-xl font-semibold mb-2">Flexible Leasing</h3>
        <p class="text-gray-600">Tailored lease terms to suit your business needs.</p>
    </div>
    <div class="bg-white p-6 rounded shadow card-hover">
        <h3 class="text-xl font-semibold mb-2">Wide Range of Equipment</h3>
        <p class="text-gray-600">From tractors to construction machinery.</p>
    </div>
    <div class="bg-white p-6 rounded shadow card-hover">
        <h3 class="text-xl font-semibold mb-2">Fast Approval</h3>
        <p class="text-gray-600">Get your lease approved quickly.</p>
    </div>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>