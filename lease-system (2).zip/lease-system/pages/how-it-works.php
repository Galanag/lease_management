<?php
// pages/how-it-works.php
$pageTitle = 'How It Works';
require_once __DIR__ . '/../config.php';
?>
include __DIR__ . '/../partials/header.php';

<main class="container">
    <h1>How Leasing Works</h1>

    <div class="steps">
        <div class="step">
            <div class="step-icon">1</div>
            <h3>Inquiry & Pre-Application</h3>
            <p>Submit your initial interest online. You will receive an immediate confirmation with a reference number.</p>
        </div>
        <div class="step">
            <div class="step-icon">2</div>
            <h3>Application Submission</h3>
            <p>Fill the detailed application form with all required documents. Our system automatically checks for completeness.</p>
        </div>
        <div class="step">
            <div class="step-icon">3</div>
            <h3>Credit & Risk Assessment</h3>
            <p>Our team reviews your financials, business plan, and credit history. You can track progress via your dashboard.</p>
        </div>
        <div class="step">
            <div class="step-icon">4</div>
            <h3>Approval & Conditions</h3>
            <p>If approved, you receive a conditional offer with any requirements (down payment, collateral, etc.).</p>
        </div>
        <div class="step">
            <div class="step-icon">5</div>
            <h3>Contract Signing</h3>
            <p>Review and sign the lease agreement online or at your nearest branch.</p>
        </div>
        <div class="step">
            <div class="step-icon">6</div>
            <h3>Asset Procurement</h3>
            <p>We order and procure the equipment from the supplier. You can track the procurement status.</p>
        </div>
        <div class="step">
            <div class="step-icon">7</div>
            <h3>Disbursement & Delivery</h3>
            <p>The asset is delivered and insurance activated. The lease officially begins.</p>
        </div>
        <div class="step">
            <div class="step-icon">8</div>
            <h3>Active Lease & Payments</h3>
            <p>Make payments according to your schedule. Manage everything from your dashboard.</p>
        </div>
    </div>

    <div class="branch-info">
        <h2>Branch Assignment</h2>
        <p>When you apply, we automatically assign your nearest branch based on your city. If you prefer a different branch (CRM branch), you can indicate it on the application form. Your request will be reviewed by head office and, if approved, your application will be transferred.</p>
    </div>
</main>

<style>
.steps {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}
.step {
    background: white;
    padding: 1.5rem;
    border-radius: 0.5rem;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    position: relative;
    text-align: center;
}
.step-icon {
    width: 3rem;
    height: 3rem;
    background: #059669;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    font-weight: bold;
    margin: 0 auto 1rem;
}
.branch-info {
    background: #f0fdf4;
    padding: 2rem;
    border-radius: 0.5rem;
    margin-top: 3rem;
    border-left: 4px solid #059669;
}
</style>

<?php include __DIR__ . '/../partials/footer.php'; ?>