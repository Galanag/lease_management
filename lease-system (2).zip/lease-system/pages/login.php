<?php
// pages/auth/login.php
$pageTitle = 'Login';
require_once __DIR__ . '/../../config.php';
include __DIR__ . '/../../partials/header.php';

if (isLoggedIn()) {
    redirect(BASE_URL . '?page=dashboard');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $db = getDb();
    $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bindValue(1, $email, SQLITE3_TEXT);
    $res = $stmt->execute();
    $user = $res->fetchArray(SQLITE3_ASSOC);
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_name'] = $user['full_name'];
        redirect(BASE_URL . '?page=dashboard');
    } else {
        $error = 'Invalid email or password';
    }
}
?>

<div class="flex items-center justify-center min-h-[70vh]">
    <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-6">Login to SiinQee Lease</h2>

        <?php if ($error): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4 rounded">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2">Email Address</label>
                <input type="email" name="email" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500">
            </div>
            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-bold mb-2">Password</label>
                <input type="password" name="password" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500">
            </div>
            <button type="submit"
                    class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md transition duration-200">
                Login
            </button>
        </form>

        <div class="mt-6 text-center text-sm text-gray-600">
            <p>Don't have an account?
                <a href="<?= BASE_URL ?>?page=register_client" class="text-green-600 hover:underline">Register as Client</a>
                or
                <a href="<?= BASE_URL ?>?page=register_vendor" class="text-green-600 hover:underline">Register as Vendor</a>
            </p>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../partials/footer.php'; ?>