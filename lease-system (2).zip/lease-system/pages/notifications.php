<?php
// pages/notifications.php
$pageTitle = 'Notifications';
require_once __DIR__ . '/../config.php';
if (!isLoggedIn()) redirect(BASE_URL . '?page=login');

$db = getDb();
$user_id = $_SESSION['user_id'];

// Mark all as read if requested
if (isset($_GET['mark_read'])) {
    markNotificationsRead($user_id);
    redirect(BASE_URL . '?page=notifications');
}

// Mark single as read
if (isset($_GET['read'])) {
    $id = intval($_GET['read']);
    $db->exec("UPDATE notifications SET is_read = 1 WHERE id = $id AND user_id = $user_id");
    redirect(BASE_URL . '?page=notifications');
}

$notifications = $db->query("SELECT * FROM notifications WHERE user_id = $user_id ORDER BY created_at DESC");
$unreadCount = getUnreadNotificationCount($user_id);
?>
<?php include __DIR__ . '/../partials/header.php'; ?>

<main class="container">
    <h1><i class="fas fa-bell"></i> Notifications</h1>
    <?php if ($unreadCount > 0): ?>
        <p><a href="?page=notifications&mark_read=1" class="button secondary">Mark All as Read</a></p>
    <?php endif; ?>

    <div class="notifications-list">
        <?php while($n = $notifications->fetchArray(SQLITE3_ASSOC)): ?>
            <div class="notification-item <?= $n['is_read'] ? 'read' : 'unread' ?>" onclick="window.location='<?= htmlspecialchars($n['link']) ?>'">
                <p><?= htmlspecialchars($n['message']) ?></p>
                <small><?= $n['created_at'] ?></small>
                <?php if (!$n['is_read']): ?>
                    <a href="?page=notifications&read=<?= $n['id'] ?>" class="mark-read">Mark read</a>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>
</main>

<style>
.notifications-list {
    margin-top: 1rem;
}
.notification-item {
    padding: 1rem;
    border: 1px solid #e2e8f0;
    border-radius: 0.5rem;
    margin-bottom: 0.5rem;
    cursor: pointer;
    transition: background 0.2s;
    position: relative;
}
.notification-item:hover {
    background: #f8fafc;
}
.notification-item.unread {
    background: #fef3c7;
    border-left: 4px solid #fbbf24;
}
.notification-item.read {
    background: white;
    opacity: 0.8;
}
.mark-read {
    position: absolute;
    right: 1rem;
    top: 1rem;
    font-size: 0.8rem;
    background: #059669;
    color: white;
    padding: 0.2rem 0.5rem;
    border-radius: 0.25rem;
    text-decoration: none;
}
</style>

<?php include __DIR__ . '/../partials/footer.php'; ?>