<?php
// partials/header.php
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../config.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?></title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome 6 (free) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Custom CSS for animations -->
    <style>
        /* Smooth scroll behavior */
        html {
            scroll-behavior: smooth;
        }
        /* Fade-in animation for page content */
        .fade-in {
            animation: fadeIn 0.8s ease-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        /* Card hover effect */
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.02);
        }
        /* Button hover animation */
        .btn-animate {
            transition: all 0.2s ease;
        }
        .btn-animate:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-50 to-gray-100 font-sans">
    <!-- Sticky Navbar -->
    <nav class="sticky top-0 z-50 bg-white/80 backdrop-blur-md shadow-sm border-b border-gray-200">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
            <!-- Logo -->
            <a href="<?= BASE_URL ?>" class="text-2xl font-bold text-green-700 hover:text-green-800 transition">
                <i class="fas fa-leaf mr-2"></i>SiinQee Lease
            </a>

            <!-- Desktop Menu -->
            <div class="hidden md:flex space-x-6 items-center">
                <a href="<?= BASE_URL ?>" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-home"></i> Home</a>
                <a href="<?= BASE_URL ?>?page=calculator" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-calculator"></i> Calculator</a>
                <a href="<?= BASE_URL ?>?page=market" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-store"></i> Market</a>
                <a href="<?= BASE_URL ?>?page=track" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-chart-line"></i> Track Lease</a>
                <a href="<?= BASE_URL ?>?page=about" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-info-circle"></i> About</a>
                <a href="<?= BASE_URL ?>?page=contact" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-envelope"></i> Contact</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="<?= BASE_URL ?>?page=dashboard" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                    <a href="<?= BASE_URL ?>?page=logout" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition flex items-center gap-1"><i class="fas fa-sign-out-alt"></i> Logout</a>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>?page=login" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition flex items-center gap-1"><i class="fas fa-sign-in-alt"></i> Login</a>
                    <a href="<?= BASE_URL ?>?page=register_client" class="border border-green-600 text-green-600 hover:bg-green-50 px-4 py-2 rounded-lg transition flex items-center gap-1"><i class="fas fa-user-plus"></i> Client</a>
                    <a href="<?= BASE_URL ?>?page=register_vendor" class="border border-green-600 text-green-600 hover:bg-green-50 px-4 py-2 rounded-lg transition flex items-center gap-1"><i class="fas fa-truck"></i> Vendor</a>
                <?php endif; ?>
            </div>

            <!-- Mobile Menu Button -->
            <button id="mobile-menu-button" class="md:hidden text-gray-700 focus:outline-none">
                <i class="fas fa-bars text-2xl"></i>
            </button>
        </div>

        <!-- Mobile Menu (hidden by default) -->
        <div id="mobile-menu" class="md:hidden hidden bg-white border-t border-gray-200">
            <div class="flex flex-col space-y-3 p-4">
                <a href="<?= BASE_URL ?>" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-home w-5"></i> Home</a>
                <a href="<?= BASE_URL ?>?page=calculator" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-calculator w-5"></i> Calculator</a>
                <a href="<?= BASE_URL ?>?page=market" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-store w-5"></i> Market</a>
                <a href="<?= BASE_URL ?>?page=track" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-chart-line w-5"></i> Track Lease</a>
                <a href="<?= BASE_URL ?>?page=about" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-info-circle w-5"></i> About</a>
                <a href="<?= BASE_URL ?>?page=contact" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-envelope w-5"></i> Contact</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="<?= BASE_URL ?>?page=dashboard" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-tachometer-alt w-5"></i> Dashboard</a>
                    <a href="<?= BASE_URL ?>?page=logout" class="bg-red-500 text-white px-4 py-2 rounded-lg text-center flex items-center justify-center gap-2"><i class="fas fa-sign-out-alt"></i> Logout</a>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>?page=login" class="bg-green-600 text-white px-4 py-2 rounded-lg text-center flex items-center justify-center gap-2"><i class="fas fa-sign-in-alt"></i> Login</a>
                    <a href="<?= BASE_URL ?>?page=register_client" class="border border-green-600 text-green-600 hover:bg-green-50 px-4 py-2 rounded-lg text-center flex items-center justify-center gap-2"><i class="fas fa-user-plus"></i> Register as Client</a>
                    <a href="<?= BASE_URL ?>?page=register_vendor" class="border border-green-600 text-green-600 hover:bg-green-50 px-4 py-2 rounded-lg text-center flex items-center justify-center gap-2"><i class="fas fa-truck"></i> Register as Vendor</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <main class="fade-in">