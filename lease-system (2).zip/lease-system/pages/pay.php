<?php
// pages/pay.php
$pageTitle = 'Make Payment';
require_once __DIR__ . '/../config.php';
if (!isLoggedIn()) redirect(BASE_URL . '?page=login');

$app_id = intval($_GET['app_id'] ?? 0);
$installment_id = intval($_GET['installment_id'] ?? 0);

$db = getDb();
$user_id = $_SESSION['user_id'];

// Verify the application belongs to the user
$app = $db->querySingle("SELECT * FROM applications WHERE id = $app_id AND user_id = $user_id", true);
if (!$app) {
    $_SESSION['error'] = 'Application not found.';
    redirect(BASE_URL . '?page=dashboard');
}

// Get installment details
$installment = $db->querySingle("SELECT * FROM payment_installments WHERE id = $installment_id AND application_id = $app_id", true);
if (!$installment) {
    $_SESSION['error'] = 'Installment not found.';
    redirect(BASE_URL . '?page=dashboard');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay'])) {
    $method = $_POST['method'];
    $amount = $installment['amount'];
    $description = $_POST['description'] ?? '';

    if ($method == 'online') {
        // Simulate online payment – in production, integrate Chapa
        $tx_ref = 'TXN-' . uniqid();
        $stmt = $db->prepare("INSERT INTO payments (application_id, amount, method, transaction_id, status, paid_at, notes) VALUES (?, ?, ?, ?, 'Completed', datetime('now'), ?)");
        $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);
        $stmt->bindValue(2, $amount, SQLITE3_FLOAT);
        $stmt->bindValue(3, 'online', SQLITE3_TEXT);
        $stmt->bindValue(4, $tx_ref, SQLITE3_TEXT);
        $stmt->bindValue(5, $description, SQLITE3_TEXT);
        $stmt->execute();
        $payment_id = $db->lastInsertRowID();

        // Mark installment as paid
        $db->exec("UPDATE payment_installments SET status = 'paid', payment_id = $payment_id WHERE id = $installment_id");

        // Notify user
        addNotification($user_id, $app_id, "Payment of " . formatMoney($amount) . " received.", "?page=view_application&id=$app_id");

        $_SESSION['message'] = 'Payment successful.';
        redirect(BASE_URL . '?page=dashboard');
    } elseif ($method == 'bank') {
        // Handle file upload
        $target_dir = __DIR__ . '/../uploads/receipts/';
        if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
        $filename = uniqid() . '_' . basename($_FILES['receipt']['name']);
        $target_file = $target_dir . $filename;
        if (move_uploaded_file($_FILES['receipt']['tmp_name'], $target_file)) {
            $receipt_path = 'uploads/receipts/' . $filename;
            $ref = $_POST['ref_no'] ?? '';

            $stmt = $db->prepare("INSERT INTO payments (application_id, amount, method, transaction_id, status, receipt_path, paid_at, notes) VALUES (?, ?, ?, ?, 'Pending', ?, datetime('now'), ?)");
            $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);
            $stmt->bindValue(2, $amount, SQLITE3_FLOAT);
            $stmt->bindValue(3, 'bank', SQLITE3_TEXT);
            $stmt->bindValue(4, $ref, SQLITE3_TEXT);
            $stmt->bindValue(5, $receipt_path, SQLITE3_TEXT);
            $stmt->bindValue(6, $description, SQLITE3_TEXT);
            $stmt->execute();
            $payment_id = $db->lastInsertRowID();

            // Keep installment as pending until admin approval
            $db->exec("UPDATE payment_installments SET status = 'pending', payment_id = $payment_id WHERE id = $installment_id");

            // Notify admin
            addNotification(1, $app_id, "Bank payment receipt uploaded for approval.", "?page=admin&view=$app_id");

            $_SESSION['message'] = 'Receipt uploaded. Awaiting admin approval.';
            redirect(BASE_URL . '?page=dashboard');
        } else {
            $error = 'Upload failed.';
        }
    }
}
?>
<?php include __DIR__ . '/../partials/header.php'; ?>

<main class="container">
    <h1>Make Payment</h1>
    <div class="application-card">
        <p><strong>Lease ID:</strong> <?= $app['lease_id'] ?></p>
        <p><strong>Amount Due:</strong> <?= formatMoney($installment['amount']) ?></p>
        <p><strong>Due Date:</strong> <?= $installment['due_date'] ?></p>

        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="app_id" value="<?= $app_id ?>">
            <input type="hidden" name="installment_id" value="<?= $installment_id ?>">

            <div class="form-group">
                <label>Payment Method</label>
                <select name="method" id="method" required>
                    <option value="online">Online (Simulated)</option>
                    <option value="bank">Bank Transfer / Cash (Upload Receipt)</option>
                </select>
            </div>

            <div id="online-fields">
                <p>You will be redirected to a payment gateway (simulated).</p>
            </div>

            <div id="bank-fields" style="display:none;">
                <div class="form-group">
                    <label>Reference Number (optional)</label>
                    <input type="text" name="ref_no">
                </div>
                <div class="form-group">
                    <label>Upload Receipt</label>
                    <input type="file" name="receipt" accept=".pdf,.jpg,.png,.jpeg">
                </div>
            </div>

            <div class="form-group">
                <label>Description / Notes</label>
                <input type="text" name="description">
            </div>

            <button type="submit" name="pay">Proceed to Payment</button>
        </form>
    </div>
</main>

<script>
document.getElementById('method').addEventListener('change', function() {
    var val = this.value;
    document.getElementById('online-fields').style.display = (val == 'online') ? 'block' : 'none';
    document.getElementById('bank-fields').style.display = (val == 'bank') ? 'block' : 'none';
});
</script>

<?php include __DIR__ . '/../partials/footer.php'; ?>