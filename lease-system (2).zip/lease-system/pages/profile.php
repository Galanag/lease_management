<?php
// pages/profile.php
$pageTitle = 'My Profile';
require_once __DIR__ . '/../config.php';
if (!isLoggedIn()) redirect(BASE_URL . '?page=login');

$db = getDb();
$user_id = $_SESSION['user_id'];
$user = $db->querySingle("SELECT * FROM users WHERE id = $user_id", true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    // Update common fields
    $full_name = trim($_POST['full_name']);
    $gender = $_POST['gender'];
    $birth_date = $_POST['birth_date'];
    $nationality = $_POST['nationality'];
    $national_id = $_POST['national_id'];
    $tin = $_POST['tin'];
    $phone = $_POST['phone'];
    $alternative_phone = $_POST['alternative_phone'];
    $business_name = $_POST['business_name'];
    $business_form = $_POST['business_form'];
    $business_reg_number = $_POST['business_reg_number'];
    $business_license_number = $_POST['business_license_number'];
    $year_established = $_POST['year_established'] ? intval($_POST['year_established']) : null;
    $sector = $_POST['sector'];
    $region = $_POST['region'];
    $zone = $_POST['zone'];
    $woreda = $_POST['woreda'];
    $house_number = $_POST['house_number'];
    $city = $_POST['city'];
    $address = $_POST['address'];

    // Vendor specific fields (if user is vendor)
    $trade_name = $_POST['trade_name'] ?? '';
    $business_type = $_POST['business_type'] ?? '';
    $country_registration = $_POST['country_registration'] ?? '';
    $vat_number = $_POST['vat_number'] ?? '';
    $contact_person = $_POST['contact_person'] ?? '';
    $position = $_POST['position'] ?? '';
    $office_phone = $_POST['office_phone'] ?? '';
    $equipment_types = $_POST['equipment_types'] ?? '';
    $brand_represented = $_POST['brand_represented'] ?? '';
    $equipment_origin = $_POST['equipment_origin'] ?? '';
    $avg_supply_capacity = $_POST['avg_supply_capacity'] ?? '';
    $installation_service = isset($_POST['installation_service']) ? 1 : 0;
    $after_sales_maintenance = isset($_POST['after_sales_maintenance']) ? 1 : 0;
    $spare_parts_supply = isset($_POST['spare_parts_supply']) ? 1 : 0;
    $operator_training = isset($_POST['operator_training']) ? 1 : 0;
    $warranty_provision = isset($_POST['warranty_provision']) ? 1 : 0;
    $warranty_period = $_POST['warranty_period'] ?? '';
    $bank_name = $_POST['bank_name'] ?? '';
    $bank_account_name = $_POST['bank_account_name'] ?? '';
    $bank_account_number = $_POST['bank_account_number'] ?? '';
    $bank_branch = $_POST['bank_branch'] ?? '';
    $years_supplying = $_POST['years_supplying'] ? intval($_POST['years_supplying']) : null;

    // Update password only if provided
    if (!empty($_POST['new_password'])) {
        $password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $pwd_sql = ", password = '$password'";
    } else {
        $pwd_sql = "";
    }

    $sql = "UPDATE users SET
            full_name = :full_name, gender = :gender, birth_date = :birth_date, nationality = :nationality,
            national_id = :national_id, tin = :tin, phone = :phone, alternative_phone = :alternative_phone,
            business_name = :business_name, business_form = :business_form, business_reg_number = :business_reg_number,
            business_license_number = :business_license_number, year_established = :year_established, sector = :sector,
            region = :region, zone = :zone, woreda = :woreda, house_number = :house_number, city = :city, address = :address
            " . ($pwd_sql) . "
            WHERE id = :id";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':full_name', $full_name, SQLITE3_TEXT);
    $stmt->bindValue(':gender', $gender, SQLITE3_TEXT);
    $stmt->bindValue(':birth_date', $birth_date, SQLITE3_TEXT);
    $stmt->bindValue(':nationality', $nationality, SQLITE3_TEXT);
    $stmt->bindValue(':national_id', $national_id, SQLITE3_TEXT);
    $stmt->bindValue(':tin', $tin, SQLITE3_TEXT);
    $stmt->bindValue(':phone', $phone, SQLITE3_TEXT);
    $stmt->bindValue(':alternative_phone', $alternative_phone, SQLITE3_TEXT);
    $stmt->bindValue(':business_name', $business_name, SQLITE3_TEXT);
    $stmt->bindValue(':business_form', $business_form, SQLITE3_TEXT);
    $stmt->bindValue(':business_reg_number', $business_reg_number, SQLITE3_TEXT);
    $stmt->bindValue(':business_license_number', $business_license_number, SQLITE3_TEXT);
    $stmt->bindValue(':year_established', $year_established, SQLITE3_INTEGER);
    $stmt->bindValue(':sector', $sector, SQLITE3_TEXT);
    $stmt->bindValue(':region', $region, SQLITE3_TEXT);
    $stmt->bindValue(':zone', $zone, SQLITE3_TEXT);
    $stmt->bindValue(':woreda', $woreda, SQLITE3_TEXT);
    $stmt->bindValue(':house_number', $house_number, SQLITE3_TEXT);
    $stmt->bindValue(':city', $city, SQLITE3_TEXT);
    $stmt->bindValue(':address', $address, SQLITE3_TEXT);
    $stmt->bindValue(':id', $user_id, SQLITE3_INTEGER);
    $stmt->execute();

    // If vendor, update additional fields (you may need a separate update query)
    if (isVendor()) {
        $stmt2 = $db->prepare("UPDATE users SET
            trade_name = ?, business_type = ?, country_registration = ?, vat_number = ?,
            contact_person = ?, position = ?, office_phone = ?, equipment_types = ?,
            brand_represented = ?, equipment_origin = ?, avg_supply_capacity = ?,
            installation_service = ?, after_sales_maintenance = ?, spare_parts_supply = ?,
            operator_training = ?, warranty_provision = ?, warranty_period = ?,
            bank_name = ?, bank_account_name = ?, bank_account_number = ?, bank_branch = ?,
            years_supplying = ?
            WHERE id = ?");
        $stmt2->bindValue(1, $trade_name, SQLITE3_TEXT);
        $stmt2->bindValue(2, $business_type, SQLITE3_TEXT);
        $stmt2->bindValue(3, $country_registration, SQLITE3_TEXT);
        $stmt2->bindValue(4, $vat_number, SQLITE3_TEXT);
        $stmt2->bindValue(5, $contact_person, SQLITE3_TEXT);
        $stmt2->bindValue(6, $position, SQLITE3_TEXT);
        $stmt2->bindValue(7, $office_phone, SQLITE3_TEXT);
        $stmt2->bindValue(8, $equipment_types, SQLITE3_TEXT);
        $stmt2->bindValue(9, $brand_represented, SQLITE3_TEXT);
        $stmt2->bindValue(10, $equipment_origin, SQLITE3_TEXT);
        $stmt2->bindValue(11, $avg_supply_capacity, SQLITE3_TEXT);
        $stmt2->bindValue(12, $installation_service, SQLITE3_INTEGER);
        $stmt2->bindValue(13, $after_sales_maintenance, SQLITE3_INTEGER);
        $stmt2->bindValue(14, $spare_parts_supply, SQLITE3_INTEGER);
        $stmt2->bindValue(15, $operator_training, SQLITE3_INTEGER);
        $stmt2->bindValue(16, $warranty_provision, SQLITE3_INTEGER);
        $stmt2->bindValue(17, $warranty_period, SQLITE3_TEXT);
        $stmt2->bindValue(18, $bank_name, SQLITE3_TEXT);
        $stmt2->bindValue(19, $bank_account_name, SQLITE3_TEXT);
        $stmt2->bindValue(20, $bank_account_number, SQLITE3_TEXT);
        $stmt2->bindValue(21, $bank_branch, SQLITE3_TEXT);
        $stmt2->bindValue(22, $years_supplying, SQLITE3_INTEGER);
        $stmt2->bindValue(23, $user_id, SQLITE3_INTEGER);
        $stmt2->execute();
    }

    $_SESSION['message'] = 'Profile updated.';
    redirect(BASE_URL . '?page=profile');
}
?>
<!--<?php include __DIR__ . '/../partials/header.php'; ?>-->

<main class="container">
    <h1><i class="fas fa-user-circle"></i> My Profile</h1>
    <?php if (isset($_SESSION['message'])): ?>
        <p class="success"><?= $_SESSION['message'] ?></p>
        <?php unset($_SESSION['message']); ?>
    <?php endif; ?>

    <form method="post" style="max-width: 800px; margin:0 auto;">
        <div class="form-section">
            <h2>Personal Information</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Gender</label>
                    <select name="gender">
                        <option value="">Select</option>
                        <option value="Male" <?= ($user['gender'] ?? '') == 'Male' ? 'selected' : '' ?>>Male</option>
                        <option value="Female" <?= ($user['gender'] ?? '') == 'Female' ? 'selected' : '' ?>>Female</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Date of Birth</label>
                    <input type="date" name="birth_date" value="<?= htmlspecialchars($user['birth_date'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Nationality</label>
                    <input type="text" name="nationality" value="<?= htmlspecialchars($user['nationality'] ?? 'Ethiopian') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>National ID / Passport</label>
                    <input type="text" name="national_id" value="<?= htmlspecialchars($user['national_id'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>TIN</label>
                    <input type="text" name="tin" value="<?= htmlspecialchars($user['tin'] ?? '') ?>">
                </div>
            </div>
        </div>

        <div class="form-section">
            <h2>Contact Information</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Alternative Phone</label>
                    <input type="text" name="alternative_phone" value="<?= htmlspecialchars($user['alternative_phone'] ?? '') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" readonly disabled> (cannot be changed)
                </div>
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" value="<?= htmlspecialchars($user['username'] ?? '') ?>" readonly disabled>
                </div>
            </div>
        </div>

        <div class="form-section">
            <h2>Address</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>Region</label>
                    <input type="text" name="region" value="<?= htmlspecialchars($user['region'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Zone/Sub-City</label>
                    <input type="text" name="zone" value="<?= htmlspecialchars($user['zone'] ?? '') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Woreda</label>
                    <input type="text" name="woreda" value="<?= htmlspecialchars($user['woreda'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>House Number</label>
                    <input type="text" name="house_number" value="<?= htmlspecialchars($user['house_number'] ?? '') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>City</label>
                    <input type="text" name="city" value="<?= htmlspecialchars($user['city'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <textarea name="address"><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                </div>
            </div>
        </div>

        <div class="form-section">
            <h2>Business Information</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>Business Name</label>
                    <input type="text" name="business_name" value="<?= htmlspecialchars($user['business_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Business Form</label>
                    <select name="business_form">
                        <option value="">Select</option>
                        <option value="IMX" <?= ($user['business_form'] ?? '') == 'IMX' ? 'selected' : '' ?>>IMX</option>
                        <option value="PLC" <?= ($user['business_form'] ?? '') == 'PLC' ? 'selected' : '' ?>>PLC</option>
                        <option value="Partnership" <?= ($user['business_form'] ?? '') == 'Partnership' ? 'selected' : '' ?>>Partnership</option>
                        <option value="Sole Proprietorship" <?= ($user['business_form'] ?? '') == 'Sole Proprietorship' ? 'selected' : '' ?>>Sole Proprietorship</option>
                        <option value="Share Company" <?= ($user['business_form'] ?? '') == 'Share Company' ? 'selected' : '' ?>>Share Company</option>
                        <option value="Cooperative" <?= ($user['business_form'] ?? '') == 'Cooperative' ? 'selected' : '' ?>>Cooperative</option>
                        <option value="Other" <?= ($user['business_form'] ?? '') == 'Other' ? 'selected' : '' ?>>Other</option>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Business Registration Number</label>
                    <input type="text" name="business_reg_number" value="<?= htmlspecialchars($user['business_reg_number'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Business License Number</label>
                    <input type="text" name="business_license_number" value="<?= htmlspecialchars($user['business_license_number'] ?? '') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Year Established</label>
                    <input type="number" name="year_established" value="<?= htmlspecialchars($user['year_established'] ?? '') ?>" min="1900" max="<?= date('Y') ?>">
                </div>
                <div class="form-group">
                    <label>Sector</label>
                    <select name="sector">
                        <option value="">Select</option>
                        <?php
                        $sectors = $db->query("SELECT DISTINCT sector FROM down_payment_rates");
                        while($s = $sectors->fetchArray(SQLITE3_ASSOC)): ?>
                        <option value="<?= $s['sector'] ?>" <?= ($user['sector'] ?? '') == $s['sector'] ? 'selected' : '' ?>><?= $s['sector'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
        </div>

        <?php if (isVendor()): ?>
        <div class="form-section">
            <h2>Vendor Specific Information</h2>
            <div class="form-row">
                <div class="form-group">
                    <label>Trade Name</label>
                    <input type="text" name="trade_name" value="<?= htmlspecialchars($user['trade_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Business Type (comma separated)</label>
                    <input type="text" name="business_type" value="<?= htmlspecialchars($user['business_type'] ?? '') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Country of Registration</label>
                    <input type="text" name="country_registration" value="<?= htmlspecialchars($user['country_registration'] ?? 'Ethiopia') ?>">
                </div>
                <div class="form-group">
                    <label>VAT Number</label>
                    <input type="text" name="vat_number" value="<?= htmlspecialchars($user['vat_number'] ?? '') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Contact Person</label>
                    <input type="text" name="contact_person" value="<?= htmlspecialchars($user['contact_person'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Position</label>
                    <input type="text" name="position" value="<?= htmlspecialchars($user['position'] ?? '') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Office Phone</label>
                    <input type="text" name="office_phone" value="<?= htmlspecialchars($user['office_phone'] ?? '') ?>">
                </div>
            </div>
            <h3>Equipment Supply</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Equipment Types</label>
                    <input type="text" name="equipment_types" value="<?= htmlspecialchars($user['equipment_types'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Brand Represented</label>
                    <input type="text" name="brand_represented" value="<?= htmlspecialchars($user['brand_represented'] ?? '') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Equipment Origin</label>
                    <input type="text" name="equipment_origin" value="<?= htmlspecialchars($user['equipment_origin'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Avg Supply Capacity</label>
                    <input type="text" name="avg_supply_capacity" value="<?= htmlspecialchars($user['avg_supply_capacity'] ?? '') ?>">
                </div>
            </div>
            <h3>Technical Capability</h3>
            <div class="checkbox-group">
                <label><input type="checkbox" name="installation_service" value="1" <?= $user['installation_service'] ? 'checked' : '' ?>> Installation Service</label>
                <label><input type="checkbox" name="after_sales_maintenance" value="1" <?= $user['after_sales_maintenance'] ? 'checked' : '' ?>> After-sales Maintenance</label>
                <label><input type="checkbox" name="spare_parts_supply" value="1" <?= $user['spare_parts_supply'] ? 'checked' : '' ?>> Spare Parts Supply</label>
                <label><input type="checkbox" name="operator_training" value="1" <?= $user['operator_training'] ? 'checked' : '' ?>> Operator Training</label>
                <label><input type="checkbox" name="warranty_provision" value="1" <?= $user['warranty_provision'] ? 'checked' : '' ?>> Warranty Provision</label>
            </div>
            <div class="form-group">
                <label>Warranty Period Offered</label>
                <input type="text" name="warranty_period" value="<?= htmlspecialchars($user['warranty_period'] ?? '') ?>">
            </div>
            <h3>Banking Information</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Bank Name</label>
                    <input type="text" name="bank_name" value="<?= htmlspecialchars($user['bank_name'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Bank Account Name</label>
                    <input type="text" name="bank_account_name" value="<?= htmlspecialchars($user['bank_account_name'] ?? '') ?>">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Bank Account Number</label>
                    <input type="text" name="bank_account_number" value="<?= htmlspecialchars($user['bank_account_number'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label>Bank Branch</label>
                    <input type="text" name="bank_branch" value="<?= htmlspecialchars($user['bank_branch'] ?? '') ?>">
                </div>
            </div>
            <div class="form-group">
                <label>Years Supplying Capital Goods</label>
                <input type="number" name="years_supplying" value="<?= htmlspecialchars($user['years_supplying'] ?? '') ?>">
            </div>
        </div>
        <?php endif; ?>

        <div class="form-section">
            <h2>Change Password</h2>
            <p>Leave blank to keep current password.</p>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password">
            </div>
        </div>

        <button type="submit" name="update">Update Profile</button>
    </form>
</main>

<style>
.form-section {
    background: #f9f9f9;
    padding: 1.5rem;
    margin-bottom: 2rem;
    border-radius: 0.5rem;
    border-left: 4px solid #059669;
}
.form-section h2 {
    margin-top: 0;
    color: #0f3b2c;
}
.checkbox-group {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    margin: 1rem 0;
}
.checkbox-group label {
    display: flex;
    align-items: center;
    gap: 0.3rem;
}
</style>

<!--<?php include __DIR__ . '/../partials/footer.php'; ?>-->