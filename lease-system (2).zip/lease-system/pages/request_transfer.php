<?php
// pages/request_transfer.php
require_once __DIR__ . '/../config.php';
requireLogin();

$db = getDb();
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['user_role'];

$app_id = intval($_POST['application_id'] ?? 0);
$target_branch_id = intval($_POST['target_branch_id'] ?? 0);
$reason = trim($_POST['reason'] ?? '');

if (!$app_id || !$target_branch_id) {
    $_SESSION['error'] = 'Invalid transfer request.';
    redirect(BASE_URL . '?page=dashboard');
}

// Fetch the application
$app = $db->querySingle("SELECT * FROM applications WHERE id = $app_id", true);
if (!$app) {
    $_SESSION['error'] = 'Application not found.';
    redirect(BASE_URL . '?page=dashboard');
}

// Permission checks
$allowed = false;
if ($user_role === 'client') {
    // Client can only request transfer for their own applications
    if ($app['user_id'] == $user_id) {
        $allowed = true;
    }
} elseif ($user_role === 'branch') {
    // Branch manager can request transfer for applications assigned to their branch
    $branch_id = getCurrentBranchId(); // function we added earlier
    if ($branch_id && $app['branch_id'] == $branch_id) {
        $allowed = true;
    }
} elseif ($user_role === 'admin' || $user_role === 'crmd') {
    // Admin/CRMD can request for any application (but they may also use direct transfer)
    $allowed = true;
}

if (!$allowed) {
    $_SESSION['error'] = 'You do not have permission to request transfer for this application.';
    redirect(BASE_URL . '?page=dashboard');
}

// Check if a pending request already exists
$pending = $db->querySingle("SELECT id FROM transfer_requests WHERE application_id = $app_id AND status = 'pending'");
if ($pending) {
    $_SESSION['error'] = 'A pending transfer request already exists for this application.';
    redirect(BASE_URL . '?page=dashboard');
}

// Insert the transfer request
$stmt = $db->prepare("INSERT INTO transfer_requests (application_id, from_branch_id, to_branch_id, requested_by_user, reason) VALUES (?, ?, ?, ?, ?)");
$stmt->bindValue(1, $app_id, SQLITE3_INTEGER);
$stmt->bindValue(2, $app['branch_id'], SQLITE3_INTEGER);
$stmt->bindValue(3, $target_branch_id, SQLITE3_INTEGER);
$stmt->bindValue(4, $user_id, SQLITE3_INTEGER);
$stmt->bindValue(5, $reason, SQLITE3_TEXT);
$stmt->execute();

// Notify admins/CRMD
$admins = $db->query("SELECT id FROM users WHERE role IN ('admin', 'crmd')");
while ($admin = $admins->fetchArray(SQLITE3_ASSOC)) {
    addNotification($admin['id'], $app_id, "Transfer request for application #{$app['lease_id']} by " . ($user_role == 'client' ? 'client' : 'branch manager'), "?page=admin_transfer_requests");
}

$_SESSION['message'] = 'Transfer request submitted. You will be notified when processed.';
redirect(BASE_URL . '?page=dashboard');