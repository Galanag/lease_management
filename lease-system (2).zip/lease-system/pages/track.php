<?php
// pages/track.php
$pageTitle = 'Track Lease';
require_once __DIR__ . '/../config.php';

$lease_id = $_GET['lease_id'] ?? '';
$app = null;
$error = '';

if ($lease_id) {
    $db = getDb();
    $stmt = $db->prepare("SELECT a.*, p.name as product_name, b.name as branch_name 
                          FROM applications a 
                          JOIN products p ON a.product_id = p.id 
                          JOIN branches b ON a.branch_id = b.id 
                          WHERE a.lease_id = :lease_id");
    $stmt->bindValue(':lease_id', $lease_id, SQLITE3_TEXT);
    $res = $stmt->execute();
    $app = $res->fetchArray(SQLITE3_ASSOC);
    if (!$app) {
        $error = 'No application found with that Lease ID.';
    }
}

include __DIR__ . '/../partials/header.php';
?>

<div class="container mx-auto px-4 py-8 max-w-3xl">
    <h1 class="text-3xl font-bold mb-6">Track Your Lease Application</h1>

    <div class="bg-white rounded shadow p-6 mb-8">
        <form method="get" action="" class="flex flex-col md:flex-row gap-4">
            <input type="hidden" name="page" value="track">
            <input type="text" name="lease_id" value="<?= htmlspecialchars($lease_id) ?>" placeholder="Enter your Lease ID" class="flex-1 border border-gray-300 rounded p-2">
            <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded">Track</button>
        </form>
    </div>

    <?php if ($error): ?>
        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <?php if ($app): ?>
        <div class="bg-white rounded shadow p-6">
            <h2 class="text-2xl font-bold mb-4">Application Status</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div><strong>Lease ID:</strong> <?= htmlspecialchars($app['lease_id']) ?></div>
                <div><strong>Product:</strong> <?= htmlspecialchars($app['product_name']) ?></div>
                <div><strong>Branch:</strong> <?= htmlspecialchars($app['branch_name']) ?></div>
                <div><strong>Applied on:</strong> <?= date('F j, Y', strtotime($app['created_at'])) ?></div>
                <div><strong>Current Status:</strong>
                    <span class="inline-block px-2 py-1 text-xs rounded 
                        <?= $app['status'] == 'approved' ? 'bg-green-100 text-green-800' : 
                           ($app['status'] == 'rejected' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800') ?>">
                        <?= ucfirst($app['status']) ?>
                    </span>
                </div>
                <div><strong>Stage:</strong> <?= $app['current_stage'] ?>/8</div>
            </div>
            <div class="mt-4">
                <div class="relative pt-1">
                    <div class="flex mb-2 items-center justify-between">
                        <div>
                            <span class="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                                Progress
                            </span>
                        </div>
                        <div class="text-right">
                            <span class="text-xs font-semibold inline-block text-green-600">
                                <?= round(($app['current_stage'] / 8) * 100) ?>%
                            </span>
                        </div>
                    </div>
                    <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-gray-200">
                        <div style="width:<?= ($app['current_stage'] / 8) * 100 ?>%" class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-green-500"></div>
                    </div>
                </div>
            </div>
            <?php if ($app['status'] == 'approved' && $app['current_stage'] < 8): ?>
                <p class="text-sm text-gray-600 mt-2">Your application is approved. Next steps will be communicated soon.</p>
            <?php elseif ($app['status'] == 'rejected'): ?>
                <p class="text-sm text-red-600 mt-2">We regret to inform you that your application was not approved. For more details, please contact your branch.</p>
            <?php elseif ($app['status'] == 'pending'): ?>
                <p class="text-sm text-yellow-600 mt-2">Your application is under review. We will update you once a decision is made.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>