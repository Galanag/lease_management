<?php
// pages/upload_document.php
require_once __DIR__ . '/../config.php';
requireLogin();

$user_id = $_SESSION['user_id'];
$application_id = $_POST['application_id'] ?? 0;
if (!$application_id) {
    die('Invalid application.');
}
$document_type = $_POST['document_type'] ?? '';
$notes = trim($_POST['notes'] ?? '');
if (empty($document_type) || empty($_FILES['document_file']['name'])) {
    die('Please select a document type and file.');
}

$db = getDb();
// Verify the user has permission to upload for this application
$app = $db->querySingle("SELECT branch_id, user_id FROM applications WHERE id = $application_id", true);
if (!$app) die('Application not found.');
// Check if user is admin, CRMD, or branch manager of the assigned branch
$user = $db->querySingle("SELECT role, branch_id FROM users WHERE id = $user_id", true);
if ($user['role'] != 'admin' && $user['role'] != 'crmd' && ($user['role'] != 'branch' || $user['branch_id'] != $app['branch_id'])) {
    die('You do not have permission to upload documents for this application.');
}

$upload_dir = __DIR__ . '/../uploads/documents/';
if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
$file = $_FILES['document_file'];
$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = uniqid() . '_' . $application_id . '_' . $document_type . '.' . $ext;
$filepath = 'uploads/documents/' . $filename;
move_uploaded_file($file['tmp_name'], $upload_dir . $filename);

$stmt = $db->prepare("INSERT INTO application_documents (application_id, document_type, file_path, uploaded_by, notes) VALUES (?, ?, ?, ?, ?)");
$stmt->bindValue(1, $application_id, SQLITE3_INTEGER);
$stmt->bindValue(2, $document_type, SQLITE3_TEXT);
$stmt->bindValue(3, $filepath, SQLITE3_TEXT);
$stmt->bindValue(4, $user_id, SQLITE3_INTEGER);
$stmt->bindValue(5, $notes, SQLITE3_TEXT);
$stmt->execute();

// Notify CRMD (users with role admin or crmd)
$crmdUsers = $db->query("SELECT id FROM users WHERE role IN ('admin', 'crmd')");
while ($crmd = $crmdUsers->fetchArray(SQLITE3_ASSOC)) {
    addNotification($crmd['id'], $application_id, "Document '$document_type' uploaded for application #$application_id.", "?page=admin_application&id=$application_id");
}

$_SESSION['message'] = 'Document uploaded successfully.';
header("Location: " . BASE_URL . "?page=admin_application&id=$application_id");
exit;