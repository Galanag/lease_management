<?php
// pages/vendor_delete_image.php
require_once __DIR__ . '/../../config.php';
if (!isVendor()) redirect(BASE_URL . '?page=login');

$db = getDb();
$vendor_id = $_SESSION['user_id'];
$product_id = $_GET['product_id'] ?? 0;
$image_path = $_GET['image'] ?? '';

// Check ownership of product
$product = $db->querySingle("SELECT id FROM products WHERE id = $product_id AND vendor_id = $vendor_id", true);
if (!$product) {
    die("Product not found or you don't have permission.");
}

// Delete image record and file
$db->exec("DELETE FROM product_images WHERE product_id = $product_id AND image_path = '$image_path'");
$filepath = __DIR__ . '/../../' . $image_path;
if (file_exists($filepath)) unlink($filepath);

$_SESSION['success'] = "Image deleted.";
redirect(BASE_URL . "?page=vendor_product_form&id=$product_id");