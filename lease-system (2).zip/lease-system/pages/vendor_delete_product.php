<?php
// pages/vendor_delete_product.php
require_once __DIR__ . '/../../config.php';
if (!isVendor()) redirect(BASE_URL . '?page=login');

$db = getDb();
$vendor_id = $_SESSION['user_id'];
$product_id = $_GET['id'] ?? 0;

// Check ownership
$product = $db->querySingle("SELECT id FROM products WHERE id = $product_id AND vendor_id = $vendor_id", true);
if (!$product) {
    die("Product not found or you don't have permission.");
}

// Delete associated images (files and records)
$images = $db->query("SELECT image_path FROM product_images WHERE product_id = $product_id");
while ($img = $images->fetchArray(SQLITE3_ASSOC)) {
    $filepath = __DIR__ . '/../../' . $img['image_path'];
    if (file_exists($filepath)) unlink($filepath);
}
$db->exec("DELETE FROM product_images WHERE product_id = $product_id");
$db->exec("DELETE FROM products WHERE id = $product_id");

$_SESSION['success'] = "Product deleted.";
redirect(BASE_URL . '?page=vendor_products');