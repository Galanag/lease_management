<?php
// pages/view_application.php
$pageTitle = 'Application Details';
require_once __DIR__ . '/../config.php';
if (!isLoggedIn()) redirect(BASE_URL . '?page=login');

$app_id = intval($_GET['id'] ?? 0);
$db = getDb();
$user_id = $_SESSION['user_id'];
$role = getUserRole();

// Determine which application to show (own for client, any for admin/branch)
if ($role == 'client') {
    $app = $db->querySingle("SELECT a.*, p.name as product_name, b.name as branch_name 
                              FROM applications a 
                              JOIN products p ON a.product_id = p.id 
                              JOIN branches b ON a.branch_id = b.id
                              WHERE a.id = $app_id AND a.user_id = $user_id", true);
} else {
    $app = $db->querySingle("SELECT a.*, p.name as product_name, b.name as branch_name, u.username 
                              FROM applications a 
                              JOIN products p ON a.product_id = p.id 
                              JOIN branches b ON a.branch_id = b.id
                              JOIN users u ON a.user_id = u.id
                              WHERE a.id = $app_id", true);
}

if (!$app) {
    $_SESSION['error'] = 'Application not found.';
    redirect(BASE_URL . '?page=' . ($role == 'client' ? 'dashboard' : 'admin'));
}

// Handle comment submission from client
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_comment']) && $role == 'client') {
    $comment = $_POST['comment'];
    addComment($app_id, $user_id, $comment, 0);
    $_SESSION['message'] = 'Comment added.';
    redirect(BASE_URL . '?page=view_application&id=' . $app_id);
}

// Handle document upload from client
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_doc']) && $role == 'client') {
    if (uploadDocument($app_id, $user_id, $_FILES['document'], $_POST['stage'], $_POST['description'])) {
        $_SESSION['message'] = 'Document uploaded.';
    } else {
        $_SESSION['error'] = 'Upload failed.';
    }
    redirect(BASE_URL . '?page=view_application&id=' . $app_id);
}

// Handle branch transfer request from client
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_transfer']) && $role == 'client') {
    $to_branch = intval($_POST['to_branch']);
    $reason = trim($_POST['reason']);
    $current_branch = $app['branch_id'];
    // Insert transfer request
    $stmt = $db->prepare("INSERT INTO transfer_requests (application_id, requested_by_user, from_branch_id, to_branch_id, reason) VALUES (?, ?, ?, ?, ?)");
    $stmt->bindValue(1, $app_id, SQLITE3_INTEGER);
    $stmt->bindValue(2, $user_id, SQLITE3_INTEGER);
    $stmt->bindValue(3, $current_branch, SQLITE3_INTEGER);
    $stmt->bindValue(4, $to_branch, SQLITE3_INTEGER);
    $stmt->bindValue(5, $reason, SQLITE3_TEXT);
    $stmt->execute();
    // Notify admin
    addNotification(1, $app_id, "Branch transfer request from client for application #$app_id", "?page=admin_transfer_requests");
    $_SESSION['message'] = 'Transfer request submitted.';
    redirect(BASE_URL . '?page=view_application&id=' . $app_id);
}

$comments = getComments($app_id);
$documents = getDocuments($app_id);
$branches = $db->query("SELECT id, name FROM branches ORDER BY name");
$stageNames = ['Inquiry','Application','Assessment','Approval','Contract','Procurement','Delivery','Active'];
$progress = ($app['current_stage'] / 8) * 100;
?>
<?php include __DIR__ . '/../partials/header.php'; ?>

<main class="container">
    <h1>Application Details</h1>
    <?php if (isset($_SESSION['message'])) echo "<p class='success'>".$_SESSION['message']."</p>"; unset($_SESSION['message']); ?>
    <?php if (isset($_SESSION['error'])) echo "<p class='error'>".$_SESSION['error']."</p>"; unset($_SESSION['error']); ?>

    <p><a href="<?= BASE_URL ?>?page=<?= ($role == 'client' ? 'dashboard' : 'admin') ?>" class="button secondary">&larr; Back</a></p>

    <div class="application-card">
        <h2>Lease #<?= $app['lease_id'] ?></h2>
        <div class="details-grid">
            <!-- Applicant Information -->
            <div class="detail-section">
                <h3>Applicant</h3>
                <p><strong>Name:</strong> <?= htmlspecialchars($app['applicant_full_name'] ?? 'N/A') ?></p>
                <p><strong>Business:</strong> <?= htmlspecialchars($app['business_name'] ?? 'N/A') ?></p>
                <?php if ($role != 'client'): ?>
                    <p><strong>Client:</strong> <?= htmlspecialchars($app['username'] ?? '') ?></p>
                <?php endif; ?>
            </div>

            <!-- Financing -->
            <div class="detail-section">
                <h3>Financing</h3>
                <p><strong>Product:</strong> <?= htmlspecialchars($app['product_name']) ?></p>
                <p><strong>Value:</strong> <?= formatMoney($app['total_amount']) ?></p>
                <p><strong>Down Payment:</strong> <?= formatMoney($app['equity_amount']) ?></p>
                <p><strong>Term:</strong> <?= $app['lease_term'] ?> months</p>
                <p><strong>Rate:</strong> <?= $app['interest_rate'] ?>%</p>
            </div>

            <!-- Branch -->
            <div class="detail-section">
                <h3>Assigned Branch</h3>
                <p><strong>Current Branch:</strong> <?= htmlspecialchars($app['branch_name']) ?></p>
                <?php if ($role == 'client'): ?>
                    <button type="button" onclick="document.getElementById('transfer-form').style.display='block'" class="button small">Request Branch Transfer</button>
                    <div id="transfer-form" style="display:none; margin-top:1rem;">
                        <form method="post">
                            <input type="hidden" name="request_transfer" value="1">
                            <div class="form-group">
                                <label>Transfer to Branch</label>
                                <select name="to_branch" required>
                                    <?php while($b = $branches->fetchArray(SQLITE3_ASSOC)): ?>
                                    <option value="<?= $b['id'] ?>" <?= $b['id'] == $app['branch_id'] ? 'disabled' : '' ?>><?= htmlspecialchars($b['name']) ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Reason for transfer</label>
                                <textarea name="reason" required></textarea>
                            </div>
                            <button type="submit" class="button small">Submit Request</button>
                            <button type="button" onclick="document.getElementById('transfer-form').style.display='none'" class="button small secondary">Cancel</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Status & Progress -->
            <div class="detail-section">
                <h3>Status</h3>
                <p><strong>Status:</strong> <?= $app['status'] ?></p>
                <p><strong>Stage:</strong> <?= getStageName($app['current_stage']) ?></p>
                <?php if ($app['admin_comment']): ?>
                    <p><strong>Admin Comment:</strong> <?= nl2br(htmlspecialchars($app['admin_comment'])) ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Progress bar -->
        <div class="progress-container">
            <div class="progress-bar">
                <div class="progress-fill" style="width: <?= $progress ?>%;"></div>
            </div>
            <div class="stage-labels">
                <?php foreach ($stageNames as $i => $name): ?>
                    <span class="<?= ($i+1 <= $app['current_stage']) ? 'completed' : '' ?>"><?= $name ?></span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Comments Section -->
    <h2>Comments</h2>
    <div class="comments-section">
        <?php while($c = $comments->fetchArray(SQLITE3_ASSOC)): ?>
            <div class="comment <?= $c['is_admin'] ? 'admin-comment' : '' ?>">
                <strong><?= htmlspecialchars($c['username']) ?></strong> <small><?= $c['created_at'] ?></small>
                <p><?= nl2br(htmlspecialchars($c['comment'])) ?></p>
            </div>
        <?php endwhile; ?>
    </div>

    <?php if ($role == 'client'): ?>
    <form method="post" class="comment-form">
        <input type="hidden" name="app_id" value="<?= $app_id ?>">
        <div class="form-group">
            <label>Add Comment</label>
            <textarea name="comment" rows="3" required></textarea>
        </div>
        <button type="submit" name="add_comment">Post Comment</button>
    </form>
    <?php endif; ?>

    <!-- Documents -->
    <h2>Documents</h2>
    <div class="documents-list">
        <?php while($d = $documents->fetchArray(SQLITE3_ASSOC)): ?>
            <div class="document-item">
                <a href="<?= BASE_URL . $d['file_path'] ?>" target="_blank"><?= htmlspecialchars($d['file_name']) ?></a>
                <small>Uploaded at stage <?= $d['stage_number'] ?: 'N/A' ?></small>
                <?php if ($d['description']): ?>
                    <p><?= htmlspecialchars($d['description']) ?></p>
                <?php endif; ?>
            </div>
        <?php endwhile; ?>
    </div>

    <?php if ($role == 'client'): ?>
    <form method="post" enctype="multipart/form-data" class="doc-upload">
        <input type="hidden" name="app_id" value="<?= $app_id ?>">
        <div class="form-group">
            <label>Upload Document</label>
            <input type="file" name="document" required>
        </div>
        <div class="form-group">
            <label>Stage (optional)</label>
            <input type="number" name="stage" min="1" max="8">
        </div>
        <div class="form-group">
            <label>Description</label>
            <input type="text" name="description">
        </div>
        <button type="submit" name="upload_doc">Upload</button>
    </form>
    <?php endif; ?>
</main>

<style>
.details-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}
.detail-section {
    background: #f8fafc;
    padding: 1rem;
    border-radius: 0.5rem;
}
.detail-section h3 {
    margin: 0 0 0.5rem 0;
    color: #0f3b2c;
}
.progress-container {
    margin: 1.5rem 0;
}
.progress-bar {
    background: #e2e8f0;
    height: 0.75rem;
    border-radius: 1rem;
    overflow: hidden;
    margin-bottom: 0.25rem;
}
.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #059669 0%, #10b981 100%);
}
.stage-labels {
    display: flex;
    justify-content: space-between;
    font-size: 0.75rem;
    color: #64748b;
}
.stage-labels span.completed {
    color: #059669;
    font-weight: 600;
}
.comments-section {
    max-height: 300px;
    overflow-y: auto;
    border: 1px solid #e2e8f0;
    padding: 1rem;
    border-radius: 0.5rem;
    background: #f8fafc;
    margin-bottom: 1rem;
}
.comment {
    margin-bottom: 1rem;
    padding-bottom: 0.5rem;
    border-bottom: 1px dashed #cbd5e1;
}
.comment.admin-comment {
    background: #e0f2fe;
    padding: 0.5rem;
    border-radius: 0.5rem;
}
.documents-list {
    margin: 1rem 0;
}
.document-item {
    background: #f1f5f9;
    padding: 0.5rem;
    margin-bottom: 0.5rem;
    border-radius: 0.25rem;
}
</style>

<?php include __DIR__ . '/../partials/footer.php'; ?>