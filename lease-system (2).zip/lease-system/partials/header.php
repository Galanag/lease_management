<?php
// partials/header.php
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../config.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= SITE_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        html { scroll-behavior: smooth; }
        .fade-in {
            animation: fadeIn 0.8s ease-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.02);
        }
        .btn-animate {
            transition: all 0.2s ease;
        }
        .btn-animate:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-50 to-gray-100 font-sans">
    <nav class="sticky top-0 z-50 bg-white/80 backdrop-blur-md shadow-sm border-b border-gray-200">
        <div class="container mx-auto px-4 py-3 flex justify-between items-center">
            <a href="<?= BASE_URL ?>" class="text-2xl font-bold text-green-700 hover:text-green-800 transition">
                <i class="fas fa-leaf mr-2"></i>SiinQee Lease
            </a>
            <div class="hidden md:flex space-x-6 items-center">
                <a href="<?= BASE_URL ?>" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-home"></i> Home</a>
                <a href="<?= BASE_URL ?>?page=calculator" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-calculator"></i> Calculator</a>
                <a href="<?= BASE_URL ?>?page=market" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-store"></i> Market</a>
                <a href="<?= BASE_URL ?>?page=track" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-chart-line"></i> Track Lease</a>
                <a href="<?= BASE_URL ?>?page=about" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-info-circle"></i> About</a>
                <a href="<?= BASE_URL ?>?page=contact" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-envelope"></i> Contact</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="<?= BASE_URL ?>?page=dashboard" class="text-gray-700 hover:text-green-600 transition flex items-center gap-1"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                    <!-- Notification Bell -->
                    <div class="relative">
                        <button id="notificationsBtn" class="text-gray-700 hover:text-green-600 transition relative">
                            <i class="fas fa-bell text-xl"></i>
                            <?php
                            $unreadCount = 0;
                            if (function_exists('getUnreadNotificationCount')) {
                                $unreadCount = getUnreadNotificationCount($_SESSION['user_id']);
                            }
                            ?>
                            <?php if ($unreadCount > 0): ?>
                                <span class="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5"><?= $unreadCount ?></span>
                            <?php endif; ?>
                        </button>
                        <!-- Notifications dropdown -->
                        <div id="notificationsDropdown" class="absolute right-0 mt-2 w-80 bg-white rounded shadow-lg z-50 hidden">
                            <div class="p-3 border-b font-semibold">Notifications</div>
                            <div class="max-h-64 overflow-y-auto">
                                <?php
                                if (isset($_SESSION['user_id'])) {
                                    $db = getDb();
                                    $notifications = $db->query("SELECT * FROM notifications WHERE user_id = {$_SESSION['user_id']} ORDER BY created_at DESC LIMIT 10");
                                    if ($notifications && $notifications->numColumns() > 0) {
                                        while ($n = $notifications->fetchArray(SQLITE3_ASSOC)) {
                                            echo '<a href="' . ($n['link'] ? BASE_URL . $n['link'] : '#') . '" class="block px-3 py-2 hover:bg-gray-100 border-b text-sm">';
                                            echo '<p class="font-medium">' . htmlspecialchars($n['message']) . '</p>';
                                            echo '<p class="text-xs text-gray-500">' . date('M j, Y g:i a', strtotime($n['created_at'])) . '</p>';
                                            echo '</a>';
                                        }
                                    } else {
                                        echo '<div class="px-3 py-2 text-gray-500">No notifications.</div>';
                                    }
                                } else {
                                    echo '<div class="px-3 py-2 text-gray-500">Please log in to see notifications.</div>';
                                }
                                ?>
                            </div>
                            <div class="p-2 border-t text-center">
                                <a href="#" id="markAllReadBtn" class="text-sm text-green-600">Mark all as read</a>
                            </div>
                        </div>
                    </div>
                    <!-- Profile Dropdown -->
                    <div class="relative">
                        <button id="profileBtn" class="flex items-center space-x-1 text-gray-700 hover:text-green-600 transition">
                            <i class="fas fa-user-circle text-2xl"></i>
                            <span><?= htmlspecialchars($_SESSION['user_name'] ?? $_SESSION['username'] ?? 'User') ?></span>
                            <i class="fas fa-chevron-down text-xs"></i>
                        </button>
                        <div id="profileDropdown" class="absolute right-0 mt-2 w-48 bg-white rounded shadow-lg z-50 hidden">
                            <a href="<?= BASE_URL ?>?page=profile" class="block px-4 py-2 hover:bg-gray-100">Profile</a>
                            <a href="<?= BASE_URL ?>?page=settings" class="block px-4 py-2 hover:bg-gray-100">Settings</a>
                            <hr class="my-1">
                            <a href="<?= BASE_URL ?>?page=logout" class="block px-4 py-2 hover:bg-gray-100 text-red-600">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>?page=login" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition flex items-center gap-1"><i class="fas fa-sign-in-alt"></i> Login</a>
                    <a href="<?= BASE_URL ?>?page=register_client" class="border border-green-600 text-green-600 hover:bg-green-50 px-4 py-2 rounded-lg transition flex items-center gap-1"><i class="fas fa-user-plus"></i> Client</a>
                    <a href="<?= BASE_URL ?>?page=register_vendor" class="border border-green-600 text-green-600 hover:bg-green-50 px-4 py-2 rounded-lg transition flex items-center gap-1"><i class="fas fa-truck"></i> Vendor</a>
                <?php endif; ?>
            </div>
            <button id="mobile-menu-button" class="md:hidden text-gray-700 focus:outline-none">
                <i class="fas fa-bars text-2xl"></i>
            </button>
        </div>
        <div id="mobile-menu" class="md:hidden hidden bg-white border-t border-gray-200">
            <div class="flex flex-col space-y-3 p-4">
                <a href="<?= BASE_URL ?>" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-home w-5"></i> Home</a>
                <a href="<?= BASE_URL ?>?page=calculator" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-calculator w-5"></i> Calculator</a>
                <a href="<?= BASE_URL ?>?page=market" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-store w-5"></i> Market</a>
                <a href="<?= BASE_URL ?>?page=track" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-chart-line w-5"></i> Track Lease</a>
                <a href="<?= BASE_URL ?>?page=about" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-info-circle w-5"></i> About</a>
                <a href="<?= BASE_URL ?>?page=contact" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-envelope w-5"></i> Contact</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="<?= BASE_URL ?>?page=dashboard" class="text-gray-700 hover:text-green-600 transition flex items-center gap-2"><i class="fas fa-tachometer-alt w-5"></i> Dashboard</a>
                    <a href="<?= BASE_URL ?>?page=logout" class="bg-red-500 text-white px-4 py-2 rounded-lg text-center flex items-center justify-center gap-2"><i class="fas fa-sign-out-alt"></i> Logout</a>
                <?php else: ?>
                    <a href="<?= BASE_URL ?>?page=login" class="bg-green-600 text-white px-4 py-2 rounded-lg text-center flex items-center justify-center gap-2"><i class="fas fa-sign-in-alt"></i> Login</a>
                    <a href="<?= BASE_URL ?>?page=register_client" class="border border-green-600 text-green-600 hover:bg-green-50 px-4 py-2 rounded-lg text-center flex items-center justify-center gap-2"><i class="fas fa-user-plus"></i> Register as Client</a>
                    <a href="<?= BASE_URL ?>?page=register_vendor" class="border border-green-600 text-green-600 hover:bg-green-50 px-4 py-2 rounded-lg text-center flex items-center justify-center gap-2"><i class="fas fa-truck"></i> Register as Vendor</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <main class="fade-in">
        <script>
            // Dropdown toggles (run after DOM is ready)
            document.addEventListener('DOMContentLoaded', function() {
                const notifBtn = document.getElementById('notificationsBtn');
                const notifDropdown = document.getElementById('notificationsDropdown');
                if (notifBtn && notifDropdown) {
                    notifBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        notifDropdown.classList.toggle('hidden');
                    });
                    // Close when clicking outside
                    document.addEventListener('click', (e) => {
                        if (!notifBtn.contains(e.target) && !notifDropdown.contains(e.target)) {
                            notifDropdown.classList.add('hidden');
                        }
                    });
                }

                const profileBtn = document.getElementById('profileBtn');
                const profileDropdown = document.getElementById('profileDropdown');
                if (profileBtn && profileDropdown) {
                    profileBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        profileDropdown.classList.toggle('hidden');
                    });
                    document.addEventListener('click', (e) => {
                        if (!profileBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
                            profileDropdown.classList.add('hidden');
                        }
                    });
                }

                const markAllBtn = document.getElementById('markAllReadBtn');
                if (markAllBtn) {
                    markAllBtn.addEventListener('click', async (e) => {
                        e.preventDefault();
                        const res = await fetch('<?= BASE_URL ?>api/mark_notifications_read.php');
                        if (res.ok) {
                            location.reload();
                        }
                    });
                }
            });
        </script>