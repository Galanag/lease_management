<?php
// populate_zones.php
require_once 'config.php';

$db = getDb();

// Clear existing zones (optional)
$db->exec("DELETE FROM zones");

// Map zone -> branch name from your Excel
$zonesData = [
    'East Shoa' => 'Adama',
    'Adama' => 'Adama',
    'Batu' => 'Adama',
    'Mojo' => 'Adama',
    'West Shoa' => 'Ambo',
    'Ambo' => 'Ambo',
    'Arsi' => 'Asella',
    'Asella' => 'Asella',
    'Bishoftu' => 'Bishoftu',
    'H/G/ Welega' => 'Bule Hora',
    'Borana' => 'Bule Hora',
    'East Borana' => 'Bule Hora',
    'Guji' => 'Bule Hora',
    'West Guji' => 'Bule Hora',
    'Shakiso' => 'Bule Hora',
    'Bule hora' => 'Bule Hora',
    'Moyale' => 'Bule Hora',
    'Holeta' => 'Burayu',
    'shagar' => 'Burayu', // assign to Burayu (the row has ambiguity)
    'North Shoa' => 'Fiche',
    'Shano' => 'Fiche',
    'Kelem Welega' => 'Gimbi',
    'West Walega' => 'Gimbi',
    'Najo' => 'Gimbi',
    'East Hararge' => 'Haramaya',
    'West Hararge' => 'Haramaya',
    'Maya' => 'Haramaya',
    'Jimma' => 'Jimma',
    'Agaro' => 'Jimma',
    'Jimma Town' => 'Jimma',
    'Sandafa' => 'L/Tefo',
    'Buno Badele' => 'Mattu',
    'I/A/Bor' => 'Mattu',
    'Matu' => 'Mattu',
    'East Welega' => 'Nekemte',
    'Nekemte' => 'Nekemte',
    'East Bale' => 'Robe',
    'Bale' => 'Robe',
    'Robe Town' => 'Robe',
    'West Arsi' => 'Shashamanne',
    'Dodola' => 'Shashamanne',
    'Shashamane' => 'Shashamanne',
    'S/W/Shao' => 'Waliso',
    'Waliso' => 'Waliso'
];

// Get branch IDs
$branchIds = [];
$res = $db->query("SELECT id, name FROM branches");
while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
    $branchIds[$row['name']] = $row['id'];
}

$stmt = $db->prepare("INSERT INTO zones (name, branch_id) VALUES (:name, :branch_id)");
foreach ($zonesData as $zone => $branchName) {
    if (isset($branchIds[$branchName])) {
        $stmt->bindValue(':name', $zone, SQLITE3_TEXT);
        $stmt->bindValue(':branch_id', $branchIds[$branchName], SQLITE3_INTEGER);
        $stmt->execute();
    } else {
        echo "Warning: Branch '$branchName' not found for zone '$zone'<br>";
    }
}

echo "Zones populated successfully.";