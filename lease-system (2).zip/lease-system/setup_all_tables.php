<?php
// setup_all_tables.php
require_once 'config.php';

$db = getDb();

// Drop all tables (careful – deletes all data)
$tables = [
    'users', 'applications', 'application_stages', 'documents', 'document_requirements',
    'notifications', 'payment_schedules', 'installments', 'service_requests',
    'asset_tracking', 'site_visits', 'branches', 'zones', 'products',
    'down_payment_rates', 'application_fees', 'service_charge_rates', 'contact_info'
];
foreach ($tables as $table) {
    $db->exec("DROP TABLE IF EXISTS $table");
}

// ---------- users ----------
$db->exec("CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    full_name TEXT,
    phone TEXT,
    role TEXT DEFAULT 'client',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");
$testPass = password_hash('password', PASSWORD_DEFAULT);
$db->exec("INSERT INTO users (email, password, full_name, phone, role) VALUES
    ('client@test.com', '$testPass', 'Test Client', '0911111111', 'client'),
    ('admin@test.com', '$testPass', 'Admin User', '0922222222', 'admin'),
    ('vendor@test.com', '$testPass', 'Vendor User', '0933333333', 'vendor'),
    ('staff@test.com', '$testPass', 'Staff User', '0944444444', 'staff')");

// ---------- branches ----------
$db->exec("CREATE TABLE branches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    city TEXT
)");
$branches = ['Adama','Ambo','Asella','Bishoftu','Bule Hora','Burayu','Fiche','Gimbi','Haramaya','Jimma','L/Tefo','Mattu','Nekemte','Robe','Sebeta','Shashamanne','Waliso'];
$stmt = $db->prepare("INSERT INTO branches (name) VALUES (?)");
foreach ($branches as $b) { $stmt->bindValue(1,$b); $stmt->execute(); }

// ---------- zones ----------
$db->exec("CREATE TABLE zones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    branch_id INTEGER,
    FOREIGN KEY (branch_id) REFERENCES branches(id)
)");
// Insert sample zone mapping (simplified – add all from your document)
$zoneMap = [
    'East Shoa' => 'Adama', 'Adama' => 'Adama', 'Batu' => 'Adama', 'Mojo' => 'Adama',
    'West Shoa' => 'Ambo', 'Ambo' => 'Ambo', 'Arsi' => 'Asella', 'Asella' => 'Asella',
    'Bishoftu' => 'Bishoftu', 'H/G/ Welega' => 'Bule Hora', 'Borana' => 'Bule Hora'
];
$branchIds = [];
$res = $db->query("SELECT id, name FROM branches");
while ($row = $res->fetchArray(SQLITE3_ASSOC)) $branchIds[$row['name']] = $row['id'];
$stmt = $db->prepare("INSERT INTO zones (name, branch_id) VALUES (?, ?)");
foreach ($zoneMap as $zone=>$branch) {
    if (isset($branchIds[$branch])) {
        $stmt->bindValue(1,$zone); $stmt->bindValue(2,$branchIds[$branch]); $stmt->execute();
    }
}

// ---------- products ----------
$db->exec("CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL,
    sector TEXT,
    available INTEGER DEFAULT 1,
    vendor_id INTEGER
)");
$db->exec("INSERT INTO products (name, price, sector) VALUES
    ('Tractor', 500000, 'Agriculture'),
    ('Excavator', 1200000, 'Construction'),
    ('Harvester', 800000, 'Agriculture')");

// ---------- down_payment_rates ----------
$db->exec("CREATE TABLE down_payment_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT NOT NULL,
    rate REAL NOT NULL
)");
$down = [['IMX',10],['Manufacturing',15],['Agriculture',20],['Services',20],['Construction',25],['Employees',5]];
$stmt = $db->prepare("INSERT INTO down_payment_rates (sector, rate) VALUES (?,?)");
foreach ($down as $r) { $stmt->bindValue(1,$r[0]); $stmt->bindValue(2,$r[1]); $stmt->execute(); }

// ---------- application_fees ----------
$db->exec("CREATE TABLE application_fees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT NOT NULL,
    fee REAL NOT NULL
)");
$fees = [['Agriculture',1500],['Manufacturing',1500],['Construction',2000],['Services',1500],['IMX',500]];
$stmt = $db->prepare("INSERT INTO application_fees (sector, fee) VALUES (?,?)");
foreach ($fees as $f) { $stmt->bindValue(1,$f[0]); $stmt->bindValue(2,$f[1]); $stmt->execute(); }

// ---------- service_charge_rates ----------
$db->exec("CREATE TABLE service_charge_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT NOT NULL,
    term_min INTEGER,
    term_max INTEGER,
    rate REAL NOT NULL
)");
$rates = [
    ['IMX',1,2,20.0],['IMX',2,4,20.5],['IMX',4,5,21.5],['IMX',5,7,22.0],
    ['Agriculture',1,2,20.0],['Agriculture',2,4,21.5],['Agriculture',4,5,22.0],
    ['Manufacturing',1,2,20.0],['Manufacturing',2,4,21.5],['Manufacturing',4,5,22.0],['Manufacturing',5,7,22.5],
    ['Services',1,2,20.0],['Services',2,4,21.5],['Services',4,5,22.0],['Services',5,7,22.5],
    ['Construction',1,2,21.0],['Construction',2,4,21.5],['Construction',4,5,22.5],['Construction',5,7,23.0],
    ['Employees',1,2,12.0],['Employees',2,4,12.5],['Employees',4,5,13.0],['Employees',5,7,14.0]
];
$stmt = $db->prepare("INSERT INTO service_charge_rates (sector, term_min, term_max, rate) VALUES (?,?,?,?)");
foreach ($rates as $r) { $stmt->bindValue(1,$r[0]); $stmt->bindValue(2,$r[1]); $stmt->bindValue(3,$r[2]); $stmt->bindValue(4,$r[3]); $stmt->execute(); }

// ---------- contact_info ----------
$db->exec("CREATE TABLE contact_info (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT,
    phone TEXT,
    manager TEXT
)");
$db->exec("INSERT INTO contact_info (address, phone, manager) VALUES 
    ('Addis Ababa, Ethiopia', '+251 911 234 567', 'John Doe')");

// ---------- applications (basic) ----------
$db->exec("CREATE TABLE applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lease_id TEXT,
    user_id INTEGER,
    branch_id INTEGER,
    product_id INTEGER,
    sector TEXT,
    total_amount REAL,
    down_payment REAL,
    financed_amount REAL,
    service_charge REAL,
    total_repayment REAL,
    term_months INTEGER,
    frequency TEXT,
    status TEXT DEFAULT 'inquiry',
    current_stage INTEGER DEFAULT 1,
    conditions TEXT,
    insurance_expiry DATE,
    insurance_notified INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME,
    FOREIGN KEY(user_id) REFERENCES users(id)
)");

// ---------- application_stages ----------
$db->exec("CREATE TABLE application_stages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    stage_number INTEGER NOT NULL,
    stage_name TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    started_at DATETIME,
    completed_at DATETIME,
    expected_completion DATE,
    notes TEXT,
    FOREIGN KEY(application_id) REFERENCES applications(id)
)");

// ---------- documents ----------
$db->exec("CREATE TABLE documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    document_type TEXT,
    file_name TEXT,
    file_path TEXT,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_verified INTEGER DEFAULT 0,
    verified_by INTEGER,
    verified_at DATETIME,
    FOREIGN KEY(application_id) REFERENCES applications(id),
    FOREIGN KEY(user_id) REFERENCES users(id)
)");

// ---------- document_requirements ----------
$db->exec("CREATE TABLE document_requirements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stage_number INTEGER NOT NULL,
    document_type TEXT NOT NULL,
    description TEXT,
    is_required INTEGER DEFAULT 1
)");
$reqs = [
    [1,'business_license','Valid business license',1],
    [1,'tin_certificate','TIN certificate',1],
    [1,'national_id','National ID of owner',1],
    [2,'financial_statement','Last 6 months bank statement',1],
    [3,'collateral_docs','Collateral ownership documents',1],
    [4,'signed_contract','Signed lease contract',1]
];
$stmt = $db->prepare("INSERT INTO document_requirements (stage_number, document_type, description, is_required) VALUES (?,?,?,?)");
foreach ($reqs as $r) { $stmt->bindValue(1,$r[0]); $stmt->bindValue(2,$r[1]); $stmt->bindValue(3,$r[2]); $stmt->bindValue(4,$r[3]); $stmt->execute(); }

// ---------- notifications ----------
$db->exec("CREATE TABLE notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    type TEXT,
    subject TEXT,
    message TEXT,
    sent_at DATETIME,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
)");

// ---------- payment_schedules ----------
$db->exec("CREATE TABLE payment_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    total_financed REAL NOT NULL,
    total_service_charge REAL NOT NULL,
    total_repayment REAL NOT NULL,
    installment_count INTEGER NOT NULL,
    frequency TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    modified_at DATETIME,
    FOREIGN KEY(application_id) REFERENCES applications(id)
)");

// ---------- installments ----------
$db->exec("CREATE TABLE installments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    schedule_id INTEGER NOT NULL,
    due_date DATE NOT NULL,
    amount REAL NOT NULL,
    status TEXT DEFAULT 'pending',
    paid_date DATE,
    payment_method TEXT,
    transaction_id TEXT,
    notes TEXT,
    penalty_amount REAL DEFAULT 0,
    FOREIGN KEY(schedule_id) REFERENCES payment_schedules(id)
)");

// ---------- service_requests ----------
$db->exec("CREATE TABLE service_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    subject TEXT,
    description TEXT,
    status TEXT DEFAULT 'open',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME,
    FOREIGN KEY(application_id) REFERENCES applications(id),
    FOREIGN KEY(user_id) REFERENCES users(id)
)");

// ---------- asset_tracking ----------
$db->exec("CREATE TABLE asset_tracking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    supplier TEXT,
    order_date DATE,
    expected_delivery DATE,
    actual_delivery DATE,
    installation_date DATE,
    status TEXT DEFAULT 'ordered',
    notes TEXT,
    FOREIGN KEY(application_id) REFERENCES applications(id)
)");

// ---------- site_visits ----------
$db->exec("CREATE TABLE site_visits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    scheduled_date DATE,
    visited_date DATE,
    conducted_by INTEGER,
    report TEXT,
    status TEXT DEFAULT 'scheduled',
    staff_id INTEGER,
    notes TEXT,
    FOREIGN KEY(application_id) REFERENCES applications(id)
)");

echo "All tables created successfully.";