<?php
// setup_database.php
require_once __DIR__ . '/includes/config.php'; // Adjust path as needed

$db = getDb();

// ========== 1. Down Payment Rates ==========
$db->exec("DROP TABLE IF EXISTS down_payment_rates");
$db->exec("CREATE TABLE down_payment_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT NOT NULL,
    rate REAL NOT NULL
)");

$downPaymentData = [
    ['IMX', 10],
    ['Manufacturing', 15],
    ['Agriculture', 20],
    ['Services', 20],
    ['Construction', 25],
    ['Employees', 5]
];

$stmt = $db->prepare("INSERT INTO down_payment_rates (sector, rate) VALUES (?, ?)");
foreach ($downPaymentData as $row) {
    $stmt->bindValue(1, $row[0], SQLITE3_TEXT);
    $stmt->bindValue(2, $row[1], SQLITE3_FLOAT);
    $stmt->execute();
}

// ========== 2. Application Fees ==========
$db->exec("DROP TABLE IF EXISTS application_fees");
$db->exec("CREATE TABLE application_fees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT NOT NULL,
    fee REAL NOT NULL
)");

$feeData = [
    ['Agriculture', 1500],
    ['Manufacturing', 1500],
    ['Construction', 2000],
    ['Services', 1500],
    ['IMX', 500]
];

$stmt = $db->prepare("INSERT INTO application_fees (sector, fee) VALUES (?, ?)");
foreach ($feeData as $row) {
    $stmt->bindValue(1, $row[0], SQLITE3_TEXT);
    $stmt->bindValue(2, $row[1], SQLITE3_FLOAT);
    $stmt->execute();
}

// ========== 3. Service Charge Rates ==========
$db->exec("DROP TABLE IF EXISTS service_charge_rates");
$db->exec("CREATE TABLE service_charge_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT NOT NULL,
    term_min INTEGER,
    term_max INTEGER,
    rate REAL NOT NULL
)");

$serviceData = [
    ['IMX', 1, 2, 20.0],
    ['IMX', 2, 4, 20.5],
    ['IMX', 4, 5, 21.5],
    ['IMX', 5, 7, 22.0],
    ['Agriculture', 1, 2, 20.0],
    ['Agriculture', 2, 4, 21.5],
    ['Agriculture', 4, 5, 22.0],
    ['Manufacturing', 1, 2, 20.0],
    ['Manufacturing', 2, 4, 21.5],
    ['Manufacturing', 4, 5, 22.0],
    ['Manufacturing', 5, 7, 22.5],
    ['Services', 1, 2, 20.0],
    ['Services', 2, 4, 21.5],
    ['Services', 4, 5, 22.0],
    ['Services', 5, 7, 22.5],
    ['Construction', 1, 2, 21.0],
    ['Construction', 2, 4, 21.5],
    ['Construction', 4, 5, 22.5],
    ['Construction', 5, 7, 23.0],
    ['Employees', 1, 2, 12.0],
    ['Employees', 2, 4, 12.5],
    ['Employees', 4, 5, 13.0],
    ['Employees', 5, 7, 14.0]
];

$stmt = $db->prepare("INSERT INTO service_charge_rates (sector, term_min, term_max, rate) VALUES (?, ?, ?, ?)");
foreach ($serviceData as $row) {
    $stmt->bindValue(1, $row[0], SQLITE3_TEXT);
    $stmt->bindValue(2, $row[1], SQLITE3_INTEGER);
    $stmt->bindValue(3, $row[2], SQLITE3_INTEGER);
    $stmt->bindValue(4, $row[3], SQLITE3_FLOAT);
    $stmt->execute();
}

// ========== 4. Branches (from Sheet1) ==========
$db->exec("DROP TABLE IF EXISTS branches");
$db->exec("CREATE TABLE branches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    city TEXT
)");

$branchesData = [
    ['Adama'],
    ['Ambo'],
    ['Asella'],
    ['Bishoftu'],
    ['Bule Hora'],
    ['Burayu'],
    ['Fiche'],
    ['Gimbi'],
    ['Haramaya'],
    ['Jimma'],
    ['L/Tefo'],
    ['Mattu'],
    ['Nekemte'],
    ['Robe'],
    ['Sebeta'],
    ['Shashamanne'],
    ['Waliso']
];

$stmt = $db->prepare("INSERT INTO branches (name) VALUES (?)");
foreach ($branchesData as $row) {
    $stmt->bindValue(1, $row[0], SQLITE3_TEXT);
    $stmt->execute();
}

// ========== 5. Zones / Towns (from Sheet2) ==========
$db->exec("DROP TABLE IF EXISTS zones");
$db->exec("CREATE TABLE zones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    branch_id INTEGER,
    FOREIGN KEY (branch_id) REFERENCES branches(id)
)");

// Map zone/town names to branch names (from Sheet2)
$zoneMapping = [
    'East Shoa' => 'Adama',
    'Adama' => 'Adama',
    'Batu' => 'Adama',
    'Mojo' => 'Adama',
    'West Shoa' => 'Ambo',
    'Ambo' => 'Ambo',
    'Arsi' => 'Asella',
    'Asella' => 'Asella',
    'Bishoftu' => 'Bishoftu',
    'H/G/ Welega' => 'Bule Hora',
    'Borana' => 'Bule Hora',
    'East Borana' => 'Bule Hora',
    'Guji' => 'Bule Hora',
    'West Guji' => 'Bule Hora',
    'Shakiso' => 'Bule Hora',
    'Bule hora' => 'Bule Hora',
    'Moyale' => 'Bule Hora',
    'Holeta' => 'Burayu',
    'shagar' => 'Burayu', // note: might be ambiguous
    'North Shoa' => 'Fiche',
    'Shano' => 'Fiche',
    'Kelem Welega' => 'Gimbi',
    'West Walega' => 'Gimbi',
    'Najo' => 'Gimbi',
    'East Hararge' => 'Haramaya',
    'West Hararge' => 'Haramaya',
    'Maya' => 'Haramaya',
    'Jimma' => 'Jimma',
    'Agaro' => 'Jimma',
    'Jimma Town' => 'Jimma',
    'Sandafa' => 'L/Tefo',
    'Buno Badele' => 'Mattu',
    'I/A/Bor' => 'Mattu',
    'Matu' => 'Mattu',
    'East Welega' => 'Nekemte',
    'Nekemte' => 'Nekemte',
    'East Bale' => 'Robe',
    'Bale' => 'Robe',
    'Robe Town' => 'Robe',
    'West Arsi' => 'Shashamanne',
    'Dodola' => 'Shashamanne',
    'Shashamane' => 'Shashamanne',
    'S/W/Shao' => 'Waliso',
    'Waliso' => 'Waliso'
];

// First, get branch IDs
$branchIds = [];
$res = $db->query("SELECT id, name FROM branches");
while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
    $branchIds[$row['name']] = $row['id'];
}

$stmt = $db->prepare("INSERT INTO zones (name, branch_id) VALUES (?, ?)");
foreach ($zoneMapping as $zoneName => $branchName) {
    if (isset($branchIds[$branchName])) {
        $stmt->bindValue(1, $zoneName, SQLITE3_TEXT);
        $stmt->bindValue(2, $branchIds[$branchName], SQLITE3_INTEGER);
        $stmt->execute();
    } else {
        echo "Warning: Branch '$branchName' not found for zone '$zoneName'\n";
    }
}

// ========== 6. Late Penalty ==========
$db->exec("DROP TABLE IF EXISTS late_penalty");
$db->exec("CREATE TABLE late_penalty (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    monthly_rate REAL NOT NULL,
    daily_rate REAL NOT NULL
)");
$db->exec("INSERT INTO late_penalty (monthly_rate, daily_rate) VALUES (2.0, 0.0667)");

// ========== 7. Reschedule Fees ==========
$db->exec("DROP TABLE IF EXISTS reschedule_fees");
$db->exec("CREATE TABLE reschedule_fees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    request_order INTEGER NOT NULL,
    fee REAL NOT NULL
)");
$fees = [
    [1, 1000],
    [2, 1500],
    [3, 2500]
];
$stmt = $db->prepare("INSERT INTO reschedule_fees (request_order, fee) VALUES (?, ?)");
foreach ($fees as $row) {
    $stmt->bindValue(1, $row[0], SQLITE3_INTEGER);
    $stmt->bindValue(2, $row[1], SQLITE3_FLOAT);
    $stmt->execute();
}

echo "Database setup complete!";