<?php
require_once __DIR__ . '/config.php';
$db = getDb();

// Drop existing tables (CAUTION: deletes all data)
$tables = ['down_payment_rates','application_fees','service_charge_rates',
           'branches','zones','users','products','contact_info','applications'];
foreach ($tables as $table) {
    $db->exec("DROP TABLE IF EXISTS $table");
}

// ========== down_payment_rates ==========
$db->exec("CREATE TABLE down_payment_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT NOT NULL,
    rate REAL NOT NULL
)");
$data = [
    ['IMX',10],['Manufacturing',15],['Agriculture',20],
    ['Services',20],['Construction',25],['Employees',5]
];
$stmt = $db->prepare("INSERT INTO down_payment_rates (sector, rate) VALUES (?, ?)");
foreach($data as $row) { $stmt->bindValue(1,$row[0]); $stmt->bindValue(2,$row[1]); $stmt->execute(); }

// ========== application_fees ==========
$db->exec("CREATE TABLE application_fees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT NOT NULL,
    fee REAL NOT NULL
)");
$fees = [['Agriculture',1500],['Manufacturing',1500],['Construction',2000],['Services',1500],['IMX',500]];
$stmt = $db->prepare("INSERT INTO application_fees (sector, fee) VALUES (?, ?)");
foreach($fees as $row) { $stmt->bindValue(1,$row[0]); $stmt->bindValue(2,$row[1]); $stmt->execute(); }

// ========== service_charge_rates ==========
$db->exec("CREATE TABLE service_charge_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sector TEXT NOT NULL,
    term_min INTEGER,
    term_max INTEGER,
    rate REAL NOT NULL
)");
$rates = [
    ['IMX',1,2,20.0],['IMX',2,4,20.5],['IMX',4,5,21.5],['IMX',5,7,22.0],
    ['Agriculture',1,2,20.0],['Agriculture',2,4,21.5],['Agriculture',4,5,22.0],
    ['Manufacturing',1,2,20.0],['Manufacturing',2,4,21.5],['Manufacturing',4,5,22.0],['Manufacturing',5,7,22.5],
    ['Services',1,2,20.0],['Services',2,4,21.5],['Services',4,5,22.0],['Services',5,7,22.5],
    ['Construction',1,2,21.0],['Construction',2,4,21.5],['Construction',4,5,22.5],['Construction',5,7,23.0],
    ['Employees',1,2,12.0],['Employees',2,4,12.5],['Employees',4,5,13.0],['Employees',5,7,14.0]
];
$stmt = $db->prepare("INSERT INTO service_charge_rates (sector, term_min, term_max, rate) VALUES (?, ?, ?, ?)");
foreach($rates as $r) { $stmt->bindValue(1,$r[0]); $stmt->bindValue(2,$r[1]); $stmt->bindValue(3,$r[2]); $stmt->bindValue(4,$r[3]); $stmt->execute(); }

// ========== branches ==========
$db->exec("CREATE TABLE branches (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, city TEXT)");
$branches = ['Adama','Ambo','Asella','Bishoftu','Bule Hora','Burayu','Fiche','Gimbi','Haramaya','Jimma','L/Tefo','Mattu','Nekemte','Robe','Sebeta','Shashamanne','Waliso'];
$stmt = $db->prepare("INSERT INTO branches (name) VALUES (?)");
foreach($branches as $b) { $stmt->bindValue(1,$b); $stmt->execute(); }

// ========== zones ==========
$db->exec("CREATE TABLE zones (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, branch_id INTEGER, FOREIGN KEY(branch_id) REFERENCES branches(id))");
$zoneMap = [
    'East Shoa'=>'Adama','Adama'=>'Adama','Batu'=>'Adama','Mojo'=>'Adama',
    'West Shoa'=>'Ambo','Ambo'=>'Ambo','Arsi'=>'Asella','Asella'=>'Asella',
    'Bishoftu'=>'Bishoftu','H/G/ Welega'=>'Bule Hora','Borana'=>'Bule Hora',
    'East Borana'=>'Bule Hora','Guji'=>'Bule Hora','West Guji'=>'Bule Hora',
    'Shakiso'=>'Bule Hora','Bule hora'=>'Bule Hora','Moyale'=>'Bule Hora',
    'Holeta'=>'Burayu','shagar'=>'Burayu','North Shoa'=>'Fiche','Shano'=>'Fiche',
    'Kelem Welega'=>'Gimbi','West Walega'=>'Gimbi','Najo'=>'Gimbi',
    'East Hararge'=>'Haramaya','West Hararge'=>'Haramaya','Maya'=>'Haramaya',
    'Jimma'=>'Jimma','Agaro'=>'Jimma','Jimma Town'=>'Jimma',
    'Sandafa'=>'L/Tefo','Buno Badele'=>'Mattu','I/A/Bor'=>'Mattu','Matu'=>'Mattu',
    'East Welega'=>'Nekemte','Nekemte'=>'Nekemte',
    'East Bale'=>'Robe','Bale'=>'Robe','Robe Town'=>'Robe',
    'West Arsi'=>'Shashamanne','Dodola'=>'Shashamanne','Shashamane'=>'Shashamanne',
    'S/W/Shao'=>'Waliso','Waliso'=>'Waliso'
];
$branchIds = [];
$res = $db->query("SELECT id, name FROM branches");
while($row = $res->fetchArray(SQLITE3_ASSOC)) $branchIds[$row['name']] = $row['id'];
$stmt = $db->prepare("INSERT INTO zones (name, branch_id) VALUES (?, ?)");
foreach($zoneMap as $zone=>$branch) {
    if(isset($branchIds[$branch])) {
        $stmt->bindValue(1,$zone); $stmt->bindValue(2,$branchIds[$branch]); $stmt->execute();
    }
}

// ========== users ==========
$db->exec("CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    full_name TEXT,
    phone TEXT,
    role TEXT DEFAULT 'client',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");
$testPass = password_hash('password', PASSWORD_DEFAULT);
$db->exec("INSERT INTO users (email, password, full_name, phone, role) VALUES 
    ('client@test.com', '$testPass', 'Test Client', '0911111111', 'client'),
    ('vendor@test.com', '$testPass', 'Test Vendor', '0922222222', 'vendor')");

// ========== products ==========
$db->exec("CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL,
    sector TEXT,
    available INTEGER DEFAULT 1,
    vendor_id INTEGER
)");
$db->exec("INSERT INTO products (name, price, sector) VALUES 
    ('Tractor', 500000, 'Agriculture'),
    ('Excavator', 1200000, 'Construction'),
    ('Harvester', 800000, 'Agriculture'),
    ('Loader', 600000, 'Construction')");

// ========== contact_info ==========
$db->exec("CREATE TABLE contact_info (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT,
    phone TEXT,
    manager TEXT
)");
$db->exec("INSERT INTO contact_info (address, phone, manager) VALUES 
    ('Addis Ababa, Ethiopia', '+251 911 234 567', 'John Doe')");

// ========== applications (simplified for now) ==========
$db->exec("CREATE TABLE applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    sector TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");

echo "Database setup complete. <a href='index.php'>Go to site</a>";