<?php
// setup_full_database.php
require_once 'config.php';

$db = getDb();

// Drop existing tables (optional – be careful)
$tables = [
    'application_stages', 'documents', 'notifications', 'payment_schedules',
    'installments', 'service_requests', 'asset_tracking', 'site_visits',
    'applications', 'users', 'branches', 'products', 'down_payment_rates',
    'application_fees', 'service_charge_rates', 'zones', 'contact_info'
];
foreach ($tables as $table) {
    $db->exec("DROP TABLE IF EXISTS $table");
}

// ========== USERS ==========
$db->exec("CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    full_name TEXT,
    phone TEXT,
    role TEXT DEFAULT 'client',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)");
// Insert test users (password = 'password')
$testPass = password_hash('password', PASSWORD_DEFAULT);
$db->exec("INSERT INTO users (email, password, full_name, phone, role) VALUES
    ('client@test.com', '$testPass', 'Test Client', '0911111111', 'client'),
    ('admin@test.com', '$testPass', 'Admin User', '0922222222', 'admin'),
    ('vendor@test.com', '$testPass', 'Vendor User', '0933333333', 'vendor')");

// ========== BRANCHES ==========
$db->exec("CREATE TABLE branches (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, city TEXT)");
$branches = ['Adama','Ambo','Asella','Bishoftu','Bule Hora','Burayu','Fiche','Gimbi','Haramaya','Jimma','L/Tefo','Mattu','Nekemte','Robe','Sebeta','Shashamanne','Waliso'];
$stmt = $db->prepare("INSERT INTO branches (name) VALUES (?)");
foreach ($branches as $b) { $stmt->bindValue(1,$b); $stmt->execute(); }

// ========== PRODUCTS ==========
$db->exec("CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL,
    sector TEXT,
    available INTEGER DEFAULT 1,
    vendor_id INTEGER
)");
$db->exec("INSERT INTO products (name, price, sector) VALUES
    ('Tractor', 500000, 'Agriculture'),
    ('Excavator', 1200000, 'Construction'),
    ('Harvester', 800000, 'Agriculture')");

// ========== APPLICATIONS (enhanced) ==========
$db->exec("CREATE TABLE applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    lease_id TEXT UNIQUE,
    user_id INTEGER NOT NULL,
    branch_id INTEGER,
    product_id INTEGER,
    sector TEXT,
    total_amount REAL,
    down_payment REAL,
    financed_amount REAL,
    service_charge REAL,
    total_repayment REAL,
    term_months INTEGER,
    frequency TEXT,
    status TEXT DEFAULT 'inquiry',
    current_stage INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME,
    approved_at DATETIME,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(branch_id) REFERENCES branches(id),
    FOREIGN KEY(product_id) REFERENCES products(id)
)");

// ========== APPLICATION STAGES (8 stages) ==========
$db->exec("CREATE TABLE application_stages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    stage_number INTEGER NOT NULL,
    stage_name TEXT NOT NULL,
    status TEXT DEFAULT 'pending', -- pending, in_progress, completed, on_hold
    started_at DATETIME,
    completed_at DATETIME,
    expected_completion DATE,
    notes TEXT,
    FOREIGN KEY(application_id) REFERENCES applications(id)
)");

// ========== DOCUMENTS ==========
$db->exec("CREATE TABLE documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    document_type TEXT, -- e.g., 'business_license', 'tin_certificate'
    file_name TEXT,
    file_path TEXT,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_verified BOOLEAN DEFAULT 0,
    verified_by INTEGER,
    verified_at DATETIME,
    FOREIGN KEY(application_id) REFERENCES applications(id),
    FOREIGN KEY(user_id) REFERENCES users(id)
)");

// ========== DOCUMENT REQUIREMENTS (per stage) ==========
$db->exec("CREATE TABLE document_requirements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    stage_number INTEGER NOT NULL,
    document_type TEXT NOT NULL,
    description TEXT,
    is_required BOOLEAN DEFAULT 1
)");
// Insert requirements for each stage (example)
$requirements = [
    [1, 'business_license', 'Valid business license', 1],
    [1, 'tin_certificate', 'TIN certificate', 1],
    [1, 'national_id', 'National ID of owner', 1],
    [2, 'financial_statement', 'Last 6 months bank statement', 1],
    [3, 'collateral_docs', 'Collateral ownership documents', 1],
    [4, 'signed_contract', 'Signed lease contract', 1]
];
$stmt = $db->prepare("INSERT INTO document_requirements (stage_number, document_type, description, is_required) VALUES (?,?,?,?)");
foreach ($requirements as $r) {
    $stmt->bindValue(1,$r[0]); $stmt->bindValue(2,$r[1]); $stmt->bindValue(3,$r[2]); $stmt->bindValue(4,$r[3]);
    $stmt->execute();
}

// ========== NOTIFICATIONS QUEUE ==========
$db->exec("CREATE TABLE notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    type TEXT, -- 'email', 'sms'
    subject TEXT,
    message TEXT,
    sent_at DATETIME,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
)");

// ========== PAYMENT SCHEDULES ==========
$db->exec("CREATE TABLE payment_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    total_financed REAL NOT NULL,
    total_service_charge REAL NOT NULL,
    total_repayment REAL NOT NULL,
    installment_count INTEGER NOT NULL,
    frequency TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    modified_at DATETIME,
    FOREIGN KEY(application_id) REFERENCES applications(id)
)");

// ========== INSTALLMENTS ==========
$db->exec("CREATE TABLE installments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    schedule_id INTEGER NOT NULL,
    due_date DATE NOT NULL,
    amount REAL NOT NULL,
    status TEXT DEFAULT 'pending', -- pending, paid, overdue, waived
    paid_date DATE,
    payment_method TEXT,
    transaction_id TEXT,
    notes TEXT,
    penalty_amount REAL DEFAULT 0,
    FOREIGN KEY(schedule_id) REFERENCES payment_schedules(id)
)");

// ========== SERVICE REQUESTS ==========
$db->exec("CREATE TABLE service_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    subject TEXT,
    description TEXT,
    status TEXT DEFAULT 'open', -- open, in_progress, resolved, closed
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME,
    FOREIGN KEY(application_id) REFERENCES applications(id),
    FOREIGN KEY(user_id) REFERENCES users(id)
)");

// ========== ASSET TRACKING ==========
$db->exec("CREATE TABLE asset_tracking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    supplier TEXT,
    order_date DATE,
    expected_delivery DATE,
    actual_delivery DATE,
    installation_date DATE,
    status TEXT DEFAULT 'ordered',
    notes TEXT,
    FOREIGN KEY(application_id) REFERENCES applications(id)
)");

// ========== SITE VISITS ==========
$db->exec("CREATE TABLE site_visits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    scheduled_date DATE,
    visited_date DATE,
    conducted_by INTEGER, -- user_id of staff
    report TEXT,
    status TEXT DEFAULT 'scheduled',
    FOREIGN KEY(application_id) REFERENCES applications(id)
)");

// ========== SAMPLE APPLICATION (for testing) ==========
$db->exec("INSERT INTO applications (user_id, sector, total_amount, down_payment, financed_amount, service_charge, total_repayment, term_months, frequency, status, current_stage, created_at)
    VALUES (1, 'Agriculture', 500000, 100000, 400000, 240000, 640000, 36, 'monthly', 'inquiry', 1, datetime('now'))");
$app_id = $db->lastInsertRowID();

// Insert stages for this sample application
for ($stage = 1; $stage <= 8; $stage++) {
    $stageNames = [
        1 => 'Inquiry',
        2 => 'Application Submitted',
        3 => 'Credit & Risk Assessment',
        4 => 'Approval',
        5 => 'Contract Signing',
        6 => 'Asset Procurement',
        7 => 'Disbursement',
        8 => 'Active Lease'
    ];
    $status = ($stage == 1) ? 'completed' : 'pending';
    $completed_at = ($stage == 1) ? 'datetime()' : 'NULL';
    $db->exec("INSERT INTO application_stages (application_id, stage_number, stage_name, status, completed_at)
        VALUES ($app_id, $stage, '{$stageNames[$stage]}', '$status', $completed_at)");
}

echo "Database setup complete!";