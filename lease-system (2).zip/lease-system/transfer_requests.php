<?php
require_once 'config.php';
$db = getDb();
$db->exec("CREATE TABLE IF NOT EXISTS transfer_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    application_id INTEGER NOT NULL,
    from_branch_id INTEGER NOT NULL,
    to_branch_id INTEGER NOT NULL,
    status TEXT DEFAULT 'pending',
    reason TEXT,
    requested_by_user INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    responded_at DATETIME,
    FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE
)");
echo "Table ready.";