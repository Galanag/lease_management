<?php
// update_branch_assignment.php
require_once 'config.php';
$db = getDb();

// Add branch_id to users
$db->exec("ALTER TABLE users ADD COLUMN branch_id INTEGER REFERENCES branches(id)");

// Ensure CRMD branch exists
$crmd = $db->querySingle("SELECT id FROM branches WHERE name = 'CRMD'");
if (!$crmd) {
    $db->exec("INSERT INTO branches (name, city) VALUES ('CRMD', 'Addis Ababa')");
    echo "Added CRMD branch.<br>";
}

// Add reminder_sent to applications
$db->exec("ALTER TABLE applications ADD COLUMN reminder_sent INTEGER DEFAULT 0");

echo "Database updated.";