<?php
require_once 'config.php';
$db = getDb();

// Add manager_id column if missing
$cols = $db->query("PRAGMA table_info(branches)");
$hasManagerId = false;
while ($c = $cols->fetchArray(SQLITE3_ASSOC)) {
    if ($c['name'] == 'manager_id') $hasManagerId = true;
}
if (!$hasManagerId) {
    $db->exec("ALTER TABLE branches ADD COLUMN manager_id INTEGER REFERENCES users(id)");
    echo "✅ Added manager_id column.<br>";
} else {
    echo "ℹ️ manager_id already exists.<br>";
}