<?php
// update_branches_table.php
require_once 'config.php';

$db = getDb();

// Get existing columns
$cols = $db->query("PRAGMA table_info(branches)");
$existing = [];
while ($c = $cols->fetchArray(SQLITE3_ASSOC)) {
    $existing[] = $c['name'];
}

// List of columns that should exist (adjust as needed)
$required = [
    'address' => 'TEXT',
    'phone' => 'TEXT',
    'manager' => 'TEXT',
    'latitude' => 'REAL',
    'longitude' => 'REAL',
    'parent_id' => 'INTEGER'
];

foreach ($required as $col => $type) {
    if (!in_array($col, $existing)) {
        $db->exec("ALTER TABLE branches ADD COLUMN $col $type");
        echo "✅ Added column: $col<br>";
    } else {
        echo "ℹ️ Column $col already exists.<br>";
    }
}