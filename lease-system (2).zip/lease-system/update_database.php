<?php
// update_database.php
require_once 'config.php';

$db = getDb();

// Add columns to applications
$db->exec("ALTER TABLE applications ADD COLUMN conditions TEXT");
$db->exec("ALTER TABLE applications ADD COLUMN insurance_expiry DATE");
$db->exec("ALTER TABLE applications ADD COLUMN insurance_notified INTEGER DEFAULT 0");

// Add staff_id to site_visits if not exists
$tableInfo = $db->query("PRAGMA table_info(site_visits)");
$hasStaff = false;
while ($col = $tableInfo->fetchArray(SQLITE3_ASSOC)) {
    if ($col['name'] === 'staff_id') {
        $hasStaff = true;
        break;
    }
}
if (!$hasStaff) {
    $db->exec("ALTER TABLE site_visits ADD COLUMN staff_id INTEGER");
}

echo "Database updated successfully.";