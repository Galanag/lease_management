<?php
// update_database_for_documents.php
require_once 'config.php';

$db = getDb();

// ========== 1. Add missing columns to users ==========
$columns = $db->query("PRAGMA table_info(users)");
$existingCols = [];
while ($col = $columns->fetchArray(SQLITE3_ASSOC)) {
    $existingCols[] = $col['name'];
}

if (!in_array('approved', $existingCols)) {
    $db->exec("ALTER TABLE users ADD COLUMN approved INTEGER DEFAULT 0");
    echo "✅ Added 'approved' column to users table.<br>";
} else {
    echo "ℹ️ 'approved' column already exists.<br>";
}

if (!in_array('branch_id', $existingCols)) {
    $db->exec("ALTER TABLE users ADD COLUMN branch_id INTEGER REFERENCES branches(id)");
    echo "✅ Added 'branch_id' column to users table.<br>";
} else {
    echo "ℹ️ 'branch_id' column already exists.<br>";
}

// ========== 2. Create application_documents table ==========
$tableExists = $db->querySingle("SELECT name FROM sqlite_master WHERE type='table' AND name='application_documents'");
if (!$tableExists) {
    $db->exec("CREATE TABLE application_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        application_id INTEGER NOT NULL,
        document_type TEXT NOT NULL,
        file_path TEXT NOT NULL,
        uploaded_by INTEGER NOT NULL,
        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        status TEXT DEFAULT 'pending',
        notes TEXT,
        FOREIGN KEY(application_id) REFERENCES applications(id) ON DELETE CASCADE,
        FOREIGN KEY(uploaded_by) REFERENCES users(id)
    )");
    echo "✅ Created application_documents table.<br>";
} else {
    echo "ℹ️ application_documents table already exists.<br>";
}

// ========== 3. Ensure CRMD branch exists (if not already) ==========
$crmd = $db->querySingle("SELECT id FROM branches WHERE name = 'CRMD'");
if (!$crmd) {
    $db->exec("INSERT INTO branches (name, city) VALUES ('CRMD', 'Addis Ababa')");
    echo "✅ Added CRMD branch.<br>";
} else {
    echo "ℹ️ CRMD branch already exists.<br>";
}

echo "<br>All updates completed. You can now <a href='index.php'>return to the site</a>.";