<?php
// update_market_approval.php
require_once 'config.php';

$db = getDb();

// ================== STEP 1: Add 'status' column if missing ==================
$hasStatus = false;
$cols = $db->query("PRAGMA table_info(products)");
while ($col = $cols->fetchArray(SQLITE3_ASSOC)) {
    if ($col['name'] === 'status') {
        $hasStatus = true;
        break;
    }
}
if (!$hasStatus) {
    $db->exec("ALTER TABLE products ADD COLUMN status TEXT DEFAULT 'pending'");
    echo "✅ Added 'status' column to products table.<br>\n";
} else {
    echo "ℹ️ 'status' column already exists.<br>\n";
}

// ================== STEP 2: Set existing products to 'approved' ==================
// (Assumes previously approved products had approved=1 or were manually approved)
$db->exec("UPDATE products SET status = 'approved' WHERE status IS NULL OR status = ''");
echo "✅ Set all existing products to status = 'approved'.<br>\n";

// ================== STEP 3: Update vendor product form to insert with 'pending' ==================
// (We can't modify files automatically, but we can output a note)
echo "<hr>\n<h3>Next Steps:</h3>\n";
echo "<p>Ensure your vendor product submission form sets <code>status = 'pending'</code> for new products.</p>\n";
echo "<p>Example: <code>INSERT INTO products (...) VALUES (..., 'pending');</code></p>\n";

// ================== STEP 4: Provide updated market.php code ==================
echo "<hr>\n<h3>Updated market.php code – copy and replace <code>pages/market.php</code>:</h3>\n";
echo "<pre style='background:#f4f4f4; padding:1em; overflow:auto; max-height:500px;'>\n";

// Read the existing market.php template and modify it
$marketPhp = <<<'PHP'
<?php
// pages/market.php
$pageTitle = 'Market - Available Equipment';
require_once __DIR__ . '/../config.php';

$db = getDb();

// Get filter parameters from URL
$sector = $_GET['sector'] ?? '';
$min_price = $_GET['min_price'] ?? '';
$max_price = $_GET['max_price'] ?? '';
$search = $_GET['search'] ?? '';

// Build query for approved products (using status column)
$query = "SELECT p.*, 
          (SELECT GROUP_CONCAT(image_path, ',') FROM product_images WHERE product_id = p.id ORDER BY sort_order) as images
          FROM products p 
          WHERE p.available = 1 AND p.status = 'approved'";

$params = [];
if (!empty($sector)) {
    $query .= " AND p.sector = :sector";
    $params[':sector'] = $sector;
}
if (!empty($min_price)) {
    $query .= " AND p.price >= :min_price";
    $params[':min_price'] = (float)$min_price;
}
if (!empty($max_price)) {
    $query .= " AND p.price <= :max_price";
    $params[':max_price'] = (float)$max_price;
}
if (!empty($search)) {
    $query .= " AND (p.name LIKE :search OR p.description LIKE :search)";
    $params[':search'] = '%' . $search . '%';
}
$query .= " ORDER BY p.created_at DESC";

$stmt = $db->prepare($query);
foreach ($params as $key => $val) {
    $stmt->bindValue($key, $val, is_float($val) ? SQLITE3_FLOAT : SQLITE3_TEXT);
}
$result = $stmt->execute();
$products = [];
while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
    // Convert comma-separated images to array
    $row['images'] = $row['images'] ? explode(',', $row['images']) : [];
    $products[] = $row;
}

// Get recently leased products (from applications that are active)
$recentLeased = $db->query("
    SELECT p.id, p.name, p.price, p.sector, 
           (SELECT GROUP_CONCAT(image_path, ',') FROM product_images WHERE product_id = p.id LIMIT 1) as image
    FROM applications a
    JOIN products p ON a.product_id = p.id
    WHERE a.status IN ('Active', 'Lease Activated') AND p.status = 'approved'
    ORDER BY a.created_at DESC
    LIMIT 6
");

// Get distinct sectors for filter dropdown
$sectors = $db->query("SELECT DISTINCT sector FROM products WHERE available = 1 AND status = 'approved' AND sector IS NOT NULL ORDER BY sector");

include __DIR__ . '/../includes/header.php';
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Market – Available Equipment</h1>

    <!-- Filters -->
    <div class="bg-white p-4 rounded shadow mb-8">
        <form method="get" action="" class="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Sector</label>
                <select name="sector" class="w-full border border-gray-300 rounded p-2">
                    <option value="">All Sectors</option>
                    <?php while ($s = $sectors->fetchArray(SQLITE3_ASSOC)): ?>
                        <option value="<?= htmlspecialchars($s['sector']) ?>" <?= $sector == $s['sector'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($s['sector']) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Min Price (ETB)</label>
                <input type="number" name="min_price" value="<?= htmlspecialchars($min_price) ?>" step="1000" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Max Price (ETB)</label>
                <input type="number" name="max_price" value="<?= htmlspecialchars($max_price) ?>" step="1000" class="w-full border border-gray-300 rounded p-2">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Search</label>
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Product name..." class="w-full border border-gray-300 rounded p-2">
            </div>
            <div class="flex items-end">
                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded w-full">Filter</button>
            </div>
        </form>
    </div>

    <!-- Recently Leased Section -->
    <h2 class="text-2xl font-semibold mb-4">Recently Leased</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        <?php $count = 0; while ($lease = $recentLeased->fetchArray(SQLITE3_ASSOC) && $count < 6): $count++; ?>
            <div class="bg-white rounded shadow overflow-hidden">
                <?php if (!empty($lease['image'])): ?>
                    <img src="<?= BASE_URL . $lease['image'] ?>" alt="<?= htmlspecialchars($lease['name']) ?>" class="w-full h-48 object-cover">
                <?php else: ?>
                    <div class="w-full h-48 bg-gray-200 flex items-center justify-center text-gray-500">No image</div>
                <?php endif; ?>
                <div class="p-4">
                    <h3 class="font-bold text-lg"><?= htmlspecialchars($lease['name']) ?></h3>
                    <p class="text-gray-600">ETB <?= number_format($lease['price'], 2) ?></p>
                    <p class="text-sm text-gray-500"><?= htmlspecialchars($lease['sector']) ?></p>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <!-- All Products Grid -->
    <h2 class="text-2xl font-semibold mb-4">All Equipment</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <?php if (empty($products)): ?>
            <p class="col-span-full text-center text-gray-500">No products found.</p>
        <?php else: ?>
            <?php foreach ($products as $product): ?>
                <div class="bg-white rounded shadow overflow-hidden transition transform hover:-translate-y-1 hover:shadow-lg">
                    <!-- Image Carousel (if multiple images) -->
                    <div class="relative h-48">
                        <?php if (!empty($product['images'])): ?>
                            <div class="carousel relative h-full">
                                <?php foreach ($product['images'] as $idx => $img): ?>
                                    <div class="carousel-slide absolute inset-0 <?= $idx === 0 ? 'block' : 'hidden' ?>">
                                        <img src="<?= BASE_URL . $img ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-full object-cover">
                                    </div>
                                <?php endforeach; ?>
                                <?php if (count($product['images']) > 1): ?>
                                    <button class="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-1 rounded-full hover:bg-opacity-75 carousel-prev" data-product="<?= $product['id'] ?>">❮</button>
                                    <button class="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-1 rounded-full hover:bg-opacity-75 carousel-next" data-product="<?= $product['id'] ?>">❯</button>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <div class="w-full h-full bg-gray-200 flex items-center justify-center text-gray-500">No image</div>
                        <?php endif; ?>
                    </div>
                    <div class="p-4">
                        <h3 class="font-bold text-lg"><?= htmlspecialchars($product['name']) ?></h3>
                        <p class="text-gray-600">ETB <?= number_format($product['price'], 2) ?></p>
                        <p class="text-sm text-gray-500"><?= htmlspecialchars($product['sector']) ?></p>
                        <button onclick="openModal(<?= $product['id'] ?>)" class="mt-3 inline-block bg-blue-600 text-white text-sm px-3 py-1 rounded hover:bg-blue-700">View Details</button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Modal for Product Details -->
<div id="productModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6">
            <div class="flex justify-between items-start">
                <h2 id="modalTitle" class="text-2xl font-bold">Product Details</h2>
                <button onclick="closeModal()" class="text-gray-500 hover:text-gray-700 text-2xl">&times;</button>
            </div>
            <div id="modalContent" class="mt-4">
                <!-- Content loaded via AJAX -->
                <div class="text-center py-8">Loading...</div>
            </div>
        </div>
    </div>
</div>

<script>
// Simple carousel for product cards
document.querySelectorAll('.carousel').forEach(carousel => {
    const slides = carousel.querySelectorAll('.carousel-slide');
    let current = 0;
    const prevBtn = carousel.querySelector('.carousel-prev');
    const nextBtn = carousel.querySelector('.carousel-next');
    if (!prevBtn || !nextBtn) return;

    const showSlide = (index) => {
        slides.forEach((slide, i) => {
            slide.classList.toggle('hidden', i !== index);
        });
    };
    prevBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        current = (current - 1 + slides.length) % slides.length;
        showSlide(current);
    });
    nextBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        current = (current + 1) % slides.length;
        showSlide(current);
    });
});

// Modal functions
function openModal(productId) {
    const modal = document.getElementById('productModal');
    const modalContent = document.getElementById('modalContent');
    modalContent.innerHTML = '<div class="text-center py-8">Loading...</div>';
    modal.classList.remove('hidden');

    fetch(`<?= BASE_URL ?>api/product_details.php?id=${productId}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                modalContent.innerHTML = `<p class="text-red-600">Error: ${data.error}</p>`;
                return;
            }
            // Build HTML
            let html = `
                <div class="grid md:grid-cols-2 gap-6">
                    <div>
                        <div class="relative h-64 mb-4">
                            <div id="modal-carousel" class="relative h-full">
            `;
            if (data.images && data.images.length) {
                data.images.forEach((img, idx) => {
                    html += `<div class="modal-slide absolute inset-0 ${idx === 0 ? 'block' : 'hidden'}">
                                <img src="${BASE_URL}${img}" class="w-full h-full object-contain">
                             </div>`;
                });
                if (data.images.length > 1) {
                    html += `<button class="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-1 rounded-full hover:bg-opacity-75 modal-prev">❮</button>
                             <button class="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white p-1 rounded-full hover:bg-opacity-75 modal-next">❯</button>`;
                }
            } else {
                html += `<div class="w-full h-full bg-gray-200 flex items-center justify-center">No images available</div>`;
            }
            html += `</div></div>
                    <div>
                        <h3 class="text-xl font-semibold">${escapeHtml(data.name)}</h3>
                        <p class="text-gray-600 mt-2">Price: ETB ${formatNumber(data.price)}</p>
                        <p class="text-gray-600">Sector: ${escapeHtml(data.sector)}</p>
                        <p class="text-gray-600 mt-4">${escapeHtml(data.description || 'No description provided.')}</p>
                        <div class="mt-6">
                            <a href="<?= BASE_URL ?>?page=apply&product_id=${data.id}" class="inline-block bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Apply for Lease</a>
                        </div>
                    </div>
                </div>
            `;
            modalContent.innerHTML = html;

            // Setup carousel in modal
            const modalSlides = document.querySelectorAll('.modal-slide');
            let modalCurrent = 0;
            const modalPrev = document.querySelector('.modal-prev');
            const modalNext = document.querySelector('.modal-next');
            if (modalPrev && modalNext && modalSlides.length > 1) {
                const showModalSlide = (idx) => {
                    modalSlides.forEach((s, i) => s.classList.toggle('hidden', i !== idx));
                };
                modalPrev.addEventListener('click', (e) => {
                    e.stopPropagation();
                    modalCurrent = (modalCurrent - 1 + modalSlides.length) % modalSlides.length;
                    showModalSlide(modalCurrent);
                });
                modalNext.addEventListener('click', (e) => {
                    e.stopPropagation();
                    modalCurrent = (modalCurrent + 1) % modalSlides.length;
                    showModalSlide(modalCurrent);
                });
            }
        })
        .catch(err => {
            modalContent.innerHTML = `<p class="text-red-600">Failed to load product details.</p>`;
        });
}

function closeModal() {
    document.getElementById('productModal').classList.add('hidden');
}

// Helper functions
function escapeHtml(text) {
    if (!text) return '';
    return text.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}
function formatNumber(num) {
    return Number(num).toLocaleString('en-ET', {minimumFractionDigits: 2, maximumFractionDigits: 2});
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
PHP;

// Output the code (the heredoc above already includes the full market.php)
echo htmlspecialchars($marketPhp);
echo "</pre>\n";

echo "<p><strong>Done.</strong> After copying the code above into <code>pages/market.php</code>, your market page will show only products with <code>status = 'approved'</code>.</p>\n";
echo "<p>Also make sure your vendor product submission form inserts new products with <code>status = 'pending'</code>.</p>\n";
?>