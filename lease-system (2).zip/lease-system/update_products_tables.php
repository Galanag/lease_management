<?php
// update_products_tables.php
require_once 'config.php';

$db = getDb();

// 1. Add columns to products table if they don't exist
$columns = $db->query("PRAGMA table_info(products)");
$existingCols = [];
while ($col = $columns->fetchArray(SQLITE3_ASSOC)) {
    $existingCols[] = $col['name'];
}

$columnsToAdd = [
    'sector' => 'TEXT',
    'description' => 'TEXT',
    'status' => "TEXT DEFAULT 'pending'",
    'created_at' => 'DATETIME',
    'updated_at' => 'DATETIME'
];

foreach ($columnsToAdd as $colName => $colDef) {
    if (!in_array($colName, $existingCols)) {
        $db->exec("ALTER TABLE products ADD COLUMN $colName $colDef");
        echo "✅ Added column '$colName' to products table.<br>\n";
    } else {
        echo "ℹ️ Column '$colName' already exists in products table.<br>\n";
    }
}

// 2. Create product_images table if it doesn't exist
$tableExists = $db->querySingle("SELECT name FROM sqlite_master WHERE type='table' AND name='product_images'");
if (!$tableExists) {
    $db->exec("CREATE TABLE product_images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        image_path TEXT NOT NULL,
        sort_order INTEGER DEFAULT 0,
        FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
    )");
    echo "✅ Created product_images table.<br>\n";
} else {
    echo "ℹ️ product_images table already exists.<br>\n";
}

echo "<br>All updates completed. You can now <a href='index.php'>return to the site</a>.";